# Explicit Ordinary Restart

Original execution block 4 is integrated for the supported qualified installation.
This is the explicit FINISH path from specification 3.1.0 section 17.8, not an
OTA-success side effect, automatic reconnect, commissioning result or motor grant.
Default installation/profile/OTA qualification and motion gates remain closed.

## Admission And Discovery

The sole updater accepts FINISH only from a terminal locked job, with fresh
reconciled loader evidence, no candidate/transfer/TRIAL and a confirmed STM slot.
The native ESP check requires SDK VALID, full `esp_image_verify` including the
appended hash, actual S3 layout and the running embedded RFE1 operational
version/profile/build descriptor. SDK VALID or a declared hash alone is insufficient.
The worker refreshes its clock after this synchronous SDK operation; stale loader
proof cannot gain renewed age. Its WCET/watchdog bound requires target measurement.

EXITING is durably read back before EXIT(3,1,installed-profile). Only a whole
native UART drain starts operational discovery. Retained EXITING reacquires the
same all-owner/exclusive-UART barrier and reconciles the already-authorized intent.
The service client emits ordinary HELLO plus ABI discovery and STATUS queries
through the existing TX/RX owner. No OPEN, NRST or BOOT0 change accompanies this
expected APP discovery. Lost EXIT ACK is not success or an automatic failure:
independent new-APP proof is mandatory before the original 15-second deadline.
An explicit rejection, partial UART failure, incompatible identity or expiry
remains closed with EXIT_FAILED.

ABI 1 loader READY after an ESP update/repair does not disclose the confirmed
STM image length/hash/build. FINISH therefore persists an explicit slot/profile
intent with unknown length/hash/build left zero. The loader independently
verifies its confirmed journal/image and installed contract at EXIT, and the new
APP independently validates its confirmed bootstrap/journal/image before APP/IDLE.
STM COMPLETE additionally retains the exact installed STM descriptor and checks
the matching operational build. No ESP hash is relabeled as a STM hash.

REU1 remains canonical version 1, 512 bytes. Slot/profile-only EXITING uses the
existing exit-image field, with no guessed metadata, format, migration or erase.
Older decoders reject this representation closed. Qualification/rollback tests
must use compatible previous recovery firmware, including error enums 7/8.

## Native Preparation

`RoverUpdateRestart` collects all nine owner domains using the entry collector's
actual generation and EXITING successor ticket. Original source times survive
value mailboxes; contention retries without pretending a native action succeeded.
Busy preparation revokes a prior positive acknowledgement.

- Gateway resets mission/upload state, completion/request objects, manual lease,
  telemetry replay watermarks and forwarding caches. Old frontend work is drained.
- GNSS owns driver teardown and fresh receiver/configuration/parser/GGA/epoch
  initialization; IMU owns SH-2/Wire teardown and fresh acquisition/epoch reset.
  Missing configured hardware remains unavailable, not a fabricated good sample
  or a FINISH prerequisite. Driver failures remain negative preparation.
- The IRQ owner waits for both fresh driver preparations before resetting and
  resuming the native ISR fence. Diagnostic IRQ attachment waits for ordinary
  admission; old callbacks cannot accumulate reusable samples during inhibition.
- MQTT destroys the old SDK client/outbox, clears inbound/outbound work and
  preserves its single publisher task. The new connection has a new generation.
- NTRIP clears socket/parser/RTCM/GGA/backoff state and retains the actual enabled
  deployment configuration even when restricted boot created no caster worker.
- Manual WS stays closed until native async teardown/empty session proof;
  admission waits for empty command/STOP/ACK/ordinary HTTP queues. Released
  network/manual tickets are recognized without requiring them to stay parked.
- The UART owner requires its actual parser, software queues and hardware TX
  drained, plus idle service transport and exact native release authorization.

## Final Proof And Release

The sole RX owner observes CRC-valid HELLO/STATE/SAFE/MOTOR into a value mailbox.
Fresh operational 3.1/512/profile/build identity must match independently queried
APP/IDLE/NONE, unlocked, confirmed intended slot and no candidate/image/transfer.
STATE must have a nonzero fresh epoch, EMPTY store, zero mission/progress/lease/
input and no start/resume permission. All three newly observed motor targets
must be known zero. Allowed state is DISARMED without faults, or FAULT with
only active physical-input causes corroborated by fresh SAFE. GNSS fix, IMU
readiness, mechanical-stopped feedback and released ESTOP are not required.
Other faults, stale/unknown targets, wrong boot/profile/build, RX integrity loss
or replayed/regressing state cannot unlock. Forward epoch changes from native
physical-fault sampling are accepted; regression is not. Newly received native
U_STATUS also revokes an older queried APP proof if lock/error/transfer changes
or malformed status arrives during release, even after service transport closes.

After all native preparations and STM proof, the updater commits and reads back
the exact IDLE successor. Time is refreshed after NVS; expired owner proof cannot
release transport. Transport release precedes individual native authorization;
all owner releases must complete before the bridge adopts the new boot/epoch.
Every release pass rereads the exact canonical persistent record. The bridge
rechecks the latest native observation, not the cached initially positive proof,
then the updater independently rechecks it again before opening admission.
Service sequence ownership passes to the ordinary UART sequence without reuse.
Any delayed/partial release remains closed and is bounded by the original
15-second deadline; failure after IDLE persists locked ERROR/EXIT_FAILED when
storage can still be verified. Uncertain storage is never repaired automatically.

Restricted boot prepares only dormant fresh sensor/frontend tasks. UART,
network and updater tasks transfer to their ordinary loops in the same native
task; no second parser, updater or network owner is created. Frontend ownership
passes explicitly from the restricted network loop. Normal boot reuses existing
owners. Explicit new mission upload/ARM/START/manual claim remain necessary.
HC integration is external: [HC handoff](HC_V31_INTEGRATION_HANDOFF.md) describes
discarding old command/session objects and binding the new boot/epoch.

## Verification Limits

Host integration executes actual framed discovery/query/EXIT, durable store,
native producer gates and restart orchestration for live FINISH (with dropped
ACK) and retained EXITING, each with DISARMED and active ESTOP/FAULT. Negative
tests cover newer nonzero motor targets or locked service status, missing/negative owner preparation,
late NVS completion, unavailable callbacks, delayed authorization/transport,
partial-release expiry and persistent relock. Native sensor/IRQ, MQTT and NTRIP
fixtures cover real callback ordering, a second maintenance cycle, no duplicate
publisher and enabled-caster return from restricted startup. SDK fixtures check
the actual running-image verification adapter; source guards check final native
revalidation, read-only discovery and same-task promotion.

Actual pinned ESP sketch/Xtensa object/IRAM/build-policy checks are separate
from the 130 host executables and 138 Python cases, passing normally and under
ASan/UBSan. Neither is a commissioned-board full ELF or on-device proof of
electrical stopping, scheduler/teardown/SDK WCET, power-cut persistence or the
52 system acceptance cases. No device was flashed/reset/operated; acceptance
remains 0/52. Original item 1's measured-only reset-time loader CAN producer
remains separate software work; the independently power-inhibited path is the
supported integration.
