# HC-ből kezelt roverparaméterek — új követelmény, 2026-10-09

Állapot: az RCP1 adatcodec, HC draftséma és RCF1 tartós tárolási alapréteg
implementált/tesztelt; az éles STM/HTTP runtime írási útvonal még NINCS bekötve.
Pontos szerződés és korlátok: `HC_PARAMETERS_RCP1.md`.
A felhasználó kifejezetten HC-ből kezelhető paramétereket kér,
nem fordításonként generált C headereket. Ez felülírja a mellékelt baseline
v3.1.0 specifikáció 4.2 fejezetének immutable operational profile előírását.
A baseline fájlt történeti/formátum-referenciaként változatlanul megőrizzük;
nem állítjuk, hogy a jelenlegi firmware már teljesíti ezt az új követelményt.

## Elvárt működés

- A HC-ban legyen roverenként menthető, szerkeszthető paraméterkészlet,
  import/export, összehasonlítás az aktív rover-konfigurációval és explicit
  alkalmazás. A HC szerkesztett draftja nem automatikusan aktív konfiguráció.
- A rover tartós, verziózott konfigurációból dolgozzon, ne
  `rover_installed_profile.h` generálásából. Paraméterváltoztatáshoz ne kelljen
  STM/ESP firmware újrafordítás vagy OTA.
- Az STM döntsön az aktív mozgási konfigurációról. Az ESP a hitelesített
  továbbító/tárolási-egyeztetési részt végezze; a HC csak a rover által
  visszaigazolt és visszaolvasott revision/hash értéket mutassa aktívként.
- Első telepítés után hiányzó konfigurációval legyen elérhető a diagnosztika
  és a támogatott konfigurációs szolgáltatás, de ARM/START/MANUAL ne legyen
  engedélyezhető. Hiányzó fizikai értékeket ne pótoljunk működőnek látszó
  alapértékekkel. Firmware feltöltése és mozgásra minősítés külön lépés.

## Paraméterek és boardbizonyíték különválasztása

Az operátori paraméterek közé tartozik a roverazonosító, geometria, gördülési
kerület, motor póluspár/áttétel/irány, antenna/IMU kalibráció, sebesség-,
gyorsulás-, fordulás-, GNSS/heading/tilt- és késbeállítás. Ezek tárolása és
kezelése legyen adatvezérelt, HC-ből elérhető. A változtatás fizikai jelentését
és kapcsolódó méréseit a felület külön mutassa; a helyes JSON még nem bizonyítja
a tényleges kerületet, motorirányt vagy fékezési teljesítményt.

A MCU/flash-kiosztás, loader írásvédelem, clock/DMA/GPIO bekötés, hardveres
ESTOP/inhibit/független feedback és watchdog/táp minősítése külön board-
telepítési réteg. Ezek nem szabadon átírható üzemmenü-paraméterek. Lehet hozzájuk
HC szervizoldali adatlap/folyamat, de változtatásuk külön jogosultságot és
ellenőrzött üzembe helyezést igényel. Az inhibit/feedback fizikai jelenlétét
egy HC checkbox nem bizonyítja. `commissioned=true` és biztonsági minősítés
nem lehet egyszerű felhasználói kapcsoló.

Mért biztonsági határértéket csak a hozzá tartozó érvényes üzembe helyezési
bizonyítékkal lehessen bővíteni. Egy paramétermódosítás ne tehessen elavult
stop-, geofence-, motor- vagy szenzor-kalibrációt automatikusan érvényessé.

## Alkalmazási és tárolási követelmények

Konfiguráció csak explicit kezelői műveletként, megállított/disarmed, igazoltan
tiltott kimenetű állapotban alkalmazható; futó firmware update/TRIAL/EXIT,
mozgás vagy aktív manual lease alatt nem. A kézi session, küldetés és heading
érvényességét a megváltozott paramétereknek megfelelően vissza kell vonni.
Változás után nincs automatikus ARM, START, manual claim vagy mission resume.

Kell teljes séma és keresztmezős validálás, egész számok és mértékegységek,
kanonikus payload hash/CRC, monoton revision, expected-revision összehasonlítás,
aktuális MCU boot/control epoch és idempotens request-azonosító. Elveszett írási
válasz UNKNOWN; visszaolvasásos egyeztetés szükséges, nem automatikus újraküldés.

A tartós commit legyen áramkimaradás-tűrő: külön staging/inaktív rekord, teljes
ellenőrzés, commit-last, visszaolvasás, az előző jó konfiguráció megőrzése.
ESP/STM eltérés vagy félbeszakadt tranzakció alatt a mozgási kapu zárt maradjon.
A régi jó konfiguráció visszaállása legyen azonosítható, ne néma siker.
Firmware update és rollback ne törölje vagy válassza le a konfigurációt.

## Miért kell roveroldali átalakítás is?

Jelenleg a `tools/rover_profile.py install` C headert generál, és mindkét
firmware újrafordítását kéri. A main/szenzor/kézi útvonalak a
`r3_installed_profile` konstansból dolgoznak. A natív loader/APP admission
összehasonlítja a compiled profilt a factory rekorddal; RFU2, journal,
boot capsule és ESP OTA is ugyanahhoz a profile CRC-hez kötött.

Ezért egy új HTTP setter vagy a JSON kizárólag ESP NVS-be mentése nem elég.
A board/factory-azonosságot és a módosítható aktív paraméterrevision/hash-t
szét kell választani; át kell vezetni a loader/APP boot-admission, image/header,
journal, TRIAL/rollback, ESP bootstrap, HELLO/STATE, mission és konfigurációs
szolgáltatásokon. A korábbi képformátumokat nem szabad csendben átértelmezni.
Külön verziózott migráció és régi/új capability-egyeztetés szükséges.

## HC AI feladata és jelenlegi API-korlát

A HC AI a szerkesztőt, roverenkénti drafttárolást, validálást, import/exportot,
revision/conflict/UNKNOWN/stale kijelzést és a backend integrációs határt készítse
elő. A roveroldali szolgáltatás és pontos API/ACK-séma egyeztetéséig a tényleges
„alkalmazás a roveren” művelet legyen unavailable, ne mutasson szimulált sikert.
Az identity `runtime_parameters=false`; nincs paraméter-írási endpoint: ne találjon ki egyet,
ne használjon firmware OTA-t vagy nyers UART-ot paraméterbeállítás helyett.
A meglévő `GET /api/v3/profile` olvasási útvonal nem setter.

A most csomagolt referenciafeltöltő a JELENLEGI, profile-CRC-hez kötött
firmware update API-t teszteli. Nem runtime paraméterfeltöltő, nem az új
konfigurációs protokoll tesztje. A készülő API majd külön referencia- és
integrációs tesztkészletet kap, többek közt power-cut/commit, ESP/STM mismatch,
revision-conflict, invalid-measurement, missing-config boot és rollback esetekkel.
