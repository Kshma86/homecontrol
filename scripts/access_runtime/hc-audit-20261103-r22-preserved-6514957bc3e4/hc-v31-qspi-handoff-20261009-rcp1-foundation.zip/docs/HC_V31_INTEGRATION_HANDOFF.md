# HC v3.1 Integration Handoff

Owner: the HC client/backend on the other machine. Updated: 2026-10-09.
Authority: ROVER_SYSTEM_SPEC_v3.1.0.md, especially sections 4, 11-14, 17 and 22.
The live authenticated HTTP/durable-session coordinator, RFU2 transport,
STM TRIAL/CONFIRM/EXIT reconciliation and ESP OTA coexistence are implemented.
The default uninstalled builds still advertise `conformant=false` and
`stm_remote_update=false`: measured installations and hardware acceptance are
not supplied. Check the running identity; never bypass a 501 capability gate.
VG/QSPI is an explicit alternate layout, not section 17's baseline internal A/B
design and not a claim of full v3.1.0 conformance.

New user requirement: HC-managed persistent runtime parameters, not compiled
profile/header changes. Read [parameter management](HC_PARAMETER_MANAGEMENT.md)
first: it supersedes baseline section 4.2 as a target requirement. The live
parameter-write service is NOT implemented yet; the update schemas below
describe the current profile-bound firmware, not a fictional configuration API.

## Files To Transfer

- This file and the complete system specification.
- `tools/rover_hc_update.py`, `tools/rover_image.py`, `tools/rover_qspi_image.py`,
  `tools/rover_ram_audit.py`, `tools/rover_profile.py`: tested reference transport
  and separate RFU1/RFU2 inspectors. The ZIP includes their dependencies.
- `tests/test_rover_hc_update.py`, `tests/test_rover_image.py`: reference cases.
- `shared/rover_protocol.h`, `shared/rover_update_protocol.h`,
  `shared/rover_mission_validator.h`, `shared/rover_auth.h`: exact format authorities.
- `config/rover_profile.template.json`, `config/installation.template.json`,
  `config/acceptance.template.json` and their validators. Measured values are
  not supplied and must not be filled with guessed defaults.

Preserve the `tools`, `tests`, `shared` and `config` relative directory layout
when running the reference tools; their imports/template paths use that layout.

## Backend And Authentication

Keep the provisioned 64-hex Bearer token on the HC backend, never in browser
storage, browser-visible configuration, URLs or logs. Send
`Authorization: Bearer <token>` on every rover HTTP request. Use the trusted
LAN/VPN and authenticated protected transport for any external access.
Do not follow redirects with rover credentials. Limit response sizes and
validate JSON types, enums, complete fields, identities and numeric bounds.
The reference CLI reads `ROVER_API_TOKEN`; it does not expose a token option.

## Update Workflow

1. Read `GET /api/v3/identity` and `GET /api/v3/update`. Enable STM update only
   with `stm_remote_update=true` and an exact recognized ABI/layout pair:
   ABI 1 / `H743_2M_AB1`, or ABI 2 / `H743_1M_QSPI2`. For VG also require a
   nonzero uppercase 8-hex installed `profile_crc` and
   `stm_image_max_bytes=524288`. A diagnostic LOADER response alone is not
   that capability. Unknown or contradictory pairs reject without mutations.
2. After an explicit operator action, allocate a unique request ID matching
   `[A-Za-z0-9_-]{1,64}`. Send at most 1024 bytes of exact JSON:

   ```json
   {"v":3,"request_id":"hc-update-42","esp_boot":"0123456789ABCDEF","target":"STM"}
   ```

   The `esp_boot` is the current nonzero uppercase 16-hex identity, not a saved
   value from a prior connection. Target may be STM or ESP. Do not require ARM,
   GNSS fix, heading calibration or healthy IMU to request maintenance.
3. A 202 admits the session, not a flash write or success. Persist the returned
   nonzero uppercase 32-hex update ID and progress URL in HC. Poll at 2 Hz.
   Close the ordinary control UI and discard executable manual/mission requests.
4. Wait for the same job's fresh loader-derived READY: `source=STM_LOADER`,
   `source_valid=true`, `source_age_ms<=2000`, `locked=true`, `error=NONE`,
   `can_active=false`, `outputs_inhibited=true`. In A/B `candidate_slot=NONE`;
   in VG all three slot fields must be present and null, not A/B/NONE.
   Never turn UNKNOWN/null evidence into stopped or CAN-off.
5. For ABI1 STM, retain both actually slot-linked variants of the same release.
   Confirmed A means upload B; confirmed B or NONE means upload A. Reject
   contradictory inactive slot, different build/profile/contract, invalid RFU1,
   vector outside its slot, or a merely renamed A/B binary. Never relocate
   bytes in HC. `tools/rover_image.py inspect` checks the package format.
   For VG use one RFU2 APP linked at 0x08100000 with RTE2 trial metadata and
   its actual reviewed ELF. Do not rename/translate RFU1 or select an inactive
   A/B slot. Check exact release SHA-256, firmware token, profile and ELF with
   `tools/rover_qspi_image.py`; the reference `upload-qspi` performs those checks.
6. Upload once to `POST /api/v3/update/{id}/image`, raw binary, with all headers:

   ```text
   Content-Type: application/octet-stream
   Content-Length: <exact binary byte length>
   X-Image-SHA256: <64 lowercase hex, over the entire exact binary>
   X-Firmware-ID: <1..48 character firmware token>
   X-Profile-CRC32: <8 uppercase hex>
   X-Contract: 3.1.0
   X-Flash-Layout: H743_2M_AB1
   X-Image-Slot: A
   ```

   For ABI1 replace the example slot with the observed inactive slot; length
   is 1280..786432. **For VG replace the layout header with
   `H743_1M_QSPI_REC2` and slot with `APP`; length is 1280..524288.**
   `H743_1M_QSPI2` is the identity/service literal, not the image-header literal.
   Both STM lengths include FF padding and are multiples of 32. For ESP,
   upload a standard SDK app binary within the reported inactive capacity;
   layout is `ESP_IDF_OTA` and slot is `INACTIVE`. Headers cannot override
   embedded metadata. Do not use chunked encoding, multipart, JSON/base64,
   MQTT firmware transport or duplicate image headers.
7. Image 202 means the whole body was admitted; verification/trial is still
   asynchronous. Show RECEIVING, ERASING, WRITING, VERIFYING, TRIAL and COMPLETE
   separately. Byte progress at 100% is not installation success. There is no
   extra ACTIVATE call: verified transfer proceeds to trial automatically.
8. Offer explicit ABORT and FINISH. ABORT retains the lock and prior confirmed
   image; after confirmation it cannot undo the installation. FINISH is allowed
   only with fresh `can_finish=true` after COMPLETE/ABORTED/ERROR. POST their
   exact `/abort` or `/finish` paths with an empty body. A FINISH 202 is pending;
   wait for verified IDLE and fresh compatible DISARMED/EMPTY, or physical-input
   FAULT. Never automatically FINISH, ARM, START, re-upload or resume a mission.

## Lost Replies And Reboots

The rover now implements the supported qualified native FINISH path described
in [explicit ordinary restart](NATIVE_ESP_RESTART.md). HC must still wait for
unlocked IDLE plus the new compatible STM boot/epoch and EMPTY/zero-target
state; an EXIT ACK, FINISH 202 or transient IDLE while the ordinary gate remains
locked is not completion. Discard old mission, command, manual lease and sensor
session objects. Physical-input-only FAULT is a valid FINISH result, never an
ARM grant. This handoff does not modify the external HC application.

- If a mutation response is lost, mark its outcome UNKNOWN and reconcile using
  GET on the retained job. The reference raises `UnknownMutation`; it never
  automatically replays a mutation. Read-only polling may retry with backoff.
- An operator-authorized exact create replay can resolve to the same persisted
  job; changed contents under the same request ID are ID_CONFLICT. A new ESP boot
  requires new discovery and an explicit decision about the old job.
- An incomplete body/transfer after MCU reboot is not resumable by offset.
  Reconcile, explicitly abort if applicable, then create a new session and
  upload the full image. Do not issue an unobserved BEGIN/END with a new identity.
- If source evidence goes stale, retain the last progress but label it lost.
  Neither a disconnected request nor disappearance of MQTT proves COMPLETE,
  rollback or a successful return to ordinary operation.
- HTTP 401/403 is authentication failure, 409 is a conflict/precondition,
  413 is a size error, 422 is invalid content, 423 is the ordinary maintenance
  gate, 501 is uninstalled software capability, and 503 is unavailable service.
  Do not respond by trying another legacy update/control path.

## Ordinary HC Migration

Remove `/api/drive`, legacy route/mission/heading/STM update, ArduinoOTA and ROM
fallback calls. Use only `/api/v3` and MQTT `/v3`; require operational HELLO 3.1
and profile agreement for motion. Prefer the authenticated backend for browser
transport. Use `homecontrol.mower.manual.v3` for manual WS, one operator session,
explicit held deadman and server-issued identities. Do not retain or replay
manual setpoints/MQTT commands after reconnect. Do not compute a competing rover
navigation state or invent heading/coordinate offsets in HC.

The STM state/epoch is authoritative. Present freshness explicitly; source
timestamps cannot be refreshed by copying data into HC. Mission bytes must use
the exact specification format/CRC and installed profile, <=131072 bytes and
<=4096 segments. Keep saved missions on HC, but an update deletes STM runtime
mission/checkpoint/heading/lease: the next operation requires a new explicit
upload/calibration/ARM/START sequence as applicable. STOP remains independent
of ownership; STOP does not mean ABORT or reset a fault.

### HTTP Mapping

| Endpoint | HC behavior |
|---|---|
| GET `/api/v3/state` | Display STM-authoritative state and original source age; unknown is not DISARMED. |
| GET `/api/v3/profile` | Accept only canonical installed profile with matching STM CRC; 503 means unavailable. |
| POST `/api/v3/command` | Exact discrete command schema below; 202 is pending. |
| GET `/api/v3/command/{request_id}` | 202 pending, 200 correlated result, 404 unknown/evicted. No optimistic execution success. |
| POST `/api/v3/stop` | Exact `{ "v":3,"request_id":"hc-stop-1" }`; no boot/epoch/ownership requirement. |
| POST `/api/v3/mission` | Raw RVM3 binary, exact Content-Length and required mission headers. Never auto-START. |
| GET `/api/v3/mission` | Reconcile upload/validation result from authoritative store/identity, not sent-byte count. |
| DELETE `/api/v3/mission/upload/{id}` | Cancel this upload only; not a command to stop an executing mission. |
| GET `/api/v3/manual` upgrade | Authenticated backend WS relay with the exact v3 subprotocol. |

Example command object, with current identities/epoch substituted:

```json
{"v":3,"request_id":"hc-arm-42","esp_boot":"0123456789ABCDEF","stm_boot":"FEDCBA9876543210","control_epoch":7,"command":"arm","value":null}
```

Allowed discrete commands/values follow specification section 12.2 exactly:
arm/disarm/pause/reset_fault/maintenance_begin/maintenance_end/telemetry use
null; heading_set uses integer heading_mdeg; start/resume use mission_id,
revision and crc32. Unknown extra fields reject. No movement mutation is
automatically resent after UNKNOWN. A correlated APPLIED ACK is required;
at 1500 ms without one, show UNKNOWN and query state.

Mission upload headers are `Content-Type: application/octet-stream`, exact
`Content-Length`, `X-Mission-CRC32`, `X-Request-ID`, `X-ESP-Boot`, `X-STM-Boot`
and `X-Control-Epoch`. The CRC is the RVM3 header's defined checksum, not a
whole-file CRC including its own field. No chunked encoding. END admits bounded
STM validation; only an observed READY establishes an executable mission.

For MQTT, use the provisioned base plus `/v3` and the section 12 topic table.
Commands/STOP are QoS 0, non-retained, clean-session and never queued for replay.
State is stale after 1500 ms without a new source sequence; unchanged
republished snapshots cannot renew freshness. Sensor ages keep their stricter
individual validity rules. Firmware images are never transported over MQTT.

For manual WS, wait for the correlated claimed lease, then send complete
setpoints at 10 Hz only while the operator holds the deadman. Sequence must
strictly increase within that lease. Relay only the latest fresh unsent frame,
never synthesize or replay a previous command. Deadman release sends a complete
zero setpoint with deadman=false. Socket stop keeps ownership; release ends the
matching lease; global STOP remains the separate HTTP/MQTT operation.

## HC Test Checklist

- Exact create JSON including current ESP boot; missing/extra/duplicate fields,
  malformed identities, stale boot and changed request fingerprint reject.
- Both real A/B variants, inactive-slot selection, wrong profile/header/vector,
  uppercase/lowercase hash rules, truncated/oversized/chunked body.
- Every phase's UI, counters, null/stale source evidence and changed MCU boot.
- Lost create/body/abort/finish reply with no hidden retry or auto-activation.
- STOP/ABORT during receipt/erase/trial; ALREADY_COMMITTED remains successful
  installation, not a rollback or an aborted image.
- Explicit FINISH, failed EXITING, no retained command replay, no automatic ARM.
- Gate false/501 and restricted recovery diagnostics cannot enable the updater.
- Backend secrets stay absent from browser state, request logs and redirects.

Run the reference tests locally before connecting to a rover. Hardware T37-T52
still require real commissioned equipment and evidence; mock HC success is not
physical acceptance. The existing reference adapter implements STM transport,
not a finished ESP-OTA UI or the actual HC application's integration.

```sh
python3 tests/test_rover_hc_update.py
python3 tests/test_rover_image.py
```

## VG / QSPI Layout Integration (2026-10-09)

The 1-MiB STM32H743VG uses RFU2 / service ABI2, one internal APP and verified
external stores, not RFU1 A/B. Identity/service names the layout
`H743_1M_QSPI2`; RFU2 packages/image headers name it `H743_1M_QSPI_REC2`.
The live ESP coordinator supports this exact pair. Default uninstalled builds
remain disabled. Never infer commissioning from an earlier QSPI bench, a generic
ESP build, null slot fields or a prepared offline installation bundle.

HC must use authenticated HTTP only, not the compact RQ2 UART envelope or native
permission flags. Bind the VG workflow to the published layout/target, immutable
RFU2 metadata, fresh boot epoch and durable job ID/result. The integration and
remaining hardware acceptance requirements are documented in
[QSPI_UPDATE_RUNTIME.md](QSPI_UPDATE_RUNTIME.md).

The VG wire now explicitly distinguishes LOADER and APP_TRIAL, with a fresh
APP epoch separate from the loader/storage generation. An APP CONFIRM success
only prepares its guarded TRIAL_OK reset: it remains locked TRIAL_ATTEMPTED with
no completed job result. HC must not report durable installation success from
that ACK. Only a fresh loader session's committed CONFIRMED / COMPLETE result
proves finalization. Role/epoch changes require explicit authenticated coordinator
reconciliation, not automatic retries, unlock or normal-operation resume.

The actual VG operational maintenance service requires HELLO arguments
`2,H743_1M_QSPI2,ESP,<firmware>` and replies
`2,H743_1M_QSPI2,APP,<firmware>`. ABI1 HELLO does not admit this path. OPEN/STATUS
use the existing admission envelope and sole UART owner; after guarded
ENTER_UPDATE reset the loader durably locks the same update ID before BEGIN.
Never derive a VG job from an A/B slot or translate RFU1 headers into RFU2.

ABI2 EXIT has explicit peer major/minor/profile compatibility at binary request
bytes 276/278/280 (u16/u16/u32 LE), represented as its own eight-byte compact
payload. Peer must be operational 3.1 with the installed profile, and ESP must
independently prove its confirmed APP before FINISH. No GNSS/IMU navigation
readiness is required to finish maintenance. EXIT is not an ARM grant.

The adapter's guarded `expectReset` can reconcile TRIAL, CONFIRM and EXIT only
after canonical terminal ACK plus actual hardware TX drain. Its
`exitResetVerified(now)` means a fresh loader has observed the exact unlocked
confirmed journal; it is NOT ordinary restart success. HC must still await the
separate compatible ordinary APP boot and fresh EMPTY/zero-target evidence.
Neither these wire details nor an offline installation bundle enables an HC
action. See [offline first installation](QSPI_PROVISIONING.md).

### Important VG Restrictions

- In VG maintenance there is no ABI2 STOP opcode. Authenticated ordinary STOP
  returns **503 / NOT_READY** while that path owns UART; never display it as
  APPLIED or physical standstill. Physical inhibit and independent feedback
  remain mandatory. Before wire entry, STOP can use the ordinary stopping path.
  STOP is never ABORT or FINISH. This differs from baseline section 17; HC
  cannot repair it by sending ABI1/raw UART.
- `can_retry=false` is intentional for the current VG locked terminal workflow.
  Do not create a replacement job while it remains locked. Offer reconciliation,
  supported ABORT where applicable and explicit FINISH only when permitted.
- Retained STM TRIAL after ESP reboot cannot be re-confirmed using a new timer.
  Wait for authoritative rollback/committed loader outcome; never claim success
  from an APP ACK, invent a deadline or auto-replay the transfer.

Reference VG upload, after explicit create and fresh READY:

```sh
python3 tools/rover_hc_update.py --url http://ROVER upload-qspi \
  --id CURRENT_32_HEX_JOB --app approved.rfu2.bin --elf approved.app.elf \
  --sha256 APPROVED_64_LOWERCASE_HEX --firmware-id APPROVED_TOKEN
```

`ROVER_API_TOKEN` is supplied locally to the backend process, not copied into
this file or the command line. The reference CLI implements STM updates only;
implement target-ESP UI/backend separately against the published identity and
actual audited ESP app release. Do not reuse the RFU2 parser for ESP binaries.
