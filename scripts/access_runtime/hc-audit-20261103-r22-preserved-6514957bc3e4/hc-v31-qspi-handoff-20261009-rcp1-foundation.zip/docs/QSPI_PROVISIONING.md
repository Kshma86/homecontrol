# Offline VG First Installation

This is artifact preparation and a review checklist, **not an automatic flash
procedure or commissioning approval**. The installed/profile/update/motion
defaults remain closed. The current board's previously observed SWAP_BANK=1
and unprotected root do not meet the native VG writer's requirements.

The actual STM software is selected with `ROVER_STM_SLOT=QSPI`; RFU1 A/B images,
VI factory records and the NONDEPLOYABLE QSPI fixture cannot be substituted.
The live authenticated ESP VG update workflow is implemented but remains gated
by the reviewed installed profile/loader headers. A prepared bundle alone does
not make that capability available and is not permission to flash.

## Required Reviewed Inputs

- Complete measured `rover_profile.json`, not the empty template or test data.
- VG `installation.json`: exact UID/revision/density and actual clock/pins,
  independently verified inhibit/feedback/coast, VESC configurations and stop
  evidence. NOR pins PB2/PB6/PD11/PD12/PD13/PE2 are reserved.
- `loader_qualification.json`: real 64-MHz reset-clock register observations,
  characterized LSI/IWDG bounds, supply error/temperature evidence and reviewed
  manuals/errata. A VI CAN-only qualification cannot replace VG power feedback.
- Actual loader and APP ELF files built with matching reviewed local profile
  and VG qualification headers; exact padded RFU2 body and release SHA-256/token.
- Retained internal-bank, option-byte and complete existing-NOR backups, with
  hashes and recovery access. Preserve `artifacts/qspi-bench-20261008/` unchanged.

Header generation can be performed offline into new review paths:

```sh
python3 tools/rover_profile.py install rover_profile.json \
  --output /tmp/vg-reviewed-profile.h
python3 tools/rover_loader_commission.py rover_profile.json installation.json \
  loader_qualification.json --layout H743_1M_QSPI_REC2 \
  --header /tmp/vg-reviewed-loader.h
python3 tools/rover_factory.py rover_profile.json installation.json \
  --layout H743_1M_QSPI_REC2 --output /tmp/vg-reviewed-factory.rfi2.bin
```

Review the generated data before applying it to the compiled local headers
`shared/rover_installed_profile.h` and `shared/rover_installed_qspi_loader.h`.
Generating a header does not install it or qualify hardware. Receiver/sensor/
ESP OTA installations have their own measured-header workflows; do not turn
their flags positive merely to make a build or the bundle tool pass.
Rebuild BOTH actual native targets and run CTest using the commands in
`recovery/qspi/README.md`. Default uninstalled ELF files correctly fail the
bundle's local-installation binding checks.

## Prepare The Bundle

Supply the approved release's exact lowercase SHA-256 independently; the tool
does not replace it with a hash calculated from an untrusted input:

```sh
python3 tools/rover_qspi_provision.py \
  rover_profile.json installation.json loader_qualification.json \
  /tmp/rover-vg-app/recovery/qspi/rover_qspi_loader.elf \
  /tmp/rover-vg-app/H743_LED_Blink_MX.elf \
  /tmp/rover-vg-app/H743_LED_Blink_MX.bin \
  --sha256 <approved-lowercase-sha256> --firmware <approved-firmware-token> \
  --output /tmp/rover-vg-first-install
```

The output directory must not already exist. Input validation precedes directory
creation. Existing bundles are never overwritten. A write failure can leave a
partial new directory; no package is usable without the complete manifest and
all files independently matching its declared hashes. Inputs are bounded regular
files; JSON duplicate keys, missing evidence, wrong target/profile/hash/firmware,
invalid native ELF placement/startup, and mismatched compiled data reject.

| Output | Placement / Meaning |
| --- | --- |
| `loader.bin` | Root at 0x08000000, strictly below 0x08078000 |
| `factory.rfi2.bin` | Exact 32-KiB RFI2 at 0x08078000 |
| `app.rfu2.bin` | Sole internal APP at 0x08100000, at most 512 KiB |
| `initial-nor.bin` | Clean initial 8-MiB layout: confirmed mirror in store 1 at 0x040000; canonical sequence-1 CONFIRMED/unlocked journal at offset zero |
| `manifest.json` | Exact hashes/lengths/UID/profile/firmware, required map/WRP, actual compiled profile commissioning bit and explicit offline-only/uncommissioned/update-disabled review state |

Other NOR stores, the second journal and expansion reserve are erased in this
clean first-install image. **It is not a migration image for an existing device.**
The manifest's `commissioned=false` means this offline operation grants no
physical commissioning approval; `compiled_profile_commissioned` separately
reports the source profile's actual bit. Never confuse those two meanings.
Do not mass-write it over retained journals, earlier backups or unrelated reserved
NOR data. Archive/review the existing chip first and explicitly approve either
a clean installation or a separate migration plan. SD is not required.

## Physical Provisioning Review

1. Keep the rover physically inhibited and retain verified recovery access.
   Confirm ST-LINK serial, MCU UID, 1024-KiB density and reviewed revision 0x2003.
2. Review the actual physical bank map and original options/backups before any
   SWAP_BANK or WRP change. Required native steady state is unswapped banks,
   WPSN1 low byte F0 and WPSN2 low byte FF. No tool here applies those changes.
   Reject the unpopulated 0x08080000..0x080FFFFF hole in every read/write plan.
3. Review whole internal erase-sector ownership: RFI2 shares bank 1's last
   128-KiB sector with the root reservation and cannot be erased independently.
   Protect root/factory only after reviewed installation and readback.
4. For an explicitly approved clean NOR seed, write/read/hash the confirmed
   APP mirror before publishing its journal. Publish the journal's final
   32-byte commit word last, after descriptor/body verification; do not treat
   an unordered whole-chip image write as a commit-last transaction.
5. Independently read back internal root/RFI2/APP, external APP/journal and
   options. Compare full hashes and compiled/factory profile/qualification
   bindings before releasing reset. A programmer's success message is not
   physical admission or commissioning evidence.
6. Run real native clock/IRQ/watchdog/supply/stop/transport tests, cold boot,
   interrupted reception/install/restore/journal/TRIAL/CONFIRM/EXIT tests and
   verified normal restart with empty mission/zero targets. Verify preserved
   NOR reserves and operation without the SD card. Record actual timing and
   power-cut results; host tests and the earlier reversible bench do not qualify
   production writes or startup.

No software option repair, automatic NOR reset, forced unlock, fabricated
physical feedback or automatic ARM is an acceptable fallback. This single-APP/
external-restore layout also needs its own approved requirement/acceptance
revision; baseline v3.1.0 section 17's internal A/B rules are not met by relabeling.

## ESP Update Baseline: Explicit Local USB Operation

First installation also requires an ESP durable update baseline. Missing keys
deliberately halt the updater; a network credential provision does not seed it.
The live sketch now accepts the following exact LF-terminated USB serial line:

```text
ROVER_UPDATE_BASELINE EMPTY_ONLY PHYSICALLY_INHIBITED
```

Only send it after an explicitly authorized first-install review with the rover
physically inhibited. The acknowledgement is an operator attestation, not a
measurement of physical inhibit. No automatic boot/HTTP operation invokes it.
USB parsing enqueues one request; the sole native updater task checks that its
startup store is EMPTY/halted, re-reads both actual NVS keys and writes/readbacks
the canonical sequence-1 IDLE baseline only if BOTH remain absent. Existing
unlocked history, locked history, malformed data and read uncertainty reject;
there is no erase, repair, replacement or automatic retry. Unrelated deployment
credentials remain untouched. Do not erase NVS to force this precondition.

Expect `UPDATE_BASELINE_PENDING`, followed by either
`UPDATE_BASELINE_OK_REBOOT_REQUIRED` or `UPDATE_BASELINE_REJECTED`.
Success does NOT clear this boot's sticky guard or enable ordinary work. Arrange
a separate approved reboot, then rediscover identity and peer state. The command
does not itself reset the ESP or STM. If no native updater task is running, a
pending reply is not evidence of a saved record. A lost USB reply is UNKNOWN:
review the NVS/readback offline; do not repeat/erase to manufacture success.

For local missing-measurement inventory before generating headers:

```sh
python3 tools/rover_upload_preflight.py config/commissioning --require-inputs
```

This uses the VG validators, reports all null input paths and never declares
deployment authorized. Its exit 2 means required initial STM inputs are invalid.
Even valid inputs still require reviewed compiled bindings, board-specific ESP
artifacts, complete backups, an approved installation plan and hardware tests.
