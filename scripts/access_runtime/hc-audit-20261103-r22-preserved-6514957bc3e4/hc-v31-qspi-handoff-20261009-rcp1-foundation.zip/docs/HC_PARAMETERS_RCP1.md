# HC paraméteradat-szerződés és roveroldali alapréteg — 2026-10-09

Állapot: implementált és tesztelt adat-/tárolási alapréteg, **nem kész éles
paraméteralkalmazási szolgáltatás**. `GET /api/v3/identity` most explicit
`runtime_parameters=false` capability-t ad. Hiányzó capability is unavailable;
a HC nem indíthat paramétermutációt, és nem találhat ki endpointot.

## Amit a HC AI már használhat

`config/rover_parameters.template.json` a szerkesztő teljes, 27 mezős mintája.
Csak a formátumverzió kitöltött, minden működési érték null: ezekből a felület
draftot készíthet, de érvényes vagy mért konfigurációt nem állíthat.
`tools/rover_parameters.py` a pontos mezőhalmaz, típusok, mértékegységek,
határok és keresztmezős ellenőrzések futtatható referenciája. Nincs `install`,
C-header-generálás, firmware-rebuild vagy hálózati írás ebben az eszközben.

```sh
python3 tools/rover_parameters.py schema
python3 tools/rover_parameters.py check draft.json
python3 tools/rover_parameters.py canonical draft.json
python3 tools/rover_parameters.py encode draft.json --output draft.rcp1
python3 tools/rover_parameters.py decode draft.rcp1
python3 tests/test_rover_parameters.py
```

Az encode kizárólag új fájlt hoz létre, meglévőt nem ír felül. A schema offline
JSON Schema 2020-12 kimenet; nem kell az internetes `$schema` címet letölteni.
A séma önmagában nem ellenőrzi a kvaternió normáját, a mechanikai/elektromos
késlimit kapcsolatát vagy a fizikai méréseket. A referencia ezenfelül szigorúan
egész számokat kér: bool, lebegőpontos `500.0`, NaN/Infinity nem számparaméter.
A JSON duplikált és ismeretlen kulcsai tiltottak.

Paraméternévben a mértékegység szerepel; pl. `max_linear_mm_s` mm/s,
`wheel_gear_ratio_milli` ezredarány, `imu_mount_q_ppm` egymilliós kvaternió.
Motorirány csak -1/+1. A robotazonosító 1..32 ASCII `[A-Za-z0-9_-]` karakter.
A tömbhosszak kötöttek. A teljes adatobjektumot validáljuk, nem részleges PATCH-et.
GPIO, UID, boardminősítés, `installed`, `commissioned` és VESC firmware nem
operátori paramétermező, beküldésük hibás adatnak számít.

## Bináris formátum

Az RCP1 kizárólag paraméteradat, **nem firmware-kép**, nem RFU2/RFI2 és nem
OTA-feltöltési test. Pontosan 256 byte, explicit little-endian, nem C struct.
A pontos offsetek a Python `SCALARS`/`ARRAYS` táblában és a production
`shared/rover_parameters.h` codecben azonosak; C11/C++11/Python byteazonossági
teszt ellenőrzi őket.

| Byte-offset | Tartalom |
| --- | --- |
| 0..7 | `RCP1`, uint16 verzió=1, uint16 hossz=256 |
| 8 | `blade_enabled` 0 vagy 1 |
| 12..44 | null-lezárt, nullokkal kitöltött robotazonosító |
| 48..151 | geometria, motorok, kalibráció, stop- és működési limitek |
| 252..255 | CRC32 a 0..251 byte felett |

A nem felsorolt byte-ok nullák. Dekódolás után teljes kanonikus újraenkódolás
és byte-összehasonlítás szükséges: javított CRC mellett is hibás a nem nulla
reserved byte, padding, érvénytelen verzió vagy adat. A CRC sérülésellenőrzés,
nem kriptográfiai hitelesítés. Lehet érvényes nulla CRC is; az adat jelenlétét
külön jelző adja. Ezt a CRC-t **nem** szabad a jelenlegi firmware-update
`profile_crc`/`X-Profile-CRC32` vagy a boot/factory profil CRC helyére tenni.

## Tartós roveroldali alapréteg

`shared/rover_configuration_store.h` RCF1 v1, 512-byte-os rekordot kezel.
Külön namespace `rover-config`, kulcsok `params0`/`params1`; adapter:
`tools/esp32_stm32_remote/rover_configuration_store.h`. Nem töröl/formáz,
nem ír deployment-, hitelesítési vagy firmware-update sessionkulcsot.
A réteg még nincs példányosítva az éles konfigurációs ownerben, így a
jelenlegi firmware nem kezdi magától írni ezeket a kulcsokat.

A rekord a paramétereken kívül monoton revisiont, expected_revisiont,
request_id-t, eredeti ESP/STM bootot, STM UID-t, board/installation CRC-t és
request control epochot hordoz. PREPARED után csak az azonos adathoz tartozó,
legfeljebb 1500 ms-os, aktuális élő peer sessionnel külön egyeztetett STM-bizonyíték
enged tartós commitot. A bizonyíték disarmed/stopped/inhibited állapotot és
manual/update kizárást követel. Ezeknek natív, eredeti mintavételű bizonyítéknak
kell lenniük: HTTP bodyból vagy új timestampből nem állíthatók elő.

A store `COMMITTED` eredménye csak visszaolvasott tartósság, **nem** STM live
`APPLIED`, nem mozgási engedély. A storage `locked()` sem helyettesíti az
élő STM gate-et. Az effektív controllerprofil-építő megőrzi a read-only board-
bekötést, de mindig visszavonja a `commissioned` bitet: adatmentés nem minősítés.

Új revision először az inaktív kulcsba kerül, az előző aktív rekord megmarad;
commit ugyanazon staging kulcson történik és teljes visszaolvasást követel.
Hiányzó, sérült, eltérő boardazonosságú, ellentmondó vagy bizonytalan rekord
nem javítható automatikusan. A PENDING reboot után is PENDING és zárt marad,
nem lesz csendben aktív vagy visszaállított. Bootváltás nem újítja meg a jobot.
Azonos request pontos replaye nem ír újra; eltérő tartalom ID_CONFLICT.

Ezek host modellel ellenőrzött tulajdonságok. Minden 0..511 byte utáni staging-
és commitmegszakítási eset tesztelt, de ez nem a valós NVS/hardveres power-cut
minősítés helyettesítése.

## Ami még kell az éles alkalmazáshoz

Az STM natív konfigurációs tranzakciója, a sole UART owner bekötése, a
hitelesített HTTP API, élő readback/UNKNOWN-egyeztetés, boot utáni restore,
controller/mission/heading/manual invalidálás és a factory/boot/OTA változatok
explicit kompatibilitási/migrációs kezelése még nincs bekötve. Nem lesz éles
apply attól, hogy egy NVS adapter és egy editor elkészült.

A fékezési/stop érték, geometria, motorirány és IMU-kalibráció módosításához
hozzájuk kötött mérési bizonyíték kell. A nagyobb stop-deceleration vagy
kisebb stop-idő nem tekinthető igazoltnak egy helyes JSON miatt. A board-inhibit,
feedback, watchdog/táp mérések és az ESP pontos flash/PSRAM-változata továbbra
is nyitott telepítési bemenetek.
