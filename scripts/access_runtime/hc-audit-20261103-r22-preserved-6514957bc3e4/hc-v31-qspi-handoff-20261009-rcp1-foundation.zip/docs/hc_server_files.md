# HC transfer manifest — 2026-10-09

Start with `HC_AI_ATADAS_20261009.md` at the handoff ZIP root, then
`docs/HC_PARAMETER_MANAGEMENT.md` and `docs/HC_V31_INTEGRATION_HANDOFF.md`.
Use the latest `hc-v31-qspi-handoff-20261009-rcp1-foundation.zip`; the earlier
archives are preserved and predate the implemented RCP1 draft codec/store core.
Read `docs/HC_PARAMETERS_RCP1.md`: no installed parameter apply endpoint exists,
and identity explicitly advertises `runtime_parameters=false`.
The ZIP includes the complete supplied
`ROVER_SYSTEM_SPEC_v3.1.0.md`, reference HTTP client, RFU1/RFU2 validators,
production format headers, empty templates and runnable reference tests.
The parameter editor can use `tools/rover_parameters.py schema/check/canonical`
and `config/rover_parameters.template.json` now, without rebuilding firmware.
Keep its relative directories when extracting. `MANIFEST.json` lists every
payload file's SHA-256 and length; it is an integrity list, not a signature.

Generate without device access or secret files:

```sh
python3 tools/rover_hc_handoff.py \
  --spec /home/a/Downloads/ROVER_SYSTEM_SPEC_v3.1.0.md \
  --output /tmp/hc-v31-qspi-handoff.zip
```

The live qualified VG HTTP/durable-session/RFU2/STM/ESP-OTA integration is
implemented. Default installations remain unqualified and capability-gated;
actual deployment/measurements/physical acceptance remain necessary.
VG/QSPI is an explicit alternate to baseline section 17's internal A/B layout.

The HC application is on the other machine and is not modified here.
Legacy `ROVER_HC_CONTRACT.md` and `docs/project_state.md` are historical v2,
not current contracts. Wi-Fi/MQTT/NTRIP/API credentials, deployment NVS,
device backups and measured board-private installation files are excluded.
Provision the authorized backend token separately.

The reference client supports explicit STM ABI1 A/B and ABI2 VG/RFU2 updates.
It does not implement the HC UI, an ESP OTA release UI, manual backend relay
or mission planner. Those are tasks for the other AI.
