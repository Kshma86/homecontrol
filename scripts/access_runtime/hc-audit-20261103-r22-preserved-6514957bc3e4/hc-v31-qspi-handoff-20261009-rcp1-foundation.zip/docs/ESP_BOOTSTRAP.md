# ESP startup without automatic NVS formatting

The pinned Arduino core 3.3.7 `initArduino()` formats the entire default NVS
partition after `ESP_ERR_NVS_NO_FREE_PAGES` or `ESP_ERR_NVS_NEW_VERSION_FOUND`.
Rejecting OTA hooks and a later `setup()` check cannot prevent that branch.
The rover supplies `src/rover_esp_bootstrap.cpp` as a GNU-wrapped startup entry,
without modifying the installed Arduino core or SDK.

## Required linker configuration

The final application link must include `-Wl,--wrap=initArduino`. For the pinned
Arduino platform this belongs in `compiler.c.elf.extra_flags`, not `build_opt.h`:
the latter only supplies compilation flags. Preserve any other required linker
flags when adding this property. For example, with the actual commissioned board
configuration in `ROVER_FQBN` and an explicit build directory:

```sh
bash tools/build_esp.sh "$ROVER_FQBN" /tmp/rover-esp-reviewed-build
```

The helper also preserves the original sketch/src include roots: Arduino copies
those files to its build tree, where unadjusted relative shared includes fail.
It runs the pinned SDK checks and preserves `ROVER_EXTRA_COMPILE_FLAGS` and
`ROVER_EXTRA_LINK_FLAGS`. `ARDUINO_CLI`, `ARDUINO_CONFIG_FILE` and
`ARDUINO_LIBRARIES_DIR` can select an already installed isolated tool environment.
It does not explicitly install packages; initialize the CLI/dependencies before
an offline build, since Arduino itself may fetch absent builtin tools.

This command is a build recipe, not an installation or upload instruction. No
board/flash/PSRAM/partition configuration is inferred from the generic SDK syntax
check. Compile all sketch `src/` units. A retained volatile `__real_initArduino`
pointer in the setup readiness gate deliberately makes a missing linker flag
fail the link. GNU wrapping resolves that pointer to the original core function;
the rover never calls it. Native calls from Arduino's separate startup unit are
redirected to `__wrap_initArduino`.

## Startup policy

- Capture the native timer at wrapped entry and audit actual running OTA state
  before NVS initialization. Factory, UNDEFINED and VALID permit the existing
  development startup, not an OTA trial confirmation or motion permission.
- Reject missing/unknown/new/invalid/aborted image state without attempting NVS
  or ordinary platform startup. Unqualified PENDING yields one supported SDK
  rollback request when compiled in. Any return remains closed; no mark-valid
  operation is performed by bootstrap.
- Qualified PENDING must match the installed profile and actual equal OTA
  partition addresses/sizes. Before storage initialization, subscribe a native
  TWDT user with a commissioned reset bound. It is not tied to the temporary
  `app_main` task and receives no initialization feed. The updater later adopts
  this same handle once, rather than adding a fresh watchdog lifetime.
- After NVS success, independently load the exact canonical locked ESP TRIAL
  with an accepted image and matching profile, before platform initialization.
  Missing/corrupt/wrong records, watchdog failure or native timer >=10 seconds
  request rollback once and stay closed on return. No ordinary tasks run.
- Call supported `nvs_flash_init()` once. Preserve its exact signed error code.
  Every nonzero result blocks startup; neither of the core's formatting-trigger
  errors gets an erase, retry, repair, key generation or provisioning fallback.
- After NVS success, perform the pinned core's optional manual PSRAM heap setup,
  log configuration, optional unused BT memory release, `init()` and
  `initVariant()`. A failed manual PSRAM initialization also blocks startup.
- `setup()` first checks the retained bootstrap result, before boot entropy,
  deployment loading, UART/sensor/network/tasks and USB provisioning. On failure
  only a USB diagnostic is attempted; the absent boot identity inhibits `loop()`.
  Reentry cannot repeat storage/platform work or turn failure into readiness.

`shared/rover_esp_bootstrap.h` expresses this once-only policy in C11/C++11. Its
ports deliberately have no erase, format, retry or confirmation operation.
`CONFIG_NVS_ENCRYPTION=1` is a compile error until an existing-key-only native
adapter is commissioned: the default SDK path must not implicitly generate keys.

## Evidence and remaining work

Host tests link the actual wrapper and a separate Arduino caller with GNU
wrapping. They inject both formatting-trigger errors, other storage failures,
native OTA uncertainty, compiled rollback on/off and manual PSRAM failure. The
original core entry must never execute, and repeated entry must never retry.
The final ELF checker requires strong executable wrapper/readiness symbols in
addition to the descriptor and rejecting OTA hooks. The synthetic Xtensa fixture
links the real wrapper against native-header SDK stubs; missing wrapping and
encrypted NVS fail the real toolchain build. It is not a deployable sketch or a
hardware startup test. SDK syntax/object checks compile with PSRAM disabled and
enabled; ARM C/C++ checks validate the portable policy.
An additional qualified-bootstrap fixture executes the real wrapper against
locally generated test-only installation headers, covering eight success/fault
paths, watchdog-before-NVS ordering and initialization consuming the deadline.
It never changes the checked-in unqualified production header.

The 2026-10-09 complete generic ESP32-S3 sketch links also contain the strong
boot hooks and wrapper and pass exact ELF/image regeneration, with PSRAM off
and QSPI PSRAM on. The helper's original include roots are necessary under
Arduino's copied build tree. The ELF checker recognizes only the pinned SDK's
exact `.ext_ram.dummy` NOLOAD reservation geometry, not arbitrary overlapping
data/BSS sections. Optional full-sketch regression corrupts that actual section
and rejects wrong flags/type/address/length/alignment before esptool is invoked.
Neither generic build establishes the connected board's measured configuration.

This removes the whole-partition formatting fallback from the configured rover
startup path. It does not establish that supported SDK NVS initialization never
writes flash, has bounded latency, or preserves commissioned data through every
power cut. Actual board-specific full linking, startup ordering, NVS/PSRAM
behavior, watchdog and rollback must still be verified on target. Qualified
TRIAL uses native ESP timer epoch zero, conservatively including time before
`app_main`; late setup, task adoption or peer discovery cannot restart it.
The [live ESP owner](NATIVE_ESP_UPDATE_OWNER.md) now performs bounded full-image
verification and independently gated confirmation after restricted startup.
No formatting/provisioning fallback or automatic ordinary release was added.
Unqualified ESP updates remain closed, conformance/capabilities remain false,
and missing measured installation data still prevents motion.
