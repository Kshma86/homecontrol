# VG / QSPI Update Runtime

Status: actual native VG loader and operational APP builds, transactional storage,
native physical admission, locked TRIAL/confirmation, operational maintenance,
guarded EXIT/reset, live authenticated ESP RFU2 coordination, ESP OTA/TRIAL
coexistence, linked ELF audits and offline first-install bundle preparation.
**Not deployed or commissioned.** The checked-in measured headers remain zero,
so the production sketch keeps STM remote update unavailable and reports ABI1
compatibility metadata until a reviewed VG installation is generated.

The experimentally chosen layout is `H743_1M_QSPI_REC2`, RFU2, service ABI2.
It changes specification 3.1.0 section 17's internal A/B and external-storage
independence requirements. Conformance remains false; STM remote-update is published true only when the
generated VG loader/profile commission passes the ESP-side immutable gate.
The board's earlier reversible W25Q64JV bench result does not qualify this runtime.

## Implemented Components

| Component | Responsibility |
| --- | --- |
| `recovery/rover_qspi_update.c` | Sole transaction/boot policy owner; real pinned SHA-256; bounded reception, installation, restoration and reset reconciliation |
| `shared/rover_qspi_storage.h` | Commit-last two-bank journal, blank-only local bootstrap, bounded W25Q64 writes and readback |
| `recovery/rover_qspi_mutation.c` | Native HAL 1-1-1 transport; exactly the current worker's WREN / page program / sector erase; native observer required |
| `recovery/rover_vg_flash.c` | Async register-level bank-2 APP erase/program; exact owner/data/generation, hardware/protection/supply/placement checks and sliced readback |
| `recovery/rover_qspi_service.c` | ABI2 command owner, serialized jobs, frozen retries, current journal/epoch binding, truthful delayed ACK and durable job result |
| `shared/rover_qspi_client.h` | ESP-side frozen request/retry/reply codec owner, epoch and progress checks; no private UART reader or slot selection |
| `shared/rover_qspi_wire.h` | Compact canonical uppercase-hex envelope fitting the existing 512-byte line parser; full binary ABI2 CRC remains authoritative |
| `recovery/rover_qspi_uart.c` | Exclusive VG UART mode reusing existing native RX/TX helpers; immutable replies, physical TX completion, residence/gap/error fences and terminal park |
| `recovery/rover_qspi_worker.c` | Qualified native loader scheduler: one storage slice per millisecond, guarded watchdog feed, final-ACK-before-TRIAL/EXIT, normal listen window and terminal branch/reset |
| `recovery/rover_qspi_trial_worker.c`, `rover_qspi_trial_placement.c` | Separate locked APP scheduler; readonly journal/internal-image verification, qualified feed, physical final CONFIRM ACK/drain, terminal UART park and guarded TRIAL_OK software reset |
| `tools/esp32_stm32_remote/rover_qspi_link.h` | Existing ESP UART-owner adapter for frozen partial TX, hardware drain, canonical discovery, retry, stale epoch/source and terminal failures |
| `tools/esp32_stm32_remote/rover_qspi_update_owner.h` | Durable live RFU2 owner: full-body SHA/header proof, ABI2 transfer, TRIAL/CONFIRM/RESTORE/EXIT and retained-reset reconciliation |
| `tools/esp32_stm32_remote/rover_update_live_http.h`, `rover_update_worker.h` | Authenticated bounded HTTP/body handoff and layout-specific native-owner dispatch; no HTTP-task UART/NVS access |
| `recovery/rover_qspi_entry.c`, `qspi_vector_branch.S` | Guarded, one-shot native capsule publication and masked APP reset entry; no default admission |
| `Core/Src/rover_qspi_app_entry.c` | Separate RTE2 pre-RAM flash probe and mandatory native early APP owner; uninstalled builds fail closed |
| `Core/Src/rover_qspi_firmware_header.c` | Separate target/profile-bound RFU2 embedded header, not a patched RFU1 image |
| `tools/rover_qspi_image.py` | Exact padding, RTE2 validation and ARM ELF / section / load-byte / RAM-initialization audits before packaging |
| `recovery/qspi/main.c`, `recovery/rover_qspi_platform.c` | Actual immutable-root scheduler and native factory/physical/storage/UART/watchdog/terminal composition |
| `recovery/rover_qspi_physical_capsule.c` | One-shot 796-byte physical handoff at 0x38000080, bound to the canonical boot grant and current native evidence |
| `Core/Src/rover_qspi_app_admit.c`, `rover_qspi_app_vectors.S` | Actual early APP admission, sole SRAM IRQ owners, locked TRIAL loop and verified ordinary-main transfer |
| `Core/Src/rover_qspi_maintenance_boot.c`, `rover_app_maintenance.c` | Readonly VG metadata/image preflight and actual operational stop/park/ENTER_UPDATE reset |
| `tools/check_qspi_runtime.py` | Actual linked native owner, vector, startup, load-region, arena, capsule and stack audits |
| `tools/rover_qspi_provision.py` | Offline-only measured/ELF-bound root/RFI2/APP/initial-NOR bundle and review manifest; no hardware operation |

`recovery/qspi/CMakeLists.txt` builds the actual native loader, an ARM component
library and APP entry objects. The root project explicitly selects the actual
APP with `-DROVER_STM_SLOT=QSPI`; see `recovery/qspi/README.md` for commands.
The native images are uncommissioned by default, not deployment authorization.
The optional `qspi_app_layout_fixture` is a **nondeployable test fixture**, not
the rover APP. Its positive ELF audit proves format/layout, not native admission.
The package audit also binds native RAM boundary symbols, checks the 16-KiB stack
reserve, permits initialized RAM only inside the verified startup copy span,
permits zeroed storage only inside the verified BSS span, and rejects overlapping
allocated sections. The separate NOLOAD capsule reservation must be preserved at
0x38000000; it cannot become copied or zeroed application storage. All allocated
sections, including NOLOAD reservations, must have exactly one PT_LOAD owner.

## Transaction Sequence

1. On every loader reset, completely scan both journals. Unreadable data or
   conflicting sequences never authorize a boot or mutation. An empty journal
   can be initialized only through separately admitted local commissioning.
   A torn/nonempty journal cannot be silently initialized.
   An unlocked CONFIRMED journal plus a valid original ENTER_UPDATE reset first
   requires fresh native maintenance admission and a full internal APP hash.
   Commit locked CONFIRMED / job NONE with the captured update ID before
   accepting BEGIN; only that ID may open this maintenance session. A reset
   preserves the lock and cannot silently resume ordinary operation.
2. BEGIN chooses a store different from both `confirmed` and `previous`.
   Commit locked RECEIVING before erasing that store. Preserve the confirmed
   external backup and previous image. Erase only the rounded candidate extent.
3. DATA accepts sequential 32-byte-aligned chunks of at most 128 bytes. Copy
   into the worker, program, read back, then advance/ACK `received`. There is no
   speculative progress ACK or assumed offset recovery after reset.
4. END independently hashes the complete NOR image, checks its RFU2 header,
   profile, firmware token and RTE2 descriptor, then durably commits STAGED.
5. INSTALL freshly verifies the candidate and the current confirmed NOR backup.
   Only then commit INSTALLING, erase the four internal APP sectors, and copy
   through owned 32-byte words. Never erase/program root, factory or the flash gap.
6. Hash and validate the entire internal readback. Commit TRIAL_PENDING.
   Before starting the APP, recheck the internal image and commit TRIAL_ATTEMPTED
   with exactly one attempt. An ACK/boot grant requires a complete post-write
   journal scan. Branch to the image's **Reset_Handler**, not its C entry probe.
7. The APP validates the RTE2 native entry capsule before using copied C storage.
   The startup assembly verifies RAM copy/zero before the mandatory SRAM early
   owner is called. TRIAL must stay in its inhibited service loop, never return
   into operational `main`. It has a nonextendible ten-second deadline.
8. Healthy TRIAL can construct `TRIAL_OK` only with independently admitted local
   health proof. It cannot write CONFIRMED. The implemented APP trial worker waits
   for the exact successful CONFIRM reply's physical completion/drain, stops
   feeding, parks UART, rechecks native health at each publication checkpoint,
   publishes through the guarded RTC BKP0..15 owner and requests a software reset.
9. The loader captures and clears the RTC marker and original reset causes once.
   Only a matching update ID / SHA, valid original software-reset capture and
   independent native CONFIRM admission can proceed. Rehash internal candidate,
   commit CONFIRMED with `job_result=COMPLETE`, rotate old confirmed to `previous`,
   clear candidate, and keep lock. Invalid/missing handoff restores instead.
10. Failed TRIAL commits RESTORING, verifies the confirmed NOR source, actually
    copies it back into the sole internal APP, verifies readback and commits
    locked CONFIRMED / ROLLED_BACK. No selector flip is used as a restoration.
11. EXIT requires explicit peer major 3 / minor 1 / installed-profile agreement
    and independent native finish admission, freshly
    verifies the confirmed APP and durably clears the lock. It produces **no
    same-session normal boot grant**. A deliberate reset must rescan/rehash and
    obtain fresh normal-entry admission. EXIT never arms the rover.

An interrupted INSTALLING or RESTORING operation starts verification and a full
copy again from its still-owned NOR source. A interrupted RECEIVING session
reports INTERRUPTED, refuses DATA/END continuation, and needs a complete new
transfer with a fresh update ID. Incomplete or corrupt internal bytes are never
granted a boot. A failed journal callback may have physically committed its
record: report reset/reconciliation required, never success or automatic replay.

Journal byte 52 now stores `RqJobResult`; bytes 56..63 remain reserved zero.
Earlier foundation records with zero at byte 52 still mean `RQ_JOB_NONE`.
CRC covers metadata integrity only; it is not image verification or authentication.

## Native Admission

`RqUpdateIo.authorize` is not an HTTP/HC flag. Each permission requires the
independently owned, fresh native evidence for its role and exact journal / job /
boot generation. APP_ENTRY proves actual loader entry; TRIAL_HEALTH proves the
local RAM, scheduler, watchdog, service UART and inhibition tests; CONFIRM proves
the one-shot original reset capture, not an external CONFIRM command.

The storage observers additionally prove supply, stopping/output inhibition,
exclusive bus ownership, code/IRQ/data residency and watchdog admission. The
internal driver validates actual 1024-KiB density, device 0x450 / revision 0x2003,
unchanged clock/power/option registers, caches off, an unswapped map, protected
physical bank 1 (`WPSN_CUR1=F0`) and writable bank 2 (`WPSN_CUR2=FF`).
It unlocks only KEYR2. Begin never busy-polls a sector erase. Completion relocks
the bank and checks the entire erased sector in 128-byte slices or the exact
programmed word. Unknown completion, authority loss, ECC/errors and deadline
expiry quarantine the operation; no unlock/reset/retry fallback is guessed.

The actual board last measured `SWAP_BANK=1` and no sector WRP. Those conditions
**do not satisfy the implemented native admission**. No code here changes option
bytes. Local root provisioning, protection and an explicitly reviewed bank map
are separate operations requiring verified artifacts and retained backups.

Native entry admission must also prove UART TX/RX drained and parked, DMA and
peripherals quiescent, native RAM initialization and a current watchdog handoff.
The marker is written last and read back. Early entry rejects malformed/old
capsules, wrong CPU/VTOR context, profile, tokens or a stale DWT deadline.
`rover_qspi_app_admit` is supplied by the real QSPI APP, with no weak positive
fallback; it composes the independently qualified service/physical owner.
Preserve the loader timebase through
APP entry. Capsule revision **3**, still 128 bytes, additionally seals the actual
masked publication tick at byte 108, separately from the original grant/deadline
tick at byte 40. The early APP entry reconstructs `uwTick` conservatively from
that publication tick and validated DWT elapsed time before native admission.
The pre-RAM probe retains its 2-ms handoff limit; RAM copy/zero and verification
must finish within the separate 20-ms startup limit. The ten-second trial budget
still begins at the original grant. Old revision-2 capsules are rejected even
with a valid CRC. Do not reset DWT, watchdog or the trial deadline during entry.

If NOR WEL/BUSY or write completion is unknown, a new MCU reset alone is not proof
that the external chip is idle. Use the read-only startup probe and remain
inhibited when it rejects the session. No WRDI, NOR reset, protection/QE write,
mass erase or status-register repair is introduced as an automatic fallback.

## ABI2 Transport Contract

`RQS2` is a fixed 320-byte canonical LE request with ABI/layout 2, 64-bit native
service generation and expected journal sequence, monotonic nonzero request ID,
update ID, image descriptor/chunk and CRC. `RQR2` is a 128-byte canonical reply.
Commands: STATUS, BEGIN, DATA, END, INSTALL, TRIAL, CONFIRM, EXIT, RESTORE.
Commissioning/bootstrap is intentionally not remotely exposed.
BEGIN carries an image offer with store NONE: only the loader selects a free NOR
store. The remote client cannot choose an internal slot or external store.
Discovery can use an unsolicited canonical STATUS reply with request ID zero;
the native loader worker emits it before the first request, and the ESP wire
adapter binds that fresh native generation before starting a request. A service
generation is an epoch, not an authentication secret.
Reply byte 116 holds the role (`0=LOADER`, `1=APP_TRIAL`); bytes 120..123 are still
zero capability/conformance fields. Each APP trial service requires a fresh native
RNG epoch distinct from the loader's epoch. Storage/capsule ownership retains the
original loader generation, while UART request/reply replay binds the new APP
epoch and role. The ESP adapter pins both and fails on unsolicited changes.
Rebinding across deliberate boot/reset belongs to the authenticated coordinator,
not an automatic transport fallback.

EXIT carries explicit peer major/minor as little-endian u16 at request bytes
276/278 and profile CRC as u32 at byte 280. All other commands require those
bytes zero; bytes 284..315 remain reserved zero. Native STM verifies these
values against the installed profile and operational 3.1. The ESP coordinator
must independently verify its own confirmed APP before sending them. EXIT has
no GNSS/IMU navigation-readiness prerequisite and does not grant motion.

The server owns at most one pending request. Same ID plus exact frame retries
observe the same result; changed payload or stale epoch/sequence is rejected.
Replies carry actual committed state/job result, local byte progress, lock and
error. Capability/conformance bytes remain zero. An untrusted journal reports
unknown/error and locked, never a fabricated unlocked installation.

This codec is **not an alternate UART reader**. The VG transport exclusively
owns the existing native RX/TX helpers; never run it alongside the old loader or
operational UART owner on the same peripheral. The ESP authenticated HTTP
coordinator selects the distinct VG/APP layout only from the reviewed installed
loader/profile headers. It does not feed RQS2 through ABI1 JSON service or
translate APP/store identities into A/B.
CRC/epoch values do not replace authentication or native stopping proof.

### Line Envelope

`RQ2Q:` is followed by uppercase hex of binary request bytes 0..55, then only
the command's descriptor (BEGIN, bytes 56..147), DATA bytes (148 onward, exactly
the declared length), or EXIT compatibility (bytes 276..283), then the original
binary CRC bytes 316..319 and LF. Other
command payloads and reserved bytes are reconstructed as zero and validated by
the full binary codec. The longest request is 382 bytes including LF. `RQ2R:`
contains all 128 reply bytes in uppercase hex and LF, exactly 262 bytes. Complete
line decoders receive the existing parser's normalized line without LF. There
is no new raw-binary parser, escaped delimiter or enlarged frame budget.

The ESP adapter must run on the existing bridge/UART owner after its independently
proved native exclusive barrier. HTTP/update tasks cannot call it concurrently;
they must use the existing copied work/result handoff. It writes at most 128 bytes
per call, advances only by actual driver acceptance and acknowledges a reply only
after the whole frozen frame has physically drained. Unknown/partial TX, lost
ownership, stale clock/source or a changed STM epoch latch failure; there is no
implicit reopening, replay-watermark reset, queue flush or operational resume.

`RoverQspiLink::expectReset` accepts only the completed canonical TRIAL, CONFIRM
or EXIT ACK after actual local TX drain and current exclusive ownership. TRIAL
binds the next fresh APP_TRIAL epoch/ID/sequence; CONFIRM binds the next loader's
locked CONFIRMED / COMPLETE result. A fresh locked ROLLED_BACK loader after a
failed trial is observable as rollback, never installation success. The adapter's
ten-second window starts at the original TRIAL ACK acquisition and covers both
transitions without renewal. The STM's earlier native grant deadline remains
independently authoritative; wire timing cannot extend it. Epochs
must never repeat across the four observed sessions of one complete update.
EXIT binds a fresh loader epoch with the exact already-committed sequence,
unchanged job result, zero update ID and unlocked CONFIRMED state, within ten
seconds of the original ACK. `exitResetVerified(now)` requires current evidence;
it proves only loader journal reconciliation, not normal APP startup. The link
then refuses further mutations. Only the separate ordinary restart gate can
admit a new compatible APP boot and EMPTY/zero-target state.

The actual ESP sketch recognizes fresh valid `RQ2R` through its existing sole
parser. With a qualified VG header it copies complete replies into a fixed,
bounded mailbox consumed only by the updater task; without that header it keeps
the former permanent incompatibility fence. Reserved RQ2-prefixed lines never
fall through to ordinary dispatch. The updater task alone drives the ABI2 link
after the ordinary UART owner, queued ABI1 transport and hardware TX are drained.

### Native Loader Scheduler

Start the VG transport before update scanning/verification, then bind the worker
with reviewed watchdog qualification and the independent native physical/storage
observer. Missing qualification never starts a feed loop. The worker checks RAM
placement, core/UART vector residency, permitted IRQs, stopped/inhibited supply,
root protection, clock/DWT and actual watchdog configuration each cycle. It runs
at most one core storage slice per millisecond, fences a 2-ms cycle / 20-ms service
interval, and feeds only after both service and UART completion remain current.
These software bounds are not measured WCET or installation evidence.

Normal boot waits for the original two-second listen window and refuses any
observed well-formed mutation intent. A normal boot grant is still one-shot and
expires after two seconds; an already expired grant cannot be refreshed by the
transport. TRIAL and EXIT require the exact final successful response's actual
TX completion and canonical current journal state. The worker then stops feeds,
parks RX/TX and waits for UART UE/TEACK/REACK shutdown. TRIAL consumes the grant
and invokes native RTE2 entry; EXIT clears the old RTC marker and requests a native
software reset, never a same-session normal branch. Terminal failure stays masked.
The original deadlines also include DWT elapsed time while SysTick is masked.

The loader worker deliberately refuses APP trial mode. The implemented separate
APP trial worker starts with the original sealed grant/clock and the APP service's
fresh epoch. It only scans/hashes; all public core mutation methods explicitly
refuse APP trial mode, independently of a permissive callback. APP service exposes
STATUS and guarded CONFIRM preparation only, never BEGIN/DATA/END/INSTALL/TRIAL/
RESTORE/EXIT. The client rejects commands and replies inconsistent with this role.

APP CONFIRM `OK` means **prepared for guarded reset**, not durable confirmation:
the reply remains locked `TRIAL_ATTEMPTED`, `BOOT_READY`, `job_result=NONE`.
Only the new loader session can subsequently report `CONFIRMED / COMPLETE`.
After the exact final ACK drains, the APP worker stops feeds, parks the UART and
checks journal, ID/hash, original deadlines, placement, supply, stop proof,
watchdog and native reset causes again. Failure stays masked without publication;
a publication failure clears the marker. An unexpectedly returning reset clears
the success marker and halts. TRIAL never returns to operational main.
The real APP early owner composes this worker with the native board/service
admission and sole HAL callbacks; no admission is invented.

The client retries a frozen request every 500 ms, expires source freshness after
2000 ms and has a hard 120-second request deadline. Pending replies cannot extend
the hard deadline. The STM worker separately bounds reception inactivity to ten
seconds, total transfer to 900 seconds, initial receive preparation to 90 seconds,
image verification to ten seconds, internal copy to 90 seconds, journal commit to
120 seconds, and APP trial to ten seconds. Boot grants are one-shot and expire
after two seconds. These are software deadlines, not measured WCET claims.

## Remaining Deployment Work

- Reviewed local provisioning of root/factory/bank map/WRP, immutable backups,
  native flash/NOR mutation and power-cut tests on this board, then commissioning.
- Measured profile, inhibit/feedback, watchdog, supply and timing inputs. The
  software never substitutes fixture values for these records.
- Full device qualification of RFU2 transfer, cuts at each durable transition,
  failed TRIAL/rollback, RESTORE, EXIT and the final ordinary ESP reboot.
  HC remains on the separate machine covered by its existing handoff.

Do not turn the installed-loader/profile/CAN/OTA flags positive merely because
the component tests or the earlier reversible QSPI bench passed.

## Verification

`make -C tests ... check` includes the new C and C++ transaction, native QSPI and
native VG-flash tests. They exercise reception, real SHA, retained backup,
installation, single trial, APP-to-loader reset confirmation, finish/reset,
restoration, all 48 word-copy interruption points in the small integration
fixture and all four internal erase interruption points. Storage tests cover
every partial successor byte and rollover erase boundary separately. They also
cover lost/invalid reset proof, wrong epoch/data/authority, marker corruption,
timeouts, protection, uncertain commit completion and fixed-frame retries.

ASan/UBSan checks and an ARM SDK component build supplement host tests. They do
not execute a real sector erase, native branch, APP scheduler or ESP reboot on
hardware. The prior VI A/B/recovery ELF audits remain regression checks only.

On 2026-10-08 the unrestricted full suite passed 154 native executions and 176
Python methods. All 14 QSPI native C/C++ executables passed ASan/UBSan. With
`ROVER_QSPI_LAYOUT_FIXTURE=ON`, CTest's `qspi_arm_elf_audit` additionally passed ten
methods using the actual ARM fixture and corrupted ELF/body pairs. Subsequent
stricter RAM/capsule packaging checks and foundation image/bench tests passed.
No hardware write or option-byte change occurred in this implementation turn.

The subsequent native UART/loader scheduler/ESP wire continuation passed the full
157-native / 176-Python regression, new STM C/C++ runtime and ESP link ASan/UBSan
tests, and the changed startup compatibility gate under ASan/UBSan. The ARM SDK
components and ten ARM-ELF fixture methods pass. The pinned Xtensa check compiles
the actual sketch, the QSPI link caller fixture and existing SDK/startup/OTA gates.
These checks remain software/mock/object evidence, not deployed VG qualification.

On 2026-10-09 the live ESP continuation added the durable layout discriminator,
RFU2 HTTP contract (`H743_1M_QSPI_REC2` / `APP`), fixed-mailbox RQ2 routing,
full BEGIN/DATA/END/INSTALL/TRIAL/CONFIRM/RESTORE/EXIT ownership, retained
`EXITING` recovery, ESP OTA coexistence, capability publication and a clean
post-APP-proof ESP reboot. The actual ESP sketch syntax check and full host suite
pass with the installed VG/profile headers still zero.

The final integration audit additionally moves QSPI TX into a fixed 128-byte
copy handoff serviced only by the bridge's native UART owner. Original physical
drain evidence expires at 50 ms; partial frames and lost ownership fail closed.
Idle loader STATUS keeps ESP OTA/TRIAL peer proof current without renewing the
original RX timestamp. A retained STM TRIAL may reconcile completed/rolled-back
loader evidence, but an already running APP trial with a lost original timer can
only await rollback, never CONFIRM under a newly invented deadline. Interrupted
HTTP or lost-RAM restoration reports ERROR/INTERRUPTED; explicit user ABORT
reports ABORTED/CANCELLED. Repeated latched failures do not repeatedly write NVS.
Wire-entry and EXIT waits use bounded, actual transition times.

The frozen RQ2 maintenance protocol has no independent STOP command. Ordinary
STOP remains available before the exclusive protocol switch. During RQ2 service,
the STM's continuously checked physical inhibition remains mandatory; HTTP STOP
returns 503/NOT_READY rather than falsely accepting an ABI1 frame on a suspended
transport. It never aborts the firmware job or substitutes for physical stop proof.

Regression cases cover the copied TX owner, acquisition age, idle keepalive,
lost ESP TRIAL clock, recovered completed/rolled-back jobs, interrupted and
explicitly cancelled restoration, late update entry and idempotent error writes.
The owner/link/handoff checks also pass ASan/UBSan; full suite and pinned Xtensa
checks remain software evidence, not hardware qualification.

The final 2026-10-09 Release build links the actual Cortex-M7 loader and QSPI
APP with GCC 14.3.1. The loader uses 100672 bytes of flash and 232256 bytes of
RAM; the APP uses 167812 bytes of flash and 419648 bytes of RAM_D1. The packaged
167840-byte uncommissioned RFU2 body has SHA-256
`c271f71cb2b6bcf715d6954df74616a28c2c57d1f50abaa0467e37f3e0443d73`;
the linked runtime ELF audit passes. This hash identifies only the zero-profile
verification build and must not be approved or installed as a commissioned image.

Full ESP links also pass for two explicitly chosen **verification-only** generic
ESP32-S3 configurations: Arduino 3.3.7, qio, 8-MB flash, `default_8MB`
partitions, PSRAM disabled / QSPI PSRAM enabled. The complete image sizes are
1352688 / 1355568 bytes; static RAM is 250396 / 250480 bytes (76%). Both retain
profile `00000000`, no reviewed board configuration and disabled installation
capabilities. They are not deployment artifacts. Their strong bootstrap/OTA
hooks, descriptor placement, entire ELF and exact esptool-5.1.0 regenerated
images pass inspection. The RFE1 ESP descriptor's frozen service ABI remains 1;
this does not reinterpret the separately selected STM ABI2/RFU2 layout.

The helper performs no upload and requires explicit board/build arguments:

```sh
bash tools/build_esp.sh "$ROVER_FQBN" /tmp/rover-esp-reviewed-build
python3 tools/rover_esp_image.py inspect \
  /tmp/rover-esp-reviewed-build/esp32_stm32_remote.ino.bin \
  --elf /tmp/rover-esp-reviewed-build/esp32_stm32_remote.ino.elf \
  --capacity <reviewed-inactive-OTA-capacity-bytes>
```

`inspect` validates the artifact, not the installed profile or release authority.
Use the existing `check`/`package` workflow with measured profile and independently
approved firmware/hash before any deployment. The optional full-sketch regression
uses `ROVER_ESP_FULL_LINK_DIR` and mandatory `ROVER_ESP_FULL_LINK_CAPACITY` when
running `python3 tests/test_rover_esp_image.py`; it also rejects eight actual SDK
reservation corruptions. No generic flash/PSRAM setting may be copied into a
measured installation record. Heap/stack headroom and scheduling remain target
acceptance items despite the successful links.

The locked APP continuation additionally covers exact final-ACK-before-reset,
fresh role/epoch binding, readonly APP ownership, denied premature health,
sixteen terminal/health/publication/clock/identity fault cases, conservative
capsule clock restoration and rejection of old capsules. Maximum-size C/C++
regressions exercise a complete 524288-byte receive/install/TRIAL/confirm and
restoration, including an initially empty journal and untouched reserved NOR.
These use simulated storage/physical observations, not measured write throughput,
power-cut recovery or a real deployed APP.
The final complete regression passes **159 native executions and 176 Python
methods**. All thirteen affected runtime/update/native-port/link/capacity
executables pass ASan/UBSan. The real Cortex-M7 component/object build, ten ARM
fixture audit methods and pinned Xtensa sketch/adapter checks also pass.

## RFI2 Factory / Native Physical Admission

VG provisioning uses a separate `RFI2` header and exactly 32768 bytes at
`0x08078000`. The 16-byte header contains magic, JSON length, JSON CRC32 and
layout ID 2. The JSON retains the exact profile/installation schema, but requires
STM32H743VG / 1048576 flash bytes / reviewed revision 0x2003. The canonical JSON
is at most 16384 bytes; every remaining byte must be erased. RFI1, a wrong layout,
bad CRC, noncanonical JSON, pin conflicts, incorrect UID/mapping/protection and
read failures are rejected. VI defaults still require their original 2-MiB
model/record/protection; they are not reinterpreted as VG.

Native VG identity requires an unswapped bank map and exact root/factory WRP
coverage (WPSN1 low byte F0, WPSN2 low byte FF). The record shares the protected
bank-1 root sector; it is never remotely erased. The native ECC reader now uses
VG-specific spans and rejects the `0x08080000..0x080FFFFF` hole and addresses past
the 512-KiB APP, including during armed BusFault recovery.

`rover_qspi_factory_boot` scans at most 128 bytes per step, then decodes using the
pinned fixed arena with a 20-ms service bound, then starts the native ADC3/VREF
and asserted GPIO inhibit path. Admission waits for actual feedback and the
recorded coast/disable interval. Subsequent physical cycles are bounded by 2 ms;
sample freshness is verified by the native producer. The generated VG flash and
watchdog qualifications are returned only after native physical admission.
Supply observations keep the original ADC acquisition time and the fixed loader
generation. Failures revoke qualification and poison the physical producer;
they never release inhibition. The module does not feed IWDG, mutate flash or
grant an APP entry on its own. The actual native platform composes it with the
qualified writers/UART/worker and terminal observers.

The separate `shared/rover_installed_qspi_loader.h` remains zero. Host tools use
explicit `--layout H743_1M_QSPI_REC2`; the qualification tool refuses to reuse a VI
CAN-only qualification. No measured/profile/installation values are synthesized.

SD remains optional for later archives; this boot/update owner has no SD dependency.

## Actual Native APP Maintenance And Offline Provisioning

Normal early APP entry uses readonly journal/internal-image verification and
seeds its maintenance preflight only after native admission. It stores the exact
best record location, not the last occupied page (which may contain a torn write).
Before maintenance, the real owner probes the native Winbond again, scans both
journals, compares the canonical trusted record, and hashes the full linked APP.
At terminal reset it rechecks the frozen record and original transport/physical
evidence. No APP-side NOR/internal mutation helper is used. Existing ordinary
mission/manual/checkpoint revocation, fresh stopping proof and CAN/UART parking
remain mandatory; no normal-state or motion permission is synthesized.

The loader owns an explicit BSS factory arena; the APP carries no copy of that
large arena. The actual native linked audits enforce initialized residency and
16-KiB stack/capsule reservations, including the loader's initial CPSID, copy/zero
instructions and checked VTOR/SRAM-main branch. They reject linked ABI1 mutation
owners. These audits are software evidence, not timing or hardware acceptance.

[QSPI_PROVISIONING.md](QSPI_PROVISIONING.md) documents the new offline-only
bundle tool. It binds the complete compiled profile and VG qualification in
both actual ELF files, RFU2 body/hash/firmware and a validated RFI2 record. It
prepares the confirmed APP mirror and canonical commit-last initial NOR journal;
unallocated stores/reserved space stay erased. Missing measurements or default
uninstalled headers reject bundle preparation. No option bytes, flash, installed
header or commissioning flag are changed by preparing a bundle.
