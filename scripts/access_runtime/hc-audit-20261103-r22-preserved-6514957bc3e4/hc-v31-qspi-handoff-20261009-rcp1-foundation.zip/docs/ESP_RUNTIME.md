# ESP Runtime Pins

## Current Integration Status (2026-10-09)

The qualified VG layout now also has a live ABI2/RFU2 updater: authenticated
HTTP, durable layout-aware sessions, copied UART handoffs, STM installation,
TRIAL/CONFIRM/RESTORE/EXIT reconciliation and verified ordinary restart.
It shares the ESP OTA/TRIAL owner, without inventing A/B slots. See
[QSPI runtime](QSPI_UPDATE_RUNTIME.md). Checked-in installation/profile/OTA
qualification remains zero; this is software integration, not board acceptance.

Original block 3 is now integrated: the live sole updater streams ESP OTA and
owns full verification, checked boot-selection/reboot and restricted TRIAL
confirmation/rollback. Qualified PENDING bootstrap subscribes the native TWDT
user before NVS; restricted UART/HTTP/updater tasks supply real independent
health/service proof. Success stays locked; original block 4's
[explicit ordinary restart](NATIVE_ESP_RESTART.md) now prepares fresh native
owners and returns restricted startup through the same UART/network/updater tasks.
Zero qualification, conformance/motion gates and physical acceptance 0/52 remain.
See [live ESP owner](NATIVE_ESP_UPDATE_OWNER.md). The earlier design notes below
describe prior packages; their "prepared/future/not instantiated" statements
are superseded for the supported qualified OTA/TRIAL and explicit restart paths,
not physical evidence.

## Runtime Versions

The operational gateway targets ESP32-S3 and the existing Arduino/ESP-IDF
runtime, not a second networking framework. `tools/check_esp_syntax.sh` pins
these installed versions and fails on differing external library versions:

| Component | Version |
| --- | --- |
| ESP32 Arduino core / ESP32-S3 SDK bundle | 3.3.7 |
| Espressif Xtensa compiler bundle | 2511 |
| ArduinoJson | 7.4.3 |
| Adafruit BNO08x | 1.2.5 |
| Adafruit BusIO | 1.17.4 |
| Adafruit Unified Sensor | 1.1.15 |
| Vendored Wslay | 1.1.1 |

HTTP and MQTT use the ESP-IDF libraries included in that SDK; PubSubClient is
no longer a dependency. NTRIP uses the bundled WiFiClient only in its dedicated
worker. Boot identity uses `bootloader_random_enable/disable` at startup before
RF/ADC initialization. HTTP relies on the SDK asynchronous-request support.

Manual WS uses the [Wslay event API](https://tatsuhiro-t.github.io/wslay/tutorial.html),
vendored with its MIT license under the sketch's `src/wslay/`. Arduino recursively
compiles those C sources; no external Arduino WebSockets library or custom SDK
build is required. The pinned ESP-IDF 5.5.2 binary does not enable the WS
pre-handshake authentication callback. Its built-in WS route would perform the
upgrade before the application handler, as shown in the [SDK URI dispatcher](https://github.com/espressif/esp-idf/blob/v5.5.2/components/esp_http_server/src/httpd_uri.c).
Instead the authenticated ordinary HTTP handler retains an async request and
a dedicated worker performs the 101 response and all WS I/O. The SDK does not
run a second WebSocket parser on that socket. No private SDK structure/API is used.

```sh
bash tools/check_esp_syntax.sh
make -C tests check
```

Set `ARDUINO_DATA_DIR` / `ARDUINO_LIBRARIES_DIR` for the ESP check and
`ARDUINOJSON_DIR` for host tests when installations are elsewhere. These commands
do not download packages. The ESP check is translation-unit syntax validation
against the actual SDK, not a linked/flashed image. It currently checks the
generic esp32s3 variant and qio_qspi SDK configuration. Board flash/PSRAM/partition
settings, linked image size, FreeRTOS scheduling, watchdogs and rollback behavior
must be pinned to the actual installed board and verified separately before
deployment. No claim about ESP OTA rollback follows from these version pins.

The final Arduino link now requires `-Wl,--wrap=initArduino` through
`compiler.c.elf.extra_flags`. A retained linker fence rejects builds that omit
it. See [ESP startup policy](ESP_BOOTSTRAP.md) for the non-formatting entry,
build recipe, exact failure behavior and verification boundaries.

Host manual WS tests also need OpenSSL development headers/libcrypto and local
POSIX socket access. They use OpenSSL only to substitute the SDK's mbedTLS SHA-1
and base64 calls; framing runs the exact production Wslay sources. The syntax
check includes both the ESP sketch and every vendored C translation unit.

On 2026-10-09 the complete sketch also linked using the helper
`bash tools/build_esp.sh <explicit-FQBN> <build-directory>`. Generic ESP32-S3
8-MB/qio/default_8MB builds, with PSRAM disabled and QSPI PSRAM enabled, pass
the full `rover_esp_image.py inspect` ELF/regenerated-image audit. These explicit
verification configurations are not observations of the connected board.
They retain profile CRC zero and disabled installed capabilities. Static RAM
is 250396 / 250480 bytes (76%); actual heap/stack/scheduling acceptance remains
required. See [QSPI verification](QSPI_UPDATE_RUNTIME.md).

## Operational Ownership

The live exclusive updater's all-owner entry/exit handoff is defined in
[ESP updater entry](ESP_UPDATE_ENTRY.md). The engine validates session-bound
stop/drain evidence and return proof; the operational tasks below provide native
request/snapshot bindings for all nine domains. Passive metadata/peer locks
also inhibit ordinary work without inventing acknowledgements. Unqualified
installation gates still reject mutations with early 501; source bindings do not
prove on-board shutdown timing.

| Task | Core / priority | Stack Bytes | Owner |
| --- | --- | --- | --- |
| rover-bridge | 1 / 4 | 12288 | STM UART start/parser, TX sequence, authoritative cache, request/mission/manual admission |
| rover-gnss | 1 / 3 | 4096 | GNSS UART/parser/source identity and complete RTCM TX |
| rover-imu | 1 / 2 | 6144 | BNO08x/Wire and IMU clock/mount conversion |
| rover-network | 0 / 2 | 6144 | Wi-Fi/mDNS reconnect, MQTT initialization, heap/network snapshots |
| rover-frontend | 0 / 2 | 12288 | HTTP/MQTT JSON decoding/rendering from immutable snapshots |

Existing HTTP/MQTT/WS/NTRIP socket workers remain separate low-priority contexts.
All new tasks wait for an all-or-fail startup gate, yield on every pass and use
fixed-size latest mailboxes with zero-wait copy locks. No shared mutable String
crosses sensor/bridge/connection-task ownership. RTOS tick must be <=1 ms and
the build must be dual-core. Arduino loop only handles unconfigured local USB
provisioning and changed receiver version logs, not UART/network control.

Bridge RX is limited to 256 bytes / 500 us per pass. Frontend decodes HTTP/MQTT
JSON into fixed intents; only bridge performs native admission and cache mutation.
HTTP responses return as immutable values for frontend rendering. A running
owner pins each HTTP job through socket timeout; mission BEGIN/DATA/END resets
handoff flags on every phase and preserves 128-byte chunk backpressure.
MQTT uses three ordinary intent slots, one reserved STOP slot and four FIFO ACKs.
Decoded intents retain connection generation and a 1000 ms admission lifetime;
cached duplicate results remain immutable. Each frontend pass handles one HTTP
job, one MQTT input and one telemetry channel (5 Hz state/nav, 2 Hz motors,
1 Hz health). Bridge publishes fixed snapshots at most every 10 ms or identity
change. Source timestamps retain their original age through rendering; JSON
copies all dynamic snapshot strings. UART TX is serviced between native units.
No on-target <=2 ms bridge / <=5 ms GNSS timing claim follows from this code.

STM RX is started by that sole bridge owner on its first receive pass, not during
the earlier IMU/network setup. `shared/rover_uart_ingress.h` closes reception on
an owner gap or continuously queued software residence greater than 50 ms, or an
Arduino native RX-error callback. The SDK callback only sets an atomic flag; it
does not consume bytes or modify controller/observer state. The bounded owner
continues discarding all queued bytes while closed, not just the first line.
Source-known/peer-alive and passive service reconciliation are cleared; sequence
watermarks, bound boot IDs, source timestamps, job history and update inhibition
are retained. All ordinary source watermarks reset together only on a validated
different operational HELLO boot. Measurement timestamps use the preceding poll
as a conservative software-acquisition floor, retained from the first fragment;
they are not freshly stamped by dispatch, HTTP or MQTT. This floor assumes the
normal native RX path has bounded latency: FIFO/ISR/event latency still needs
on-device measurement and is not proven by this helper.

RX failure invalidates a started ordinary TX CRC boundary before latching TX
inhibition; a started STOP or previously admitted maintenance boundary is not
rewritten. Pending requests/mission/manual ownership are canceled locally without
sending UP_ABORT or restoring any lease. New broadcast STOP remains possible.
Health exposes `uart_rx_closed`, `uart_rx_faults`, `uart_rx_discarded_bytes` and
`uart_rx_generation`; these are software-owner observations, not hardware overflow
or WCET proof. Malformed/oversized frames retain the parser's through-LF discard
rules and do not renew source measurements.

Recovery is intentionally not automatic in the live sketch. Empty `available()`
does not prove an empty FIFO/shift register or a fresh acquisition epoch. The
portable recovery API requires an exact nonwrapping generation and trusted proof
that ring, FIFO and in-flight RX were abandoned through a clean boundary; no
native recovery callback or HTTP recovery route is installed. The RX/TX integrity
latch therefore remains closed for this runtime after a detected loss. Reopening
RX in future also must not implicitly unlock updates or ordinary TX. Initial UART
driver setup is not included in the steady-state 256-byte/500-us loop budget;
its startup and SDK callback scheduling/stack costs remain unmeasured.

GNSS setup uses `shared/rover_installed_gnss.h`, generated only from a validated
installation record and bound to the installed motion-profile CRC. Without it
the GNSS UART is not started. Only verified protocol 27.11 is supported. Its
single UART owner performs bounded MON-VER acquisition, RAM-only CFG-VALSET,
TX-drained baud switching and full CFG-VALGET readback; the 5 s RAM recheck
detects changed settings. RTCM drains only while configuration is verified;
configuration frames wait for no partial RTCM and physical TX idle. No blocking
flush/reply reader or receiver nonvolatile write is used. Frontend renders
`GET /api/v3/gnss` from copied diagnostics with original source ages. See
`config/README.md` for generation and on-device checks still required.

`GET /api/v3/health` and MQTT `health` expose measured task service gaps/misses,
elapsed wall time, own-task minimum remaining stack bytes, internal heap and
queue/sensor counters for all five application tasks. Elapsed time is not CPU busy time. The health snapshot
renderer keeps unmeasured core busy and STM PERF/CAN/CRC/overflow values null;
HTTP/MQTT fit is tested at maximum counter widths. Heap/Wi-Fi snapshots retain
their original age and are invalid after 2000 ms. Full vendor/transport-task
stack reserve, idle/busy accounting, ESP watchdog and real stress/latency evidence
are still required. Operational `deployment_verified` remains zero on STM.

## Cooperative Owner Parking

The MQTT, NTRIP and manual WS adapters also accept exact typed updater parking
tickets. Native publisher/socket/session owners inhibit new work and publish
copied stop evidence only after their own teardown/queue checks. Network task
services MQTT SDK stop/destroy (not just disconnect) and explicitly disabled
NTRIP; manual-session owner waits for WS shutdown/async-return. The GNSS owner
now additionally inhibits/removes its diagnostic ISR, waits native TX, ends the
UART driver and invalidates acquisition. IMU closes its tracked SH-2 session
and Wire; IRQ proof requires both drivers absent and the diagnostic ISR fence
inhibited. Gateway clears ordinary work and inhibits producers while retaining
the started CRC boundary/independent STOP. Admission waits for same-ticket
network/manual stop, frontend queues and all ordinary HTTP workers. HTTP applies
an identity/update-GET/STOP allowlist and latches failed async teardown.
The sole STM UART owner supplies queue/parser/ring/FIFO/SDK TX-drain candidates;
a new busy observation revokes old drain readiness. Request/snapshot locks
are zero-wait, no automatic reconnect or producer resume exists after parking,
and SDK/HTTP failure cannot produce positive evidence. The live updater requests
the nine native ports through `RoverUpdateStopSet`. The native bus makes an
additional atomic queue closure/exact-transport ownership grant before service
RX/TX routing. HTTP upload, qualified OTA/trial, protected recovery and guarded
post-FINISH restart are software-integrated; teardown WCET/watchdog and on-device
evidence remain outstanding. Native candidates alone are not an ownership grant. See
`ESP_UPDATE_ENTRY.md` for APIs, ownership and proof boundaries.

## Passive Restricted Startup

After reading local update metadata, setup binds the native owner ports and
inhibits all ordinary domains before starting sensors/network producers when
the passive guard is locked or storage is uncertain. It does not attach the
GNSS diagnostic IRQ, open its UART, initialize BNO08x/Wire, create MQTT ordinary
workers/client or start the NTRIP caster worker. Disabled network/manual handoffs
still exist, including with an unconfigured deployment. Operational task
contexts remain available for parked cleanup and the bridge's service UART;
Wi-Fi and restricted HTTP can start when deployment is configured.

An accepted late peer lock invokes the same sticky inhibition from the bridge;
native sensor/socket/publisher owners perform their own teardown. Ordinary
mission/request/manual work is canceled without a synthetic applied result,
and independent STOP retries continue before any exclusive bus grant. No
automatic reconnect, producer restart or positive typed proof follows from
clearing a peer lock. HTTP checks both passive and typed restrictions at
admission, frontend/bridge dispatch and body read boundaries; identity/update
GET and STOP retain their maintenance allowlist. Untyped inhibition does not
acquire the UART or prove physical stopping.

Locally unlocked startup now waits for the read-only
[STM service identification gate](ESP_STARTUP_IDENTIFICATION.md). Its sole UART
owner sends bounded U_HELLO probes, not OPEN or an additional operational
heartbeat. Sensor driver/IRQ initialization is deferred to each native owner;
network owner starts prepared NTRIP/MQTT only after a fresh compatible unlocked
APP/IDLE source. HTTP/WS/native command and UART gates stay closed before then,
while identity/update GET and STOP remain reachable with configured deployment.
Loader, timeout, RX fault or identity contradiction causes sticky native parking.
The current STM development application still lacks the native service/boot
adapter and therefore cannot establish release proof. Bootstrap or pending/unknown
OTA rejection still returns before recovery HTTP. The active coordinator,
OTA/trial and commissioned restart are not enabled.

`rover_operational_build.h` now rejects every nonzero
`REMOTE_ENABLE_LEGACY_STM_TEXT` or `REMOTE_ENABLE_OTA` setting at compile time.
This sketch cannot be repurposed as a legacy control/ROM/FWUP/ArduinoOTA build
through those switches. Normal setup no longer registers the unused legacy
WebServer routes/headers; their registration is inside the forbidden legacy
branch. Historical inactive function/source cleanup remains separate.
The host suite checks default acceptance and four forbidden flag values; the
actual Xtensa sketch check also verifies both forbidden-mode compiler failures.

## ESP OTA Startup Gate

The pinned Arduino ESP32 3.3.7 `esp32-hal-misc.c` default `verifyOta()` returns
true and is called for PENDING_VERIFY before NVS initialization and sketch setup.
`src/rover_esp_ota_hooks.cpp` now provides strong C `verifyOta` and
`verifyRollbackLater` overrides, both false. The GNU-wrapped rover entry now
audits OTA state before NVS, rejects a pending candidate using one supported SDK
rollback request and never calls the original core entry. If rollback cannot
complete, the sketch's first setup action checks bootstrap readiness and
returns before UART/IMU/GNSS/network/tasks/provisioning for pending, new, invalid,
aborted or unknown state. The Arduino loop stays inhibited by the absent boot
identity. This blocked path exposes only its USB startup diagnostic, not an update
HTTP server. Factory and native UNDEFINED remain allowed development boots;
neither is proof of an OTA-confirmed image. VALID also does not clear the NVS lock.

`rover_esp_ota_audit.h` only calls native running-partition/state/next-partition
read APIs. It rejects non-app, non-OTA inactive slots, overlap, missing partitions,
bad alignment and address overflow. `esp_ota_max_bytes` is the actual bounded
inactive partition size (zero if unestablished), copied into frontend identity.
Capacity is not permission: update POSTs remain 501 and conformance remains false.
The compiled rollback flag is reported internally, not treated as commissioned
bootloader, power-cut or installed partition-table evidence.

The C11/C++11 `shared/rover_esp_trial_runtime.h` is a separate future updater-owner
policy, not an active task. Its 10-s timer starts at trusted app entry, not at
completion of setup or a retry. Full native image readback must bind the retained
job's exact length/SHA/FW/profile to ESP32-S3, contract 3.1.0, service ABI 1 and
running OTA partition. Local storage/watchdog/task/HTTP/producers-stopped tests
are coherent, <=50 ms old, and cannot renew a repeated health sequence by changing
its timestamp. GNSS/IMU/MQTT are deliberately absent. Fresh same-job locked
LOADER READY evidence is required before confirmation. One callback marks valid;
the next pass reads back actual SDK VALID, then one durable NVS COMPLETE commit
retains the lock. An ambiguous mark result never causes a second mark; ambiguous
state or failed NVS completion halts closed. A known pending failure yields only
a one-shot rollback intent, requiring native state recheck before the SDK call.
After SDK confirmation, no guessed rollback or implicit FINISH is emitted.

The read-only native full-image verifier described below is implemented but
not instantiated by any live task. No commissioned health collector/watchdog,
trial-capable bootstrap, uploader or exclusive coordinator is installed. The
configured wrapped entry removes the inherited whole-NVS formatting fallback:
it attempts native initialization once and preserves failures without retry.
Encrypted NVS is rejected pending an existing-key-only adapter. This startup
migration is not proof of SDK NVS latency/power-cut behavior or an active trial;
see [ESP startup policy](ESP_BOOTSTRAP.md).
`tools/check_esp_syntax.sh` additionally compiles the actual override unit with
the ESP toolchain and checks strong unmangled hooks/wrapper and the linker fence;
this is not full image
linking or on-device hook/rollback execution. Host native-audit tests exercise
the same override source with rollback compiled on and off.

## ESP Image Identity And Readback

`src/rover_esp_build.cpp` embeds one 128-byte RFE1 rover descriptor in the pinned
SDK's `.rodata_custom_desc` section. Its linker places this immediately after
the 256-byte standard app descriptor in the first image segment. The sketch's
firmware identity now references this same object's firmware field, retaining
the object and avoiding an independently maintained advertised ID. The compiled
profile comes from the installed-profile header; the current placeholder remains
zero and does not commission a profile or grant motion permission. The SDK's
32-byte version field is not repurposed or used to truncate the rover's 48-byte ID.
Descriptor size/field offsets and SDK header/segment/app-descriptor sizes are
compile-time checked. The ESP check also compiles the real descriptor source and
checks its 128-byte custom section. `tools/rover_esp_image.py` now validates final
ELF/image placement and complete identity by pinned esptool regeneration; an
actual production artifact must still be built and checked before deployment.
See `docs/ESP_IMAGE_ARTIFACTS.md` for the offline commands and proof boundaries.

`shared/rover_esp_image_verify.h` owns fixed-memory complete-image readback,
incremental platform SHA256, exact retained length/hash/FW/profile, ESP32-S3,
contract 3.1.0, service ABI 1 and canonical rover descriptor validation. Every
read/hash slice is at most 128 bytes; no firmware copy or PSRAM allocation is
needed. The native `rover_esp_image_port.h` binds only an actual running OTA app
or nonoverlapping next OTA partition, calls `esp_partition_read`, mbedTLS SHA256
and the SDK's `esp_image_verify(ESP_IMAGE_VERIFY_SILENT, ...)`. It never writes,
selects boot, marks valid, repairs NVS or starts an updater. SDK-verifier success
must agree on partition start, complete image length, chip, first segment and
app descriptor location; correct external SHA alone cannot bypass native checks.
Unsigned-app packages must include the standard appended SHA. Trailing padding,
merged flash bundles and separate signature material not included in the SDK's
reported image length are rejected; additional signed-package policies are not
claimed commissioned.

The absolute 10-s timer can begin at trusted app entry. Busy begin, future entry,
overflow, missing ports, interrupted reads/hash, cancellation, wrong identity or
native format failures cannot publish proof. Native format verification is a
synchronous SDK call, not a bounded 128-byte parser: its exclusive-task WCET and
watchdog coverage still require commissioning. A later timed pass publishes
success, so a native operation returning after the deadline cannot immediately
publish a successful image. Only DONE can yield a running trial image; native
pending/valid state is read independently and the original completed timestamp
is preserved. Querying state never refreshes the <=50-ms full-image proof.
Compiled rollback does not supply the separately required installed/tested proof.

Host C/C++ tests perform real OpenSSL SHA256 and mutate all 1504 image bytes,
including the body after the metadata prefix. Native-adapter tests exercise the
actual port and descriptor source with SDK API fixtures and rollback compiled
on/off. These tests do not execute the SDK checksum/signature implementation,
link a full ESP app or prove physical image readback/boot/rollback.
Separate offline tests now link a synthetic Xtensa ELF using the real descriptor
and boot-hook source and convert it with the actual esptool. These establish
host artifact validation, not full Arduino/FreeRTOS integration or device boot.
