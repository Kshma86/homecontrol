#ifndef ROVER_PARAMETERS_TEST_FIXTURE_H
#define ROVER_PARAMETERS_TEST_FIXTURE_H
#include "../shared/rover_configuration_store.h"

/* Synthetic TEST data. Never an installed profile or a commissioning record. */
static inline R3Parameters parameters_fixture(void)
{
    R3Parameters p={0}; strcpy(p.robot_id,"test_only");
    p.wheel_track_mm=500; p.body_radius_mm=300;
    p.wheel_circumference_mm[0]=1000; p.wheel_circumference_mm[1]=1100;
    p.wheel_motor_pole_pairs[0]=7; p.wheel_motor_pole_pairs[1]=9;
    p.wheel_gear_ratio_milli[0]=1000; p.wheel_gear_ratio_milli[1]=2000;
    p.wheel_direction[0]=1; p.wheel_direction[1]=-1; p.blade_direction=1;
    p.blade_pole_pairs=7; p.blade_erpm_limit=21000; p.blade_rpm_limit=3000;
    p.imu_mount_q_ppm[0]=1000000;
    p.wheel_erpm_limit[0]=5000; p.wheel_erpm_limit[1]=6000;
    p.wheel_brake_ma[0]=900; p.wheel_brake_ma[1]=1000;
    p.antenna_body_mm[0]=-1; p.antenna_body_mm[1]=2; p.antenna_body_mm[2]=-3;
    p.stop_deceleration_mm_s2=250; p.stop_test_max_ms=2000;
    p.max_linear_mm_s=200; p.max_yaw_mdeg_s=15000; p.accel_mm_s2=100;
    p.gnss_hacc_limit_mm=50; p.heading_accuracy_limit_mdeg=5000;
    p.tilt_limit_mdeg=20000; p.yaw_accel_mdeg_s2=30000;
    return p;
}
static inline R3ConfigRecord config_fixture(uint32_t revision)
{
    R3ConfigRecord r={0}; r.sequence=2ULL*revision-1U;
    r.phase=R3_CONFIG_PREPARED; r.revision=revision; r.expected_revision=revision-1U;
    r.board_crc=0x12345678U; r.epoch=123;
    strcpy(r.request_id,"config-test"); strcpy(r.uid,"112233445566778899AABBCC");
    strcpy(r.esp,"1122334455667788"); strcpy(r.stm,"AABBCCDDEEFF1122");
    r.parameters=parameters_fixture(); return r;
}
static inline R3ConfigPeerProof config_proof(const R3ConfigRecord *r,uint32_t now)
{
    R3ConfigPeerProof p={0};
    memcpy(p.request_id,r->request_id,65); memcpy(p.uid,r->uid,25);
    memcpy(p.esp,r->esp,17); memcpy(p.stm,r->stm,17);
    p.board_crc=r->board_crc; p.revision=r->revision; p.request_epoch=r->epoch;
    p.parameters_crc=r3_parameters_crc(&r->parameters); p.acquired_ms=now;
    p.valid=p.disarmed=p.stopped=p.outputs_inhibited=1; return p;
}
static inline void config_request(R3ConfigRecord *r,const char *id)
{ memset(r->request_id,0,sizeof(r->request_id)); strcpy(r->request_id,id); }
static inline R3ConfigBinding config_binding(void)
{
    R3ConfigBinding b={0}; b.board_crc=0x12345678U;
    strcpy(b.uid,"112233445566778899AABBCC"); strcpy(b.esp,"1122334455667788");
    strcpy(b.stm,"AABBCCDDEEFF1122"); return b;
}
#endif
