import hashlib
import json
import os
from pathlib import Path
import struct
import subprocess
import sys
import tempfile
import unittest
from test_rover_profile import fixture, profile

sys.path.insert(0, str(profile.ROOT / "tools"))
import rover_image as image


def commissioned():
    p = fixture()
    p["commissioned"] = True
    p["safety_installed_mask"] = 9
    p["safety_inputs"]["estop"] = dict(present=True, port="C", pin=0, active_level=0)
    return p


def binary(slot="A", length=1536, firmware="fixture.3.1", p=None):
    p = commissioned() if p is None else p
    data = bytearray(b"\xff" * length)
    struct.pack_into("<II", data, 0, 0x24080000, image.BASES[slot] + 0x501)
    data[1024:1280] = b"\0" * 256
    h = memoryview(data)[1024:1280]
    h[:4] = b"RFU1"
    struct.pack_into("<HH", h, 4, 256, 1)
    h[8:19] = b"STM32H743VI"
    struct.pack_into("<IIIIHHHHI", h, 24, 1, 1 if slot == "A" else 2, image.BASES[slot],
                     length, 3, 1, 1, 0, profile.checksum(p))
    h[52:52 + len(firmware)] = firmware.encode("ascii")
    return data


class ImageTests(unittest.TestCase):
    def test_linker_padding_package(self):
        for slot in ("A","B"):
            data=binary(slot)
            for missing in range(32):
                raw=data if missing==0 else data[:-missing]
                padded,meta=image.package(raw,slot,"fixture.3.1")
                self.assertEqual(padded,data)
                self.assertFalse(meta["conformant"])
                self.assertFalse(meta["stm_remote_update"])
            for raw in (data[:-32],data+b"\xff",b"\0"*1280):
                with self.assertRaises(ValueError): image.package(raw,slot,"fixture.3.1")
            with self.assertRaises(ValueError): image.package(data,"B" if slot=="A" else "A","fixture.3.1")
            with self.assertRaises(ValueError): image.package(data,slot,"wrong-build")

    def test_both_slots_and_full_hash(self):
        for slot in ("A", "B"):
            p = commissioned(); data = binary(slot, p=p)
            digest = hashlib.sha256(data).hexdigest()
            m = image.check(data, slot, "fixture.3.1", digest, p)
            self.assertEqual((m["slot"], m["image_bytes"], m["image_sha256"]), (slot, 1536, digest))
            altered = bytearray(data); altered[-1] ^= 1
            with self.assertRaises(ValueError): image.check(altered, slot, "fixture.3.1", digest, p)

    def test_reserved_and_header_bounds(self):
        for offset in (4, 6, 8, 19, 24, 28, 32, 36, 40, 42, 44, 46, *range(100, 256)):
            data = binary(); data[1024 + offset] ^= 1
            with self.subTest(offset=offset), self.assertRaises(ValueError): image.inspect(data)
        for size in (0, 1279, 1281, image.MAX_BYTES + 32):
            with self.subTest(size=size), self.assertRaises(ValueError): image.inspect(b"\xff" * size)

    def test_vectors_and_fw_padding(self):
        for stack, reset in ((0x24000000, 0x08040501), (0x24080001, 0x08040501),
                             (0x24080000, 0x08040500), (0x24080000, 0x08140501),
                             (0x24080000, 0x08040601)):
            data = binary(); struct.pack_into("<II", data, 0, stack, reset)
            with self.subTest(stack=stack, reset=reset), self.assertRaises(ValueError): image.inspect(data)
        data = binary(firmware="a" * 48); self.assertEqual(image.inspect(data)["fw_id"], "a" * 48)
        data[1077] = 0
        with self.assertRaises(ValueError): image.inspect(data)
        data = binary(firmware="bad,token")
        with self.assertRaises(ValueError): image.inspect(data)

    def test_external_metadata_and_profile_gate(self):
        uncommissioned=fixture(); candidate=binary(p=uncommissioned)
        self.assertEqual(image.check(candidate,"A","fixture.3.1",hashlib.sha256(candidate).hexdigest(),
                                     uncommissioned)["slot"],"A")
        p = commissioned(); data = binary(p=p); digest = hashlib.sha256(data).hexdigest()
        for slot, fw, sha, supplied in (("B", "fixture.3.1", digest, p), ("A", "other", digest, p),
                                        ("A", "fixture.3.1", digest.upper(), p), ("A", "fixture.3.1", digest, fixture())):
            with self.assertRaises(ValueError): image.check(data, slot, fw, sha, supplied)
        changed = dict(p); changed["robot_id"] = "different"
        with self.assertRaises(ValueError): image.check(data, "A", "fixture.3.1", digest, changed)

    def test_cli_and_legacy_rejection(self):
        with tempfile.TemporaryDirectory(prefix="rover-image-") as directory:
            target = Path(directory, "candidate.bin"); pfile = Path(directory, "profile.json")
            p = commissioned(); data = binary(p=p); target.write_bytes(data); pfile.write_text(json.dumps(p))
            args = [sys.executable, str(profile.ROOT / "tools/rover_image.py")]
            result = subprocess.run(args + ["check", str(target), "--slot", "A", "--firmware-id", "fixture.3.1",
                                    "--sha256", hashlib.sha256(data).hexdigest(), "--profile", str(pfile)],
                                    capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(result.stdout)["contract"], "3.1.0")
            before = target.read_bytes()
            result = subprocess.run(args + ["inspect", str(target)], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0); self.assertEqual(target.read_bytes(), before)
            output=Path(directory,"padded.bin"); manifest=Path(directory,"image.json")
            target.write_bytes(data[:-17])
            result=subprocess.run(args+["package",str(target),"--slot","A","--firmware-id","fixture.3.1",
                                  "--output",str(output),"--metadata",str(manifest)],capture_output=True,text=True)
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertEqual(output.read_bytes(),data)
            self.assertFalse(json.loads(manifest.read_text())["conformant"])
            result=subprocess.run(args+["package",str(target),"--slot","A","--firmware-id","fixture.3.1",
                                  "--output",str(target),"--metadata",str(manifest)],capture_output=True,text=True)
            self.assertNotEqual(result.returncode,0); self.assertEqual(target.read_bytes(),data[:-17])
            hardlink=Path(directory,"hardlink.bin"); os.link(target,hardlink)
            result=subprocess.run(args+["package",str(target),"--slot","A","--firmware-id","fixture.3.1",
                                  "--output",str(hardlink),"--metadata",str(manifest)],capture_output=True,text=True)
            self.assertNotEqual(result.returncode,0); self.assertEqual(target.read_bytes(),data[:-17])
            target.write_bytes(b"\0" * 1536)
            result = subprocess.run(args + ["inspect", str(target)], capture_output=True, text=True)
            self.assertNotEqual(result.returncode, 0); self.assertIn("BAD_HEADER", result.stderr)


if __name__ == "__main__":
    unittest.main()
