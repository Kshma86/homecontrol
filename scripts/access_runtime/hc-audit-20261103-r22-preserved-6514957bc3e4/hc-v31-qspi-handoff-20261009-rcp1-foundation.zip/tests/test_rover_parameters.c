#include <assert.h>
#include <stdio.h>
#include "rover_parameters_fixture.h"

typedef struct { uint8_t data[2][R3_CONFIG_RECORD_BYTES],present[2]; unsigned writes; } Memory;
static int read_record(void *context,unsigned slot,uint8_t *out)
{
    Memory *m=(Memory *)context; assert(slot<2);
    if (!m->present[slot]) return 0;
    memcpy(out,m->data[slot],R3_CONFIG_RECORD_BYTES); return 1;
}
static int write_record(void *context,unsigned slot,const uint8_t *data)
{
    Memory *m=(Memory *)context; assert(slot<2); ++m->writes;
    memcpy(m->data[slot],data,R3_CONFIG_RECORD_BYTES); m->present[slot]=1; return 1;
}
static void repair_crc(uint8_t *b,unsigned crc_offset)
{ r3_update_put(b+crc_offset,r3_crc_update(UINT32_MAX,b,crc_offset)^UINT32_MAX,4); }

int main(int argc,char **argv)
{
    uint8_t b[R3_PARAMETERS_BYTES]; R3Parameters p=parameters_fixture(),decoded={0};
    assert(r3_parameters_valid(&p) && r3_parameters_encode(b,&p));
    if (argc==2 && !strcmp(argv[1],"--fixture")) {
        for (unsigned i=0;i<sizeof(b);++i) printf("%02X",b[i]);
        puts(""); return 0;
    }
    assert(r3_parameters_decode(b,&decoded) && r3_parameters_crc(&decoded)==r3_parameters_crc(&p));
    assert(decoded.wheel_direction[1]==-1);
    p.antenna_body_mm[1]=-2000; p.imu_mount_q_ppm[0]=-1000000;
    assert(r3_parameters_encode(b,&p) && r3_parameters_decode(b,&decoded));
    assert(decoded.antenna_body_mm[1]==-2000 && decoded.imu_mount_q_ppm[0]==-1000000);
    const R3Parameters sentinel=decoded;
    for (unsigned i=0;i<sizeof(b);++i) {
        b[i]^=1; assert(!r3_parameters_decode(b,&decoded));
        assert(!memcmp(&decoded,&sentinel,sizeof(decoded))); b[i]^=1;
    }
    for (unsigned i=152;i<252;++i) {
        b[i]=1; repair_crc(b,252); assert(!r3_parameters_decode(b,&decoded));
        b[i]=0; repair_crc(b,252);
    }
    const unsigned reserved[]={9,10,11,45,46,47,71};
    for (unsigned i=0;i<sizeof(reserved)/sizeof(reserved[0]);++i) {
        b[reserved[i]]=1; repair_crc(b,252); assert(!r3_parameters_decode(b,&decoded));
        b[reserved[i]]=0; repair_crc(b,252);
    }
#define BAD(field,value) do { p=parameters_fixture(); p.field=(value); assert(!r3_parameters_valid(&p)); } while (0)
    BAD(blade_enabled,2); BAD(wheel_track_mm,99); BAD(body_radius_mm,1001);
    BAD(wheel_circumference_mm[0],99); BAD(wheel_motor_pole_pairs[1],101);
    BAD(wheel_gear_ratio_milli[0],999); BAD(wheel_direction[0],0); BAD(blade_direction,0);
    BAD(blade_pole_pairs,0); BAD(blade_rpm_limit,3001); BAD(blade_erpm_limit,25001);
    BAD(antenna_body_mm[0],2001); BAD(imu_mount_q_ppm[0],0);
    BAD(wheel_erpm_limit[0],6001); BAD(wheel_brake_ma[0],UINT32_MAX);
    BAD(stop_deceleration_mm_s2,0); BAD(stop_test_max_ms,2001);
    BAD(max_slope_mdeg,15001); BAD(max_linear_mm_s,501); BAD(max_yaw_mdeg_s,4999);
    BAD(accel_mm_s2,501); BAD(yaw_accel_mdeg_s2,90001); BAD(gnss_hacc_limit_mm,101);
    BAD(heading_accuracy_limit_mdeg,999); BAD(tilt_limit_mdeg,30001);
#undef BAD
    p=parameters_fixture(); strcpy(p.robot_id,"bad.id"); assert(!r3_parameters_valid(&p));
    p=parameters_fixture(); p.robot_id[32]=1; assert(!r3_parameters_valid(&p));
    R3Profile board={0},effective={0}; board.crc=1; board.installed=board.commissioned=1;
    board.safety_installed_mask=9; board.safety_inputs[0].present=1;
    strcpy(board.vesc_firmware[0],"read_only_vesc"); p=parameters_fixture();
    assert(r3_parameters_profile(&p,&board,&effective));
    assert(!effective.commissioned && effective.installed && effective.safety_installed_mask==9);
    assert(effective.safety_inputs[0].present && !strcmp(effective.vesc_firmware[0],board.vesc_firmware[0]));
    board.installed=0; assert(!r3_parameters_profile(&p,&board,&effective));

    Memory m={0}; R3ConfigIo io={read_record,write_record,&m}; R3ConfigStore s={0};
    assert(r3_config_load(&s,&io)==R3_CONFIG_EMPTY && r3_config_locked(&s) && !m.writes);
    R3ConfigRecord r=config_fixture(1),out={0}; uint8_t record[R3_CONFIG_RECORD_BYTES];
    assert(r3_config_encode(record,&r) && r3_config_decode(record,&out) && r3_config_same(&r,&out));
    for (unsigned i=0;i<sizeof(record);++i) {
        record[i]^=1; assert(!r3_config_decode(record,&out)); record[i]^=1;
    }
    for (unsigned i=432;i<508;++i) {
        record[i]=1; repair_crc(record,508); assert(!r3_config_decode(record,&out));
        record[i]=0; repair_crc(record,508);
    }
    assert(!strcmp(r3_config_prepare(&s,&io,&r),"PENDING") && m.writes==1 && r3_config_locked(&s));
    assert(!strcmp(r3_config_prepare(&s,&io,&r),"PENDING") && m.writes==1);
    R3ConfigRecord changed=r; changed.parameters.max_linear_mm_s=100;
    assert(!strcmp(r3_config_prepare(&s,&io,&changed),"ID_CONFLICT") && m.writes==1);
    changed=r; config_request(&changed,"another-request");
    assert(!strcmp(r3_config_prepare(&s,&io,&changed),"CONFIG_BUSY") && m.writes==1);
    R3ConfigPeerProof proof=config_proof(&r,1000);
    R3ConfigBinding live=config_binding();
    assert(r3_config_peer_valid(&r,&proof,2500) && !r3_config_peer_valid(&r,&proof,2501));
    proof.acquired_ms=UINT32_MAX-99U; assert(r3_config_peer_valid(&r,&proof,100));
#define BAD_PROOF(field,value) do { proof=config_proof(&r,1000); proof.field=(value); \
    assert(!strcmp(r3_config_commit(&s,&io,&proof,&live,1000),"CONFIG_PEER_UNVERIFIED") && m.writes==1); } while (0)
    BAD_PROOF(valid,0); BAD_PROOF(disarmed,0); BAD_PROOF(stopped,0); BAD_PROOF(outputs_inhibited,0);
    BAD_PROOF(manual_active,1); BAD_PROOF(update_active,1); BAD_PROOF(board_crc,2);
    BAD_PROOF(revision,2); BAD_PROOF(parameters_crc,2); BAD_PROOF(request_epoch,2);
    BAD_PROOF(request_id[0],'x'); BAD_PROOF(uid[0],'F'); BAD_PROOF(esp[0],'F'); BAD_PROOF(stm[0],'F');
#undef BAD_PROOF
    proof=config_proof(&r,1000);
    assert(!strcmp(r3_config_commit(&s,&io,&proof,NULL,1000),"CONFIG_PEER_UNVERIFIED") && m.writes==1);
#define BAD_BINDING(field,value) do { live=config_binding(); live.field=(value); \
    assert(!strcmp(r3_config_commit(&s,&io,&proof,&live,1000),"CONFIG_PEER_UNVERIFIED") && m.writes==1); } while (0)
    BAD_BINDING(board_crc,2); BAD_BINDING(uid[0],'F'); BAD_BINDING(esp[0],'F'); BAD_BINDING(stm[0],'F');
#undef BAD_BINDING
    live=config_binding();
    assert(!strcmp(r3_config_commit(&s,&io,&proof,&live,1000),"COMMITTED") && m.writes==2 && !r3_config_locked(&s));
    assert(!strcmp(r3_config_prepare(&s,&io,&r),"ALREADY_COMMITTED") && m.writes==2);
    assert(!strcmp(r3_config_commit(&s,&io,&proof,&live,1000),"CONFIG_NOT_PENDING") && m.writes==2);
    changed=config_fixture(2); config_request(&changed,"second");
    changed.parameters.max_linear_mm_s=150;
    assert(!strcmp(r3_config_prepare(&s,&io,&changed),"PENDING") && s.has_active && s.active.revision==1);
    R3ConfigStore reboot={0}; assert(r3_config_load(&reboot,&io)==R3_CONFIG_PENDING && r3_config_locked(&reboot));
    assert(reboot.has_active && reboot.active.revision==1 && reboot.latest.revision==2 && m.writes==3);
    proof=config_proof(&changed,2000);
    assert(!strcmp(r3_config_commit(&s,&io,&proof,&live,2000),"COMMITTED") && m.writes==4);
    r=config_fixture(3); config_request(&r,"third"); r.expected_revision=0;
    assert(!strcmp(r3_config_prepare(&s,&io,&r),"CONFIG_INVALID") && m.writes==4);
    r=config_fixture(1); config_request(&r,"old-revision");
    assert(!strcmp(r3_config_prepare(&s,&io,&r),"REVISION_CONFLICT") && m.writes==4);
    r=config_fixture(3); r.board_crc=2;
    assert(!strcmp(r3_config_prepare(&s,&io,&r),"BOARD_MISMATCH") && m.writes==4);
    m.present[0]=0; assert(r3_config_load(&s,&io)==R3_CONFIG_FAULT && r3_config_locked(&s));
    assert(!strcmp(r3_config_prepare(&s,&io,&r),"CONFIG_STORAGE_ERROR") && m.writes==4);
    puts("RCP1/RCF1: canonical codecs, revision/identity/fresh proof and pending boot lock: PASS");
    return 0;
}
