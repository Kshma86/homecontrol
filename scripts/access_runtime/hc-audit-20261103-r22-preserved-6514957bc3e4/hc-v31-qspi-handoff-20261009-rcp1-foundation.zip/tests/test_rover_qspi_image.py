import hashlib
import json
from pathlib import Path
import struct
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import rover_qspi_image as qspi
import rover_image as legacy


def binary(length=1536, firmware="qspi.1"):
    data = bytearray(b"\xff" * length)
    struct.pack_into("<II", data, 0, 0x24080000, qspi.APP_BASE + 1281)
    struct.pack_into("<4sHH6I", data, 768, b"RTE2", 1, 32, 2, qspi.APP_BASE,
                     qspi.APP_BASE + 1281, qspi.APP_BASE + 1297, 0x24000101, 0x52544532)
    data[1024:1280] = b"\0" * 256
    header = memoryview(data)[1024:1280]
    header[:4] = b"RFU2"
    struct.pack_into("<HH", header, 4, 256, 2)
    header[8:24] = b"STM32H743VG".ljust(16, b"\0")
    struct.pack_into("<IIIIHHHHI", header, 24, 2, 1, qspi.APP_BASE, length, 3, 1, 2, 0, 0xAABBCCDD)
    header[52:52 + len(firmware)] = firmware.encode("ascii")
    return data


class QspiImageTests(unittest.TestCase):
    def test_layout(self):
        plan = qspi.layout()
        self.assertEqual(sum(region["bytes"] for region in plan["internal"]), 1048576)
        self.assertEqual(sum(region["bytes"] for region in plan["qspi"]), 8388608)
        end = 0
        for region in plan["qspi"]:
            self.assertEqual(int(region["offset"], 16), end)
            self.assertEqual(end % 4096, 0)
            end += region["bytes"]
        self.assertFalse(plan["conformant"])
        self.assertFalse(plan["stm_remote_update"])
        self.assertTrue(all(not region["remote_write"] for region in plan["internal"]))

    def test_hash_and_metadata(self):
        data = binary()
        metadata = qspi.check(data, hashlib.sha256(data).hexdigest(), "AABBCCDD", "qspi.1")
        self.assertEqual(metadata["slot"], "APP")
        self.assertFalse(metadata["conformant"])
        for sha, crc, firmware in (("0" * 64, "AABBCCDD", "qspi.1"),
                                   (hashlib.sha256(data).hexdigest().upper(), "AABBCCDD", "qspi.1"),
                                   (hashlib.sha256(data).hexdigest(), "aabbccdd", "qspi.1"),
                                   (hashlib.sha256(data).hexdigest(), "AABBCCDD", "other")):
            with self.assertRaises(ValueError):
                qspi.check(data, sha, crc, firmware)
        changed = bytearray(data)
        changed[-1] ^= 1
        with self.assertRaises(ValueError):
            qspi.check(changed, metadata["image_sha256"], "AABBCCDD", "qspi.1")

    def test_bounds_and_metadata_mutations(self):
        self.assertEqual(qspi.inspect(binary(qspi.APP_BYTES))["image_bytes"], qspi.APP_BYTES)
        for size in (0, 1279, 1281, qspi.APP_BYTES + 32):
            with self.subTest(size=size), self.assertRaises(ValueError):
                qspi.inspect(b"\xff" * size)
        for offset in (4, 6, 8, 19, 24, 28, 32, 36, 40, 42, 44, 46, *range(100, 256)):
            data = binary()
            data[1024 + offset] ^= 1
            with self.subTest(offset=offset), self.assertRaises(ValueError):
                qspi.inspect(data)

    def test_vectors_and_firmware(self):
        for stack, reset in ((0x24000000, qspi.APP_BASE + 1281),
                             (0x24080001, qspi.APP_BASE + 1281),
                             (0x24080000, qspi.APP_BASE + 1280),
                             (0x24080000, qspi.APP_BASE + 1537),
                             (0x24080000, 0x08040501)):
            data = binary()
            struct.pack_into("<II", data, 0, stack, reset)
            with self.assertRaises(ValueError):
                qspi.inspect(data)
        self.assertEqual(qspi.inspect(binary(firmware="a" * 48))["fw_id"], "a" * 48)
        data = binary(firmware="a" * 48)
        data[1077] = 0
        with self.assertRaises(ValueError):
            qspi.inspect(data)
        with self.assertRaises(ValueError):
            qspi.inspect(binary(firmware="bad,token"))

    def test_no_legacy_cross_acceptance(self):
        data = binary()
        with self.assertRaises(ValueError):
            legacy.inspect(data)
        data[1024:1028] = b"RFU1"
        with self.assertRaises(ValueError):
            qspi.inspect(data)

    def test_cli(self):
        command = [sys.executable, str(ROOT / "tools/rover_qspi_image.py")]
        output = subprocess.run([*command, "layout"], capture_output=True, text=True, check=True)
        self.assertEqual(json.loads(output.stdout), qspi.layout())
        with tempfile.TemporaryDirectory(prefix="rover-qspi-image-") as directory:
            path = Path(directory, "image.bin")
            path.write_bytes(binary())
            output = subprocess.run([*command, "inspect", str(path)], capture_output=True, text=True, check=True)
            self.assertEqual(json.loads(output.stdout)["slot"], "APP")
            with path.open("wb") as stream:
                stream.truncate(qspi.APP_BYTES + 1)
            output = subprocess.run([*command, "inspect", str(path)], capture_output=True, text=True)
            self.assertEqual(output.returncode, 2)
            self.assertIn("BAD_LENGTH", output.stderr)

    def test_package_padding_and_entry(self):
        data = binary()
        padded, metadata = qspi.package(data[:-1], "qspi.1")
        self.assertEqual(padded, data)
        self.assertFalse(metadata["stm_remote_update"])
        with self.assertRaises(ValueError):
            qspi.package(data[:-32], "qspi.1")
        with self.assertRaises(ValueError):
            qspi.package(data, "other")
        for offset in (768, 772, 774, 776, 780, 784, 788, 792, 796):
            wrong = bytearray(data)
            wrong[offset] ^= 1
            with self.subTest(offset=offset), self.assertRaises(ValueError):
                qspi.package(wrong, "qspi.1")
        wrong = binary()
        wrong[768:772] = b"RTE1"
        with self.assertRaises(ValueError):
            qspi.check(wrong, hashlib.sha256(wrong).hexdigest(), "AABBCCDD", "qspi.1")

    def test_package_requires_audited_elf(self):
        command = [sys.executable, str(ROOT / "tools/rover_qspi_image.py"), "package"]
        with tempfile.TemporaryDirectory(prefix="rover-qspi-package-") as directory:
            source = Path(directory, "raw.bin")
            source.write_bytes(binary())
            output, metadata = Path(directory, "package.bin"), Path(directory, "package.json")
            args = [*command, str(source), "--firmware-id", "qspi.1", "--output", str(output), "--metadata", str(metadata)]
            result = subprocess.run(args, capture_output=True, text=True)
            self.assertEqual(result.returncode, 2)
            result = subprocess.run([*args, "--elf", str(Path(directory, "missing.elf"))], capture_output=True, text=True)
            self.assertEqual(result.returncode, 2)
            self.assertFalse(output.exists())
            self.assertFalse(metadata.exists())


if __name__ == "__main__":
    unittest.main()
