import copy
import importlib.util
import json
import struct
import subprocess
import sys
import tempfile
import zlib
from pathlib import Path
import unittest

spec = importlib.util.spec_from_file_location("rover_profile", Path(__file__).resolve().parents[1]/"tools/rover_profile.py")
profile = importlib.util.module_from_spec(spec)
spec.loader.exec_module(profile)
sys.path.insert(0, str(profile.ROOT/"tools"))
import rover_factory as factory


def fixture():
    p = json.loads(profile.TEMPLATE.read_text())
    p.update(robot_id="test_only", wheel_track_mm=500, wheel_circumference_mm=[1000,1000],
             wheel_motor_pole_pairs=[7,7], wheel_gear_ratio_milli=[1000,1000], wheel_direction=[1,-1],
             blade_pole_pairs=7, blade_direction=1, body_radius_mm=300, antenna_body_mm=[0,0,0],
             imu_mount_q_ppm=[1000000,0,0,0], wheel_erpm_limit=[6000,6000], blade_erpm_limit=21000,
             blade_rpm_limit=3000, wheel_brake_ma=[1000,1000], stop_deceleration_mm_s2=250,
             max_slope_mdeg=0, safety_installed_mask=8, stop_test_max_ms=2000,
             vesc_firmware=["test","test","test"])
    p["safety_inputs"]={name:dict(present=False,port="NONE",pin=0,active_level=0) for name in ("estop","lift","bumper")}
    return p


class ProfileTests(unittest.TestCase):
    def test_canonical_order(self):
        p=fixture()
        self.assertEqual(profile.canonical(p),profile.canonical(dict(reversed(list(p.items())))))
        self.assertIn("R3_PROFILE_CRC_TEXT",profile.header(p))
        self.assertFalse(p["commissioned"])

    def test_no_physical_defaults(self):
        with self.assertRaises(ValueError): profile.validate(json.loads(profile.TEMPLATE.read_text()))

    def test_invalid_values(self):
        for key,value in (("wheel_track_mm",True),("wheel_direction",[0,1]),("imu_mount_q_ppm",[0,0,0,0]),
                          ("blade_rpm_limit",4000),("commissioned",True),("safety_installed_mask",15)):
            p=fixture(); p[key]=value
            with self.subTest(key=key),self.assertRaises(ValueError): profile.validate(p)
        p=fixture(); p["extra"]=0
        with self.assertRaises(ValueError): profile.validate(p)
        with self.assertRaises(ValueError): profile.reject_duplicate_keys([("x",1),("x",2)])

    def test_generated_header_compiles(self):
        p=fixture()
        with tempfile.TemporaryDirectory(prefix="rover-profile-test-") as directory:
            header=Path(directory)/"installed.h"
            header.write_text(profile.header(p))
            code='#include "installed.h"\nint main(void) { return R3_PROFILE_CRC_U32 != r3_installed_profile.crc || r3_installed_profile.installed != 1 || r3_installed_profile.commissioned != 0 || r3_installed_profile.wheel_direction[1] != -1; }\n'
            for compiler,language,standard in (("cc","c","c11"),("c++","c++","c++11")):
                binary=Path(directory)/compiler.replace("+","p")
                subprocess.run([compiler,"-x",language,"-std="+standard,"-Werror","-Wall","-Wextra",
                                "-I"+directory,"-I"+str(profile.ROOT/"shared"),"-","-o",str(binary)],
                               input=code,text=True,check=True)
                subprocess.run([str(binary)],check=True)


def installation_fixture():
    return dict(manifest_version=1,board_id="synthetic_test_only",
                mcu=dict(model="STM32H743VI",uid="112233445566778899AABBCC",revision=0x2003,flash_bytes=2097152),
                clock_tree=dict(sysclk_source="test-HSI",sysclk_hz=64000000,hclk_hz=64000000,
                                pclk1_hz=64000000,pclk2_hz=32000000,usart1_source="test-D2PCLK2",fdcan_source="test-HSE"),
                dma_reviewed=False,dma_streams=[],
                stm_uart=dict(instance="USART1",baud=115200,clock_hz=64000000,
                              rx=dict(port="B",pin=15,alternate=4),tx=dict(port="B",pin=14,alternate=4)),
                stm_can=dict(instance="FDCAN1",bitrate=500000,clock_hz=25000000,
                             rx=dict(port="B",pin=8,alternate=9),tx=dict(port="B",pin=9,alternate=9)),
                physical_stop=dict(drive_inhibit=dict(present=False,port="NONE",pin=0,active_level=0),
                                   power_removal_tested=False,sense_pin_tested=False,evidence_id="test-only"),
                motor_inhibit_feedback_present=False,
                motor_inhibit_feedback=dict(port="NONE",pin=0,active_level=0),power_removed_coast_ms=0,
                esp_reset=dict(gpio=13,open_drain_tested=False,recovery_tested=False,boot0_normal_tested=False),
                gnss=dict(installed_baud=38400,operational_baud=115200,firmware="test-only",protocol="27.11"),
                imu=dict(i2c_bus_hz=100000,mount_tested=False,body_signs_tested=False,lever_arm_tested=False),
                vesc=[dict(id=i,firmware="test",timeout_ms=500,timeout_brake_ma=1000 if i<3 else 0,
                           brake_current_limit_ma=2000,config_export_sha256="A"*64) for i in (1,2,3)],
                stop_tests=dict(wheel_stop_max_ms=1800,timeout_stop_max_ms=2000,stop_decel_lower_mm_s2=250,
                                blade_stop_max_ms=0,terrain_evidence="test-only"))


class FactoryTests(unittest.TestCase):
    def test_inhibit_feedback_manifest(self):
        for coast in (1000,60000):
            m=installation_fixture(); m["motor_inhibit_feedback_present"]=True
            m["motor_inhibit_feedback"]=dict(port="C",pin=3,active_level=1)
            m["power_removed_coast_ms"]=coast
            self.assertEqual(factory.validate(fixture(),m)["installation"],m)
        for coast in (999,60001,True,1.5):
            m=installation_fixture(); m["motor_inhibit_feedback_present"]=True
            m["motor_inhibit_feedback"]=dict(port="C",pin=3,active_level=1)
            m["power_removed_coast_ms"]=coast
            with self.subTest(coast=coast),self.assertRaises(ValueError): factory.record(fixture(),m)
        for present in (None,0,1,"true"):
            m=installation_fixture(); m["motor_inhibit_feedback_present"]=present
            with self.assertRaises(ValueError): factory.record(fixture(),m)
        for pin in (dict(port="B",pin=8,active_level=1),dict(port="C",pin=3,active_level=1)):
            m=installation_fixture(); m["motor_inhibit_feedback_present"]=True
            m["motor_inhibit_feedback"]=pin; m["power_removed_coast_ms"]=1000
            m["physical_stop"]["drive_inhibit"]=dict(present=True,port="C",pin=3,active_level=1)
            with self.assertRaises(ValueError): factory.record(fixture(),m)
        m=installation_fixture(); del m["motor_inhibit_feedback_present"]
        with self.assertRaises(ValueError): factory.record(fixture(),m)
        m=installation_fixture(); m["power_removed_coast_ms"]=1000
        with self.assertRaises(ValueError): factory.record(fixture(),m)

    def test_gnss_header(self):
        p,m=fixture(),installation_fixture()
        text=factory.gnss_header(p,m)
        self.assertIn(str(profile.checksum(p))+"U,38400U",text)
        with tempfile.TemporaryDirectory(prefix="rover-gnss-header-") as directory:
            Path(directory,"installed.h").write_text(text)
            code=('#include "installed.h"\nint main(void) { return r3_installed_gnss.installed != 1 || '
                  'r3_installed_gnss.installed_baud != 38400U || r3_installed_gnss.profile_crc != '
                  +str(profile.checksum(p))+'U; }\n')
            for compiler,language,standard in (("cc","c","c11"),("c++","c++","c++11")):
                binary=Path(directory,language.replace("+","p"))
                subprocess.run([compiler,"-x",language,"-std="+standard,"-Werror","-Wall","-Wextra",
                                "-I"+directory,"-I"+str(profile.ROOT/"shared"),"-","-o",str(binary)],
                               input=code,text=True,check=True)
                subprocess.run([str(binary)],check=True)

    def test_gnss_header_rejects_unverified_receiver(self):
        for field,value in (("firmware","x"*31),("protocol","27.12"),("installed_baud",True)):
            m=installation_fixture(); m["gnss"][field]=value
            with self.subTest(field=field),self.assertRaises(ValueError): factory.gnss_header(fixture(),m)

    def test_rfi1(self):
        p,m=fixture(),installation_fixture()
        binary=factory.record(p,m)
        self.assertEqual(len(binary),131072)
        magic,length,crc,reserved=struct.unpack("<4sIII",binary[:16])
        self.assertEqual((magic,reserved),(b"RFI1",0))
        self.assertLessEqual(length,16384)
        payload=binary[16:16+length]
        self.assertEqual(zlib.crc32(payload)&0xffffffff,crc)
        self.assertEqual(json.loads(payload),dict(profile=p,installation=m))
        self.assertEqual(binary[16+length:],b"\xff"*(131072-16-length))
        reordered=dict(reversed(list(m.items())))
        self.assertEqual(factory.record(p,m),factory.record(p,reordered))

    def test_incomplete_manifest(self):
        with self.assertRaises(ValueError): factory.record(fixture(),json.loads(factory.TEMPLATE.read_text()))

    def test_timeout_braking_matches_profile(self):
        for driver,value in ((0,999),(1,1001),(2,1)):
            m=installation_fixture(); m["vesc"][driver]["timeout_brake_ma"]=value
            with self.subTest(driver=driver),self.assertRaises(ValueError): factory.record(fixture(),m)

    def test_factory_bounds_and_conflicts(self):
        for section,key,value in (("mcu","flash_bytes",1048576),("mcu","uid","unknown"),
                                  ("stm_can","bitrate",1000000),("stm_uart","baud",9600),
                                  ("stop_tests","wheel_stop_max_ms",2001),
                                  ("stop_tests","stop_decel_lower_mm_s2",249)):
            p,m=fixture(),installation_fixture(); m[section][key]=value
            with self.subTest(section=section,key=key),self.assertRaises(ValueError): factory.record(p,m)
        m=installation_fixture(); m["stm_can"]["rx"]=m["stm_uart"]["rx"]
        with self.assertRaises(ValueError): factory.record(fixture(),m)
        m=installation_fixture(); m["vesc"][0]["timeout_ms"]=501
        with self.assertRaises(ValueError): factory.record(fixture(),m)
        m=installation_fixture(); m["clock_tree"]["pclk1_hz"]=128000000
        with self.assertRaises(ValueError): factory.record(fixture(),m)
        m=installation_fixture(); channel=dict(peripheral="test-only",controller="DMA1",stream=0,request=0,mode="NORMAL",irq_priority=0)
        m["dma_streams"]=[channel,channel]
        with self.assertRaises(ValueError): factory.record(fixture(),m)
        m=installation_fixture(); m["vesc"][0]["brake_current_limit_ma"]=999
        with self.assertRaises(ValueError): factory.record(fixture(),m)
        p=fixture(); p["commissioned"]=True; p["safety_installed_mask"]=9
        p["safety_inputs"]["estop"]=dict(present=True,port="C",pin=0,active_level=0)
        with self.assertRaises(ValueError): factory.record(p,installation_fixture())


if __name__=="__main__": unittest.main()
