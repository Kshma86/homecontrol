import copy
import hashlib
import io
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))
import rover_hc_update as hc
from test_rover_image import binary as make_image
from test_rover_qspi_image import binary as make_qspi_image


class HcTest(unittest.TestCase):
    def setUp(self):
        self.calls = []
        self.job = "00112233445566778899AABBCCDDEEFF"
        self.reply = {"v": 3, "update_id": self.job, "target": "STM", "locked": True, "phase": "READY",
                      "error": "NONE", "source": "STM_LOADER", "source_valid": True, "source_age_ms": 0,
                      "can_active": False, "outputs_inhibited": True, "confirmed_slot": "A",
                      "inactive_slot": "B", "candidate_slot": "NONE"}
        self.client = hc.Client(self.transport)

    def transport(self, method, path, body=None, headers=None):
        self.calls.append((method, path, body, headers))
        return (200, copy.deepcopy(self.reply)) if method == "GET" else (202, {"v": 3, "phase": "RECEIVING"})

    def test_not_installed_never_creates(self):
        self.reply = {"v": 3, "contract": "3.1.0", "stm_remote_update": False, "update_service_abi": 1,
                      "stm_flash_layout": "H743_2M_AB1"}
        with self.assertRaises(ValueError):
            self.client.create("update-1")
        self.assertEqual(len(self.calls), 1)
        self.reply["stm_remote_update"] = True
        self.reply["esp_boot"] = "0123456789ABCDEF"
        self.assertEqual(self.client.create("update-1")[0], 202)
        payload = hc.json.loads(self.calls[-1][2])
        self.assertEqual(payload, {"v": 3, "request_id": "update-1", "esp_boot": "0123456789ABCDEF", "target": "STM"})

    def test_invalid_identity_never_creates(self):
        self.reply = {"v": 3, "contract": "3.1.0", "stm_remote_update": True, "update_service_abi": 1,
                      "stm_flash_layout": "H743_2M_AB1"}
        for boot in (None, "0"*16, "a"*16, "ABC", 1):
            self.calls.clear()
            self.reply["esp_boot"] = boot
            with self.assertRaises(ValueError):
                self.client.create("update-1")
            self.assertEqual(len(self.calls), 1)

    def test_stale_loader_and_explicit_finish(self):
        self.reply["source_age_ms"] = 2001
        with self.assertRaises(ValueError):
            self.client.upload(self.job, "unused-a", "unused-b")
        self.assertEqual(len(self.calls), 1)
        with self.assertRaises(ValueError):
            self.client.finish(self.job)
        self.reply.update(phase="COMPLETE", can_finish=True, source_age_ms=0)
        self.assertEqual(self.client.finish(self.job)[0], 202)
        self.assertEqual(self.calls[-1][1], "/api/v3/update/"+self.job+"/finish")

    def test_selects_actual_b_variant_no_activate(self):
        with tempfile.TemporaryDirectory() as temp:
            a, b = Path(temp)/"a.bin", Path(temp)/"b.bin"
            a.write_bytes(make_image("A"))
            b.write_bytes(make_image("B"))
            self.assertEqual(self.client.upload(self.job, a, b)[0], 202)
            sent = self.calls[-1]
            self.assertEqual(sent[2], b.read_bytes())
            self.assertEqual(sent[3]["X-Image-Slot"], "B")
            self.assertEqual(sent[3]["Content-Length"], str(len(sent[2])))
            self.assertEqual(len(self.calls), 2)
            b.write_bytes(a.read_bytes())
            with self.assertRaises(ValueError):
                self.client.upload(self.job, a, b)

    def test_unknown_mutation_is_never_replayed(self):
        def lost(method, path, body=None, headers=None):
            self.calls.append((method, path, body, headers))
            raise hc.UnknownMutation("lost response")
        client = hc.Client(lost)
        with self.assertRaises(hc.UnknownMutation):
            client.abort(self.job)
        self.assertEqual(len(self.calls), 1)

    def test_token_origin_and_job_bounds(self):
        for url in ("file:///etc/passwd", "http://user:pass@rover", "http://rover/api", "http://rover?token=x"):
            with self.assertRaises(ValueError):
                hc.Http(url, "A"*64)
        for job in ("0"*32, "a"*32, "../finish", None):
            with self.assertRaises(ValueError):
                self.client.abort(job)
        with self.assertRaises(ValueError):
            hc.Http("http://rover", "secret\r\n")

    def test_response_duplicate_and_nonfinite_fields_are_unknown_not_replayed(self):
        class Reply(io.BytesIO):
            status = 200
        for body in (b'{"v":3,"locked":true,"locked":false}', b'{"v":3,"age":NaN}',
                     b'{"v":3,"age":Infinity}', b'{"v":true}'):
            for method in ("GET", "POST"):
                transport = hc.Http("http://rover", "A"*64)
                with patch.object(transport.opener, "open", return_value=Reply(body)) as call:
                    with self.subTest(body=body, method=method), self.assertRaises(
                            ValueError if method=="GET" else hc.UnknownMutation):
                        transport(method, "/api/v3/update", b"" if method=="POST" else None)
                    self.assertEqual(call.call_count, 1)

    def vg_transport(self, method, path, body=None, headers=None):
        self.calls.append((method, path, body, headers))
        if method == "GET":
            return 200, copy.deepcopy(self.identity if path == "/api/v3/identity" else self.reply)
        return 202, {"v": 3, "phase": "RECEIVING"}

    def vg_setup(self):
        self.identity = dict(v=3, contract="3.1.0", stm_remote_update=True, update_service_abi=2,
                             stm_flash_layout="H743_1M_QSPI2", stm_image_max_bytes=524288,
                             profile_crc="AABBCCDD", esp_boot="0123456789ABCDEF")
        self.reply.update(esp_boot=self.identity["esp_boot"], confirmed_slot=None, inactive_slot=None, candidate_slot=None)
        self.client = hc.Client(self.vg_transport)

    def test_vg_create_and_unknown_layouts(self):
        self.vg_setup()
        self.assertEqual(self.client.create("vg-job")[0], 202)
        for field, bad in (("update_service_abi", 1), ("update_service_abi", True),
                           ("stm_flash_layout", "H743_2M_AB1"), ("profile_crc", "00000000"),
                           ("stm_image_max_bytes", 524320), ("stm_remote_update", False)):
            before = copy.deepcopy(self.identity); self.identity[field] = bad; self.calls.clear()
            with self.subTest(field=field), self.assertRaises(ValueError): self.client.create("vg-job")
            self.assertTrue(all(c[0] == "GET" for c in self.calls)); self.identity = before

    def test_vg_exact_rfu2_upload_no_activate(self):
        self.vg_setup()
        with tempfile.TemporaryDirectory() as directory:
            app = Path(directory) / "app.bin"; app.write_bytes(make_qspi_image())
            digest = hashlib.sha256(app.read_bytes()).hexdigest()
            with patch.object(hc.qspi, "verify_elf") as audit:
                self.assertEqual(self.client.upload_qspi(self.job, app, "app.elf", digest, "qspi.1")[0], 202)
                audit.assert_called_once_with(Path("app.elf"), app.read_bytes())
            self.assertEqual(len(self.calls), 3)
            sent = self.calls[-1]
            self.assertEqual(sent[2], app.read_bytes())
            self.assertEqual(sent[3]["X-Flash-Layout"], "H743_1M_QSPI_REC2")
            self.assertEqual(sent[3]["X-Image-Slot"], "APP")
            self.assertEqual(sent[3]["X-Image-SHA256"], digest)

    def test_vg_rejects_stale_boot_slots_and_package_without_post(self):
        self.vg_setup()
        with tempfile.TemporaryDirectory() as directory:
            app = Path(directory) / "app.bin"; app.write_bytes(make_qspi_image())
            digest = hashlib.sha256(app.read_bytes()).hexdigest()
            for field, bad in (("esp_boot", "1111111111111111"), ("source_age_ms", True),
                               ("source_age_ms", 2001), ("source_valid", False), ("candidate_slot", "NONE"),
                               ("confirmed_slot", "A"), ("inactive_slot", "B"), ("outputs_inhibited", None)):
                before = copy.deepcopy(self.reply); self.reply[field] = bad; self.calls.clear()
                with self.subTest(field=field), self.assertRaises(ValueError):
                    self.client.upload_qspi(self.job, app, "unused", digest, "qspi.1")
                self.assertTrue(all(c[0] == "GET" for c in self.calls)); self.reply = before
            for sha, firmware in (("0"*64, "qspi.1"), (digest, "wrong")):
                self.calls.clear()
                with self.assertRaises(ValueError): self.client.upload_qspi(self.job, app, "unused", sha, firmware)
                self.assertTrue(all(c[0] == "GET" for c in self.calls))
            self.identity["profile_crc"] = "12345678"
            with self.assertRaises(ValueError): self.client.upload_qspi(self.job, app, "unused", digest, "qspi.1")

    def test_vg_elf_failure_and_lost_reply_are_not_retried(self):
        self.vg_setup()
        with tempfile.TemporaryDirectory() as directory:
            app = Path(directory) / "app.bin"; app.write_bytes(make_qspi_image())
            digest = hashlib.sha256(app.read_bytes()).hexdigest()
            with patch.object(hc.qspi, "verify_elf", side_effect=ValueError("invalid ELF")):
                with self.assertRaises(ValueError): self.client.upload_qspi(self.job, app, "app.elf", digest, "qspi.1")
            self.assertTrue(all(c[0] == "GET" for c in self.calls))
            self.calls.clear()
            def lost(method, path, body=None, headers=None):
                if method == "POST":
                    self.calls.append((method, path, body, headers)); raise hc.UnknownMutation("lost")
                return self.vg_transport(method, path, body, headers)
            with patch.object(hc.qspi, "verify_elf"), self.assertRaises(hc.UnknownMutation):
                hc.Client(lost).upload_qspi(self.job, app, "app.elf", digest, "qspi.1")
            self.assertEqual(sum(call[0] == "POST" for call in self.calls), 1)

    def test_finish_never_uses_stale_or_unknown_permission(self):
        self.reply.update(phase="COMPLETE", can_finish=True)
        for field, bad in (("source_age_ms", 2001), ("source_age_ms", True), ("source_valid", False),
                           ("outputs_inhibited", None), ("can_active", None)):
            before = copy.deepcopy(self.reply); self.reply[field] = bad; self.calls.clear()
            with self.assertRaises(ValueError): self.client.finish(self.job)
            self.assertTrue(all(c[0] == "GET" for c in self.calls)); self.reply = before


if __name__ == "__main__":
    unittest.main()
