import copy
import json
from pathlib import Path
import struct
import subprocess
import sys
import tempfile
import unittest
import zlib

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import rover_parameters as parameters


def fixture():
    # Synthetic values only, corresponding to the C fixture; not board defaults.
    return dict(parameters_version=1, robot_id="test_only", blade_enabled=False,
                wheel_track_mm=500, body_radius_mm=300, wheel_circumference_mm=[1000, 1100],
                wheel_motor_pole_pairs=[7, 9], wheel_gear_ratio_milli=[1000, 2000], wheel_direction=[1, -1],
                blade_direction=1, blade_pole_pairs=7, max_slope_mdeg=0, blade_erpm_limit=21000,
                blade_rpm_limit=3000, antenna_body_mm=[-1, 2, -3], imu_mount_q_ppm=[1000000, 0, 0, 0],
                wheel_erpm_limit=[5000, 6000], wheel_brake_ma=[900, 1000], stop_deceleration_mm_s2=250,
                stop_test_max_ms=2000, max_linear_mm_s=200, max_yaw_mdeg_s=15000, accel_mm_s2=100,
                gnss_hacc_limit_mm=50, heading_accuracy_limit_mdeg=5000, tilt_limit_mdeg=20000,
                yaw_accel_mdeg_s2=30000)


class ParametersTests(unittest.TestCase):
    def test_round_trip(self):
        p = fixture()
        self.assertEqual(parameters.decode(parameters.encode(p)), p)
        p["antenna_body_mm"] = [-2000, 2000, -1]
        p["imu_mount_q_ppm"] = [-1000000, 0, 0, 0]
        self.assertEqual(parameters.decode(parameters.encode(p)), p)
        self.assertEqual(parameters.canonical(p), parameters.canonical(dict(reversed(list(p.items())))))

    def test_no_commissioning_defaults(self):
        template = json.loads((ROOT / "config/rover_parameters.template.json").read_text())
        self.assertEqual(set(template), parameters.FIELDS)
        self.assertTrue(all(value is None for name, value in template.items() if name != "parameters_version"))
        with self.assertRaises(ValueError): parameters.validate(template)
        for name in ("commissioned", "installed", "safety_inputs", "vesc_firmware", "profile_crc", "watchdog"):
            p = fixture(); p[name] = True
            with self.subTest(name=name), self.assertRaises(ValueError): parameters.validate(p)

    def test_bad_types_and_cross_fields(self):
        for name, value in (("robot_id", "a.b"), ("robot_id", "á"), ("robot_id", "a"*33),
                            ("blade_enabled", 1), ("parameters_version", True), ("wheel_track_mm", 500.0),
                            ("blade_rpm_limit", 3001), ("wheel_direction", [0, 1]),
                            ("imu_mount_q_ppm", [0, 0, 0, 0]), ("antenna_body_mm", [0, 0]),
                            ("blade_direction", 0), ("wheel_brake_ma", [0x80000000, 0])):
            p = fixture(); p[name] = value
            with self.subTest(name=name, value=value), self.assertRaises(ValueError): parameters.validate(p)
        for name, (_, _, low, high) in parameters.SCALARS.items():
            for value in (low-1, high+1, True, None):
                p = fixture(); p[name] = value
                with self.subTest(name=name, value=value), self.assertRaises(ValueError): parameters.validate(p)
        for name, (_, _, _, low, high) in parameters.ARRAYS.items():
            for value in (low-1, high+1, True, None):
                p = fixture(); p[name][0] = value
                with self.subTest(name=name, value=value), self.assertRaises(ValueError): parameters.validate(p)
        for bad in ('{"x":1,"x":2}', '{"x":NaN}', '{"x":Infinity}', '{"x":-Infinity}'):
            with self.assertRaises(ValueError): parameters.loads(bad)

    def test_invalid_bytes_even_with_repaired_crc(self):
        original = parameters.encode(fixture())
        for index in range(256):
            b = bytearray(original); b[index] ^= 1
            with self.subTest(index=index), self.assertRaises(ValueError): parameters.decode(bytes(b))
        for index in [9, 10, 11, 22, 44, 45, 46, 47, 71, *range(152, 252)]:
            b = bytearray(original); b[index] = 1
            struct.pack_into("<I", b, 252, zlib.crc32(b[:252]) & 0xffffffff)
            with self.subTest(index=index), self.assertRaises(ValueError): parameters.decode(bytes(b))
        for b in (original[:-1], original+b"\0", bytearray(original)):
            with self.assertRaises(ValueError): parameters.decode(b)

    def test_c_and_cpp_exact_codec(self):
        with tempfile.TemporaryDirectory(prefix="rover-parameters-codec-") as directory:
            for compiler, language, standard in (("cc", "c", "c11"), ("c++", "c++", "c++11")):
                binary = Path(directory) / language.replace("+", "p")
                subprocess.run([compiler, "-x", language, "-std="+standard, "-Werror", "-Wall", "-Wextra",
                                "-Wno-missing-field-initializers", str(ROOT / "tests/test_rover_parameters.c"),
                                "-o", str(binary)], check=True)
                actual = subprocess.check_output([str(binary), "--fixture"], text=True).strip()
                self.assertEqual(actual, parameters.encode(fixture()).hex().upper())
                subprocess.run([str(binary)], check=True)

    def test_cli_draft_not_applied_and_no_overwrite(self):
        with tempfile.TemporaryDirectory(prefix="rover-parameters-cli-") as directory:
            source, output = Path(directory) / "draft.json", Path(directory) / "parameters.rcp1"
            source.write_text(json.dumps(fixture()))
            cmd = [sys.executable, str(ROOT / "tools/rover_parameters.py")]
            result = subprocess.run(cmd+["encode", str(source), "--output", str(output)], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("NOT applied", result.stdout)
            self.assertEqual(output.read_bytes(), parameters.encode(fixture()))
            self.assertNotEqual(subprocess.run(cmd+["encode", str(source), "--output", str(output)], capture_output=True).returncode, 0)
            self.assertEqual(output.read_bytes(), parameters.encode(fixture()))
            result = subprocess.run(cmd+["decode", str(output)], capture_output=True, text=True, check=True)
            self.assertEqual(json.loads(result.stdout), fixture())

    def test_schema(self):
        schema = parameters.schema()
        self.assertFalse(schema["additionalProperties"])
        self.assertEqual(set(schema["required"]), parameters.FIELDS)
        self.assertEqual(set(schema["properties"]), parameters.FIELDS)
        self.assertEqual(schema["properties"]["wheel_direction"]["items"]["enum"], [-1, 1])


if __name__ == "__main__":
    unittest.main()
