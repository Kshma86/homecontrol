#ifndef ROVER_ESP_IMAGE_VERIFY_H
#define ROVER_ESP_IMAGE_VERIFY_H
#include "rover_boot_journal.h"

#define R3_ESP_IMAGE_CHIP_ID 9U
#define R3_ESP_BUILD_BYTES 128U
#define R3_ESP_BUILD_OFFSET 288U
#define R3_ESP_IMAGE_PREFIX_BYTES 416U
#define R3_ESP_IMAGE_VERIFY_MS 10000U
typedef struct {
    uint32_t profile_crc;
    uint16_t major,minor,patch,abi;
    char firmware[49];
} R3EspBuildMetadata;
/* The SDK verifier supplies this only after standard checksum/hash/signature
 * validation. This module does not duplicate the ESP bootloader image parser. */
typedef struct {
    uint32_t address,bytes,first_data_offset,first_data_bytes;
    uint16_t chip_id;
    uint8_t magic,segment_count,hash_appended;
} R3EspImageFormat;
typedef enum {
    R3_EIV_IDLE,R3_EIV_START,R3_EIV_READ,R3_EIV_FINISH,R3_EIV_FORMAT,
    R3_EIV_PUBLISH,R3_EIV_DONE,R3_EIV_ERROR,R3_EIV_CANCELLED
} R3EspImageVerifyPhase;
typedef struct {
    int (*read)(void *,uint32_t offset,uint8_t *,size_t);
    int (*hash_start)(void *);
    int (*hash_update)(void *,const uint8_t *,size_t);
    int (*hash_finish)(void *,uint8_t[32]);
    int (*verify_format)(void *,R3EspImageFormat *);
    void *context;
} R3EspImageVerifyIo;
typedef struct {
    R3BootImage expected;
    R3EspBuildMetadata metadata;
    uint8_t prefix[R3_ESP_IMAGE_PREFIX_BYTES];
    uint32_t address,capacity,offset,started_ms,completed_ms;
    R3EspImageVerifyPhase phase;
    const char *error;
} R3EspImageVerifier;

/* RFE1 is a rover descriptor in the SDK's .rodata_custom_desc section, directly
 * after esp_app_desc_t in the first segment. All integers are little endian. */
static inline const char *r3_esp_build_decode(const uint8_t h[R3_ESP_BUILD_BYTES],
    uint32_t installed_profile,const char *firmware,R3EspBuildMetadata *out)
{
    R3EspBuildMetadata m={0};
    static const uint8_t target[16]={'E','S','P','3','2','S','3',0,0,0,0,0,0,0,0,0};
    if (!h || !firmware || !out || memcmp(h,"RFE1",4) || r3_update_u16(h+4)!=128U ||
        r3_update_u16(h+6)!=1U || h[84] || !r3_update_zero(h+85,43U)) return "BAD_HEADER";
    if (memcmp(h+8,target,16U)) return "WRONG_TARGET";
    m.major=r3_update_u16(h+24); m.minor=r3_update_u16(h+26);
    m.patch=r3_update_u16(h+28); m.abi=r3_update_u16(h+30); m.profile_crc=r3_update_u32(h+32);
    if (m.major!=3 || m.minor!=1 || m.patch) return "BAD_HEADER";
    if (m.abi!=1) return "ABI_MISMATCH";
    if (m.profile_crc!=installed_profile) return "PROFILE_MISMATCH";
    if (!r3_update_firmware(m.firmware,h+36) || strcmp(m.firmware,firmware)) return "BAD_HEADER";
    *out=m; return "NONE";
}
static inline int r3_esp_image_verify_busy(const R3EspImageVerifier *v)
{
    return v->phase>=R3_EIV_START && v->phase<=R3_EIV_PUBLISH;
}
static inline void r3_esp_image_verify_fail(R3EspImageVerifier *v,const char *code)
{
    v->phase=R3_EIV_ERROR; v->error=code; v->completed_ms=0;
    memset(&v->metadata,0,sizeof(v->metadata));
}
static inline int r3_esp_image_verify_begin(R3EspImageVerifier *v,const R3BootImage *expected,
    uint32_t installed_profile,uint32_t address,uint32_t capacity,uint32_t started_ms,uint32_t now)
{
    if (!v || r3_esp_image_verify_busy(v)) return 0;
    memset(v,0,sizeof(*v)); v->error="NONE"; v->started_ms=started_ms;
    if (!expected || expected->slot!=R3_SLOT_NONE || !expected->bytes ||
        !memchr(expected->firmware,0,sizeof(expected->firmware)) || !r3_token(expected->firmware,48U,1)) {
        r3_esp_image_verify_fail(v,"BAD_HEADER"); return 0;
    }
    if (!address || address%4096U || !capacity || capacity%4096U || capacity>=0x1000000U ||
        (uint64_t)address+capacity>UINT32_MAX || expected->bytes<464U || expected->bytes>capacity) {
        r3_esp_image_verify_fail(v,"BAD_LENGTH"); return 0;
    }
    if (expected->profile_crc!=installed_profile) {
        r3_esp_image_verify_fail(v,"PROFILE_MISMATCH"); return 0;
    }
    if (now-started_ms>=R3_ESP_IMAGE_VERIFY_MS) {
        r3_esp_image_verify_fail(v,"VERIFY_TIMEOUT"); return 0;
    }
    v->expected=*expected; v->address=address; v->capacity=capacity; v->phase=R3_EIV_START; return 1;
}
static inline void r3_esp_image_verify_cancel(R3EspImageVerifier *v)
{
    if (v && r3_esp_image_verify_busy(v)) {
        v->phase=R3_EIV_CANCELLED; v->error="CANCELLED";
        memset(&v->metadata,0,sizeof(v->metadata));
    }
}
/* Read/hash passes are <=128 bytes, with fixed memory. verify_format is the
 * synchronous SDK operation: the native owner must commission its WCET/watchdog.
 * Publication is a later timed pass, never immediately after that callback. */
static inline R3EspImageVerifyPhase r3_esp_image_verify_step(R3EspImageVerifier *v,
    const R3EspImageVerifyIo *io,uint32_t now)
{
    if (!r3_esp_image_verify_busy(v)) return v->phase;
    if (now-v->started_ms>=R3_ESP_IMAGE_VERIFY_MS) {
        r3_esp_image_verify_fail(v,"VERIFY_TIMEOUT"); return v->phase;
    }
    if (!io || !io->read || !io->hash_start || !io->hash_update || !io->hash_finish || !io->verify_format) {
        r3_esp_image_verify_fail(v,"SERVICE_ABI_NOT_INSTALLED"); return v->phase;
    }
    uint8_t bytes[128];
    if (v->phase==R3_EIV_START) {
        if (io->hash_start(io->context)!=1) r3_esp_image_verify_fail(v,"INTERNAL");
        else v->phase=R3_EIV_READ;
    } else if (v->phase==R3_EIV_READ) {
        if (v->offset>=v->expected.bytes || v->expected.bytes>v->capacity) {
            r3_esp_image_verify_fail(v,"BAD_LENGTH"); return v->phase;
        }
        const uint32_t remaining=v->expected.bytes-v->offset,n=remaining<128U?remaining:128U;
        if (io->read(io->context,v->offset,bytes,n)!=1) r3_esp_image_verify_fail(v,"FLASH_ERROR");
        else if (io->hash_update(io->context,bytes,n)!=1) r3_esp_image_verify_fail(v,"INTERNAL");
        else {
            if (v->offset<sizeof(v->prefix)) {
                const size_t left=sizeof(v->prefix)-v->offset;
                memcpy(v->prefix+v->offset,bytes,n<left?n:left);
            }
            v->offset+=n; if (v->offset==v->expected.bytes) v->phase=R3_EIV_FINISH;
        }
    } else if (v->phase==R3_EIV_FINISH) {
        if (io->hash_finish(io->context,bytes)!=1) r3_esp_image_verify_fail(v,"INTERNAL");
        else if (memcmp(bytes,v->expected.hash,32)) r3_esp_image_verify_fail(v,"BAD_HASH");
        else {
            const uint8_t *h=v->prefix;
            if (h[0]!=0xE9 || !h[1] || h[1]>16 || h[23]!=1 || r3_update_u32(h+32)!=0xABCD5432U ||
                r3_update_u32(h+28)<384U || r3_update_u32(h+28)>v->expected.bytes-32U)
                r3_esp_image_verify_fail(v,"BAD_HEADER");
            else if (r3_update_u16(h+12)!=R3_ESP_IMAGE_CHIP_ID) r3_esp_image_verify_fail(v,"WRONG_TARGET");
            else {
                const char *error=r3_esp_build_decode(h+R3_ESP_BUILD_OFFSET,
                    v->expected.profile_crc,v->expected.firmware,&v->metadata);
                if (strcmp(error,"NONE")) r3_esp_image_verify_fail(v,error);
                else v->phase=R3_EIV_FORMAT;
            }
        }
    } else if (v->phase==R3_EIV_FORMAT) {
        R3EspImageFormat f={0};
        if (io->verify_format(io->context,&f)!=1 || f.address!=v->address || f.bytes!=v->expected.bytes ||
            f.first_data_offset!=32U || f.first_data_bytes!=r3_update_u32(v->prefix+28) ||
            f.chip_id!=R3_ESP_IMAGE_CHIP_ID || f.magic!=0xE9 || f.segment_count!=v->prefix[1] || f.hash_appended!=1)
            r3_esp_image_verify_fail(v,"BAD_HEADER");
        else v->phase=R3_EIV_PUBLISH;
    } else {
        v->completed_ms=now; v->phase=R3_EIV_DONE;
    }
    return v->phase;
}
#endif
