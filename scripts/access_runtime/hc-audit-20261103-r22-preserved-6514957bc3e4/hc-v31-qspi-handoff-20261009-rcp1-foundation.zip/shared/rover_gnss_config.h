#ifndef ROVER_GNSS_CONFIG_H
#define ROVER_GNSS_CONFIG_H
#include "rover_gnss.h"

/* u-blox UBX-18010854 R07, sections 5.9.24/25 and 6.8: RAM only. */
typedef struct {
    uint32_t profile_crc, installed_baud;
    char firmware[31], protocol[17];
    uint8_t installed;
} R3GnssInstallation;
typedef enum {
    R3_GNSS_DISABLED, R3_GNSS_PROBE, R3_GNSS_SET, R3_GNSS_SWITCH,
    R3_GNSS_VERIFY, R3_GNSS_READY, R3_GNSS_FAILED, R3_GNSS_REPROBE
} R3GnssConfigPhase;
typedef enum {
    R3_GNSS_NO_ERROR, R3_GNSS_NO_INSTALLATION, R3_GNSS_PROFILE_ERROR,
    R3_GNSS_PROTOCOL_ERROR, R3_GNSS_FIRMWARE_ERROR, R3_GNSS_CONFIG_TIMEOUT,
    R3_GNSS_CONFIG_NAK, R3_GNSS_READBACK_ERROR, R3_GNSS_TX_ERROR
} R3GnssConfigError;
typedef struct {
    R3GnssInstallation installation;
    R3GnssConfigPhase phase;
    R3GnssConfigError error;
    uint32_t baud, phase_ms, sent_ms, verified_ms;
    uint8_t attempts, waiting, verified;
    char firmware[31], protocol[17];
} R3GnssConfig;
typedef struct { uint32_t key, value; uint8_t bytes; } R3GnssConfigItem;
static const R3GnssConfigItem r3_gnss_config_items[] = {
    {0x30210001U,200,2}, {0x30210002U,1,2}, {0x20210003U,1,1},
    {0x20910007U,1,1}, {0x209100bbU,5,1},
    {0x10520005U,1,1}, {0x20520002U,1,1}, {0x20520003U,0,1}, {0x20520004U,0,1},
    {0x10730001U,1,1}, {0x10730004U,1,1},
    {0x10740001U,1,1}, {0x10740002U,1,1}, {0x40520001U,115200,4}
};
#define R3_GNSS_CONFIG_ITEMS (sizeof(r3_gnss_config_items)/sizeof(r3_gnss_config_items[0]))
#define R3_GNSS_CONFIG_FRAME_MAX 128U

static inline const char *r3_gnss_config_phase_name(R3GnssConfigPhase phase)
{
    static const char *names[]={"DISABLED","PROBE","SET_RAM","SWITCH_BAUD","VERIFY_RAM","READY","FAILED","PROBE_OPERATIONAL_BAUD"};
    return (unsigned)phase<sizeof(names)/sizeof(names[0])?names[phase]:"FAILED";
}
static inline const char *r3_gnss_config_error_name(R3GnssConfigError error)
{
    static const char *names[]={"NONE","NO_INSTALLATION","PROFILE_MISMATCH","UNSUPPORTED_PROTOCOL",
        "FIRMWARE_MISMATCH","TIMEOUT","CONFIG_NAK","READBACK_MISMATCH","TX_ERROR"};
    return (unsigned)error<sizeof(names)/sizeof(names[0])?names[error]:"INTERNAL";
}
static inline void r3_gnss_config_fail(R3GnssConfig *c,R3GnssConfigError error)
{
    c->phase=R3_GNSS_FAILED; c->error=error; c->verified=0; c->waiting=0;
}
static inline int r3_gnss_config_text(char *out,size_t capacity,const uint8_t *bytes,size_t length)
{
    size_t n=0;
    while (n<length && bytes[n]) {
        if (bytes[n]<32U || bytes[n]>126U || n+1U>=capacity) return 0;
        out[n]=(char)bytes[n]; ++n;
    }
    if (!n) return 0;
    out[n]=0; return 1;
}
static inline void r3_gnss_config_init(R3GnssConfig *c,const R3GnssInstallation *installation,uint32_t profile_crc,uint32_t now)
{
    memset(c,0,sizeof(*c)); c->error=R3_GNSS_NO_INSTALLATION;
    if (!installation->installed) return;
    c->installation=*installation;
    if (installation->profile_crc!=profile_crc || installation->installed_baud<9600U ||
        installation->installed_baud>921600U || !memchr(installation->firmware,0,sizeof(installation->firmware)) ||
        !installation->firmware[0]) { r3_gnss_config_fail(c,R3_GNSS_PROFILE_ERROR); return; }
    if (!memchr(installation->protocol,0,sizeof(installation->protocol)) || strcmp(installation->protocol,"27.11")) {
        r3_gnss_config_fail(c,R3_GNSS_PROTOCOL_ERROR); return;
    }
    c->baud=installation->installed_baud; c->phase=R3_GNSS_PROBE;
    c->phase_ms=now; c->error=R3_GNSS_NO_ERROR;
}
static inline void r3_gnss_config_stage(R3GnssConfig *c,R3GnssConfigPhase phase,uint32_t now)
{
    c->phase=phase; c->phase_ms=now; c->attempts=0; c->waiting=0;
}
static inline void r3_gnss_config_tick(R3GnssConfig *c,uint32_t now)
{
    if (c->phase==R3_GNSS_READY && (uint32_t)(now-c->verified_ms)>=5000U)
        r3_gnss_config_stage(c,R3_GNSS_VERIFY,now);
    if (c->phase==R3_GNSS_PROBE || c->phase==R3_GNSS_SET || c->phase==R3_GNSS_SWITCH || c->phase==R3_GNSS_VERIFY) {
        if ((uint32_t)(now-c->phase_ms)>=4000U ||
            (c->waiting && c->attempts>=3U && (uint32_t)(now-c->sent_ms)>=1000U))
        {
            if (c->phase==R3_GNSS_PROBE && c->baud!=115200U)
                r3_gnss_config_stage(c,R3_GNSS_REPROBE,now);
            else r3_gnss_config_fail(c,R3_GNSS_CONFIG_TIMEOUT);
        }
    } else if (c->phase==R3_GNSS_REPROBE && (uint32_t)(now-c->phase_ms)>=4000U) {
        r3_gnss_config_fail(c,R3_GNSS_CONFIG_TIMEOUT);
    }
}
static inline int r3_gnss_config_valid(const R3GnssConfig *c,uint32_t now)
{
    return c->verified && (c->phase==R3_GNSS_READY || c->phase==R3_GNSS_VERIFY) &&
        (uint32_t)(now-c->verified_ms)<9000U;
}
static inline void r3_gnss_config_le(uint8_t *bytes,uint32_t value,unsigned length)
{
    for (unsigned i=0;i<length;++i) bytes[i]=(uint8_t)(value>>(8U*i));
}
static inline size_t r3_gnss_config_frame(const R3GnssConfig *c,uint8_t *out,size_t capacity,uint32_t now)
{
    uint8_t bytes[R3_GNSS_CONFIG_FRAME_MAX]={0xb5,0x62}; size_t n=6;
    if (c->waiting && (uint32_t)(now-c->sent_ms)<1000U) return 0;
    if (c->attempts>=3U) return 0;
    if (c->phase==R3_GNSS_PROBE) { bytes[2]=0x0a; bytes[3]=4; }
    else if (c->phase==R3_GNSS_SET || c->phase==R3_GNSS_VERIFY) {
        const int set=c->phase==R3_GNSS_SET;
        bytes[2]=6; bytes[3]=set?0x8a:0x8b;
        bytes[n++]=0; bytes[n++]=set?1:0; bytes[n++]=0; bytes[n++]=0;
        for (unsigned i=0;i<R3_GNSS_CONFIG_ITEMS;++i) {
            const R3GnssConfigItem *item=&r3_gnss_config_items[i];
            r3_gnss_config_le(bytes+n,item->key,4); n+=4;
            if (set) { r3_gnss_config_le(bytes+n,item->value,item->bytes); n+=item->bytes; }
        }
    } else return 0;
    r3_gnss_config_le(bytes+4,(uint32_t)(n-6U),2);
    uint8_t a=0,b=0;
    for (size_t i=2;i<n;++i) { a=(uint8_t)(a+bytes[i]); b=(uint8_t)(b+a); }
    bytes[n++]=a; bytes[n++]=b;
    if (capacity<n) return 0;
    memcpy(out,bytes,n); return n;
}
static inline void r3_gnss_config_sent(R3GnssConfig *c,uint32_t now)
{
    ++c->attempts; c->sent_ms=now; c->waiting=1;
    if (c->phase==R3_GNSS_SET) r3_gnss_config_stage(c,R3_GNSS_SWITCH,now);
}
/* Do not change local baud until the whole outgoing frame has physically drained. */
static inline int r3_gnss_config_switch(R3GnssConfig *c,uint32_t now,int tx_idle)
{
    if ((c->phase!=R3_GNSS_SWITCH && c->phase!=R3_GNSS_REPROBE) || !tx_idle ||
        (uint32_t)(now-c->phase_ms)<250U) return 0;
    const R3GnssConfigPhase next=c->phase==R3_GNSS_REPROBE?R3_GNSS_PROBE:R3_GNSS_VERIFY;
    c->baud=115200U; r3_gnss_config_stage(c,next,now); return 1;
}
static inline int r3_gnss_config_readback(const R3Ubx *u)
{
    const uint8_t *b=u->payload; size_t offset=4; uint32_t seen=0;
    if (u->length<4 || u->length>sizeof(u->payload) || b[0]!=1 || b[1]!=0 || b[2] || b[3]) return 0;
    while (offset<u->length) {
        if (u->length-offset<4U) return 0;
        const uint32_t key=r3_ubx_u32(b+offset); offset+=4;
        unsigned i=0; while (i<R3_GNSS_CONFIG_ITEMS && r3_gnss_config_items[i].key!=key) ++i;
        if (i==R3_GNSS_CONFIG_ITEMS || (seen&(1U<<i))) return 0;
        const R3GnssConfigItem *item=&r3_gnss_config_items[i];
        if (u->length-offset<item->bytes) return 0;
        uint32_t value=0;
        for (unsigned j=0;j<item->bytes;++j) value|=(uint32_t)b[offset++]<<(8U*j);
        if (value!=item->value) return 0;
        seen|=1U<<i;
    }
    return seen==((1U<<R3_GNSS_CONFIG_ITEMS)-1U);
}
/* Caller feeds only complete checksum-valid messages from its single UART parser. */
static inline void r3_gnss_config_message(R3GnssConfig *c,const R3Ubx *u,uint32_t now)
{
    r3_gnss_config_tick(c,now);
    if (c->phase==R3_GNSS_DISABLED || c->phase==R3_GNSS_FAILED) return;
    if (u->cls==0x0a && u->id==4 && u->length>=40U && u->length<=sizeof(u->payload) &&
        (u->length-40U)%30U==0) {
        char firmware[31]={0},protocol[17]={0};
        if (!r3_gnss_config_text(firmware,sizeof(firmware),u->payload,30)) return;
        for (unsigned i=40;i+30U<=u->length;i+=30U) {
            if (!memcmp(u->payload+i,"PROTVER=",8)) {
                if (protocol[0] || !r3_gnss_config_text(protocol,sizeof(protocol),u->payload+i+8,22)) {
                    r3_gnss_config_fail(c,R3_GNSS_PROTOCOL_ERROR); return;
                }
            }
        }
        memcpy(c->firmware,firmware,sizeof(firmware)); memcpy(c->protocol,protocol,sizeof(protocol));
        if (strcmp(protocol,c->installation.protocol)) { r3_gnss_config_fail(c,R3_GNSS_PROTOCOL_ERROR); return; }
        if (strcmp(firmware,c->installation.firmware)) { r3_gnss_config_fail(c,R3_GNSS_FIRMWARE_ERROR); return; }
        if (c->phase==R3_GNSS_PROBE && c->waiting) r3_gnss_config_stage(c,R3_GNSS_SET,now);
    } else if (u->cls==5 && u->id==0 && u->length==2U && u->payload[0]==6 &&
        ((u->payload[1]==0x8a && c->phase==R3_GNSS_SWITCH) ||
         (u->payload[1]==0x8b && c->phase==R3_GNSS_VERIFY && c->waiting))) {
        r3_gnss_config_fail(c,R3_GNSS_CONFIG_NAK);
    } else if (u->cls==6 && u->id==0x8b && c->phase==R3_GNSS_VERIFY && c->waiting) {
        if (!r3_gnss_config_readback(u)) { r3_gnss_config_fail(c,R3_GNSS_READBACK_ERROR); return; }
        c->verified=1; c->verified_ms=now; r3_gnss_config_stage(c,R3_GNSS_READY,now);
    }
}
#endif
