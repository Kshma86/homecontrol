#ifndef ROVER_GNSS_H
#define ROVER_GNSS_H
#include <stdint.h>
#include <string.h>

/* NAV-PVT layout: u-blox ZED-F9P UBX-18010854 R07, protocol 27.11. */
#define R3_GPS_WEEK_MS 604800000U
typedef struct {
    uint32_t itow, hacc;
    int32_t lat, lon, height, speed, course;
    uint8_t fix_type, fix_ok, carrier, satellites;
} R3Pvt;
typedef struct {
    uint8_t payload[512], state, cls, id, a, b, check_a;
    uint16_t length, offset;
    uint32_t last_byte, errors;
} R3Ubx;
typedef struct {
    R3Pvt pvt;
    uint32_t epoch, seq, acquired_ms, last_service_ms, first_ms, last_itow;
    uint8_t serviced, have_itow, recovering, valid;
} R3GnssSource;

static inline uint32_t r3_ubx_u32(const uint8_t *p)
{
    return (uint32_t)p[0] | (uint32_t)p[1]<<8 | (uint32_t)p[2]<<16 | (uint32_t)p[3]<<24;
}
static inline int32_t r3_ubx_i32(const uint8_t *p)
{
    const uint32_t u = r3_ubx_u32(p);
    return u <= 0x7fffffffU ? (int32_t)u : -1 - (int32_t)(~u);
}
static inline void r3_ubx_sum(R3Ubx *u, uint8_t byte)
{
    u->a = (uint8_t)(u->a + byte); u->b = (uint8_t)(u->b + u->a);
}
/* Returns 1 for a complete checksum-valid bounded message, never partial data. */
static inline int r3_ubx_byte(R3Ubx *u, uint8_t byte, uint32_t now)
{
    if (u->state && (uint32_t)(now-u->last_byte) > 100U) {
        u->state = 0; ++u->errors;
    }
    u->last_byte = now;
    switch (u->state) {
    case 0: if (byte == 0xb5) u->state = 1; break;
    case 1: u->state = byte == 0x62 ? 2 : (byte == 0xb5 ? 1 : 0); u->a = u->b = 0; break;
    case 2: u->cls = byte; r3_ubx_sum(u,byte); u->state = 3; break;
    case 3: u->id = byte; r3_ubx_sum(u,byte); u->state = 4; break;
    case 4: u->length = byte; r3_ubx_sum(u,byte); u->state = 5; break;
    case 5:
        u->length |= (uint16_t)byte << 8; r3_ubx_sum(u,byte);
        u->offset = 0; u->state = u->length ? 6 : 7; break;
    case 6:
        if (u->offset < sizeof(u->payload)) u->payload[u->offset] = byte;
        ++u->offset; r3_ubx_sum(u,byte);
        if (u->offset == u->length) u->state = 7;
        break;
    case 7: u->check_a = byte; u->state = 8; break;
    case 8:
        u->state = 0;
        if (u->check_a != u->a || byte != u->b) { ++u->errors; return 0; }
        return u->length <= sizeof(u->payload);
    default: u->state = 0; break;
    }
    return 0;
}
static inline int r3_ubx_pvt(const R3Ubx *u, R3Pvt *out)
{
    R3Pvt p;
    const uint8_t *b = u->payload;
    if (u->cls != 1U || u->id != 7U || u->length != 92U) return 0;
    p.itow = r3_ubx_u32(b); p.lon = r3_ubx_i32(b+24); p.lat = r3_ubx_i32(b+28);
    p.height = r3_ubx_i32(b+32); p.hacc = r3_ubx_u32(b+40);
    p.speed = r3_ubx_i32(b+60); p.course = r3_ubx_i32(b+64)/100;
    p.fix_type = b[20]; p.fix_ok = b[21]&1U; p.carrier = (b[21]>>6)&3U; p.satellites = b[23];
    if (p.itow >= R3_GPS_WEEK_MS) return 0;
    if (p.lat < -900000000 || p.lat > 900000000 || p.lon < -1800000000 || p.lon > 1800000000 ||
        p.fix_type > 5U || p.carrier > 2U || p.speed < 0) return 0;
    p.course = (p.course % 360000 + 360000) % 360000;
    if (b[78]&1U) p.fix_ok = 0;
    *out = p; return 1;
}
static inline void r3_gnss_invalidate(R3GnssSource *s)
{
    if (++s->epoch == 0U) s->epoch = 1U;
    s->seq = 1; s->valid = s->have_itow = 0; s->recovering = 1;
    s->pvt.fix_ok = 0;
}
static inline void r3_gnss_init(R3GnssSource *s)
{
    memset(s,0,sizeof(*s)); s->epoch = 1; s->recovering = 1;
}
/* Caller must discard its queued UART input before parsing again when true. */
static inline int r3_gnss_service(R3GnssSource *s, uint32_t now)
{
    const int gap = s->serviced && (uint32_t)(now-s->last_service_ms) > 50U;
    s->last_service_ms = now; s->serviced = 1;
    if (gap) r3_gnss_invalidate(s);
    return gap;
}
static inline int r3_gnss_report(R3GnssSource *s, const R3Pvt *p, uint32_t now)
{
    uint32_t delta = 0;
    if (s->have_itow) {
        if (p->itow == s->last_itow) return 0;
        if (p->itow < s->last_itow) {
            if (s->last_itow >= R3_GPS_WEEK_MS-2000U && p->itow <= 2000U)
                delta = R3_GPS_WEEK_MS-s->last_itow+p->itow;
            else r3_gnss_invalidate(s);
        } else delta = p->itow-s->last_itow;
    }
    if (!s->have_itow) s->first_ms = now;
    else if (s->recovering && delta == 200U && (uint32_t)(now-s->first_ms) >= 100U)
        s->recovering = 0;
    else if (s->recovering) s->first_ms = now;
    s->last_itow = p->itow; s->have_itow = 1; s->pvt = *p; s->acquired_ms = now;
    if (++s->seq == 0U) r3_gnss_invalidate(s);
    s->valid = !s->recovering;
    if (!s->valid) s->pvt.fix_ok = 0;
    return 1;
}
#endif
