#ifndef ROVER_CONFIGURATION_STORE_H
#define ROVER_CONFIGURATION_STORE_H
#include "rover_parameters.h"
#include "rover_request_router.h"

#define R3_CONFIG_RECORD_BYTES 512U
#define R3_CONFIG_SOURCE_MAX_MS 1500U
typedef enum { R3_CONFIG_PREPARED=1,R3_CONFIG_ACTIVE=2 } R3ConfigPhase;
typedef enum { R3_CONFIG_EMPTY,R3_CONFIG_OK,R3_CONFIG_PENDING,R3_CONFIG_FAULT } R3ConfigHealth;
typedef struct {
    uint64_t sequence;
    uint32_t board_crc,revision,expected_revision,epoch;
    R3ConfigPhase phase;
    char request_id[65],uid[25],esp[17],stm[17];
    R3Parameters parameters;
} R3ConfigRecord;
typedef struct {
    R3ConfigRecord latest,active;
    R3ConfigHealth health;
    unsigned slot;
    uint8_t has_active;
} R3ConfigStore;
typedef int (*R3ConfigRead)(void *,unsigned,uint8_t [R3_CONFIG_RECORD_BYTES]);
typedef int (*R3ConfigWrite)(void *,unsigned,const uint8_t [R3_CONFIG_RECORD_BYTES]);
typedef struct { R3ConfigRead read; R3ConfigWrite write; void *context; } R3ConfigIo;
/* Supplied from the live, independently bound peer session, never copied from
 * the durable record or an HC request. A reboot does not renew a pending job. */
typedef struct { char uid[25],esp[17],stm[17]; uint32_t board_crc; } R3ConfigBinding;
typedef struct {
    char request_id[65],uid[25],esp[17],stm[17];
    uint32_t board_crc,revision,parameters_crc,request_epoch,acquired_ms;
    uint8_t valid,disarmed,stopped,outputs_inhibited,manual_active,update_active;
} R3ConfigPeerProof;

static inline int r3_config_text(const char *s,size_t bytes)
{
    const char *end=(const char *)memchr(s,0,bytes);
    if (!end || end==s) return 0;
    for (const char *p=end;p<s+bytes;++p) if (*p) return 0;
    return 1;
}
static inline int r3_config_identity(const R3ConfigRecord *r)
{
    return r && r->board_crc && r3_config_text(r->uid,25) && r3_hex(r->uid,24) &&
        strcmp(r->uid,"000000000000000000000000") && strcmp(r->uid,"FFFFFFFFFFFFFFFFFFFFFFFF") &&
        r3_config_text(r->esp,17) && r3_hex(r->esp,16) && strcmp(r->esp,"0000000000000000") &&
        r3_config_text(r->stm,17) && r3_hex(r->stm,16) && strcmp(r->stm,"0000000000000000") &&
        r3_config_text(r->request_id,65) && r3_request_id(r->request_id) && r->epoch;
}
static inline int r3_config_record_valid(const R3ConfigRecord *r)
{
    return r3_config_identity(r) && r->expected_revision<UINT32_MAX &&
        r->revision==r->expected_revision+1U &&
        (r->phase==R3_CONFIG_PREPARED || r->phase==R3_CONFIG_ACTIVE) &&
        r->sequence==2ULL*r->revision-(r->phase==R3_CONFIG_PREPARED?1U:0U) &&
        r3_parameters_valid(&r->parameters);
}
static inline int r3_config_encode(uint8_t b[R3_CONFIG_RECORD_BYTES],const R3ConfigRecord *r)
{
    if (!b || !r3_config_record_valid(r)) return 0;
    memset(b,0,R3_CONFIG_RECORD_BYTES); memcpy(b,"RCF1",4);
    r3_update_put(b+4,1,2); r3_update_put(b+6,R3_CONFIG_RECORD_BYTES,2);
    r3_update_put(b+8,r->sequence,8); r3_update_put(b+16,r->board_crc,4);
    r3_update_put(b+20,r->revision,4); r3_update_put(b+24,r->expected_revision,4);
    r3_update_put(b+28,r->phase,4); memcpy(b+32,r->request_id,65);
    memcpy(b+100,r->uid,25); memcpy(b+128,r->esp,17); memcpy(b+148,r->stm,17);
    r3_update_put(b+168,r->epoch,4);
    if (!r3_parameters_encode(b+176,&r->parameters)) return 0;
    r3_update_put(b+508,r3_crc_update(UINT32_MAX,b,508)^UINT32_MAX,4); return 1;
}
static inline int r3_config_decode(const uint8_t b[R3_CONFIG_RECORD_BYTES],R3ConfigRecord *out)
{
    if (!b || !out || memcmp(b,"RCF1",4) || r3_update_u16(b+4)!=1 ||
        r3_update_u16(b+6)!=R3_CONFIG_RECORD_BYTES ||
        r3_update_u32(b+508)!=(r3_crc_update(UINT32_MAX,b,508)^UINT32_MAX)) return 0;
    R3ConfigRecord r={0}; uint8_t canonical[R3_CONFIG_RECORD_BYTES];
    r.sequence=r3_update_u64(b+8); r.board_crc=r3_update_u32(b+16);
    r.revision=r3_update_u32(b+20); r.expected_revision=r3_update_u32(b+24);
    r.phase=(R3ConfigPhase)r3_update_u32(b+28); memcpy(r.request_id,b+32,65);
    memcpy(r.uid,b+100,25); memcpy(r.esp,b+128,17); memcpy(r.stm,b+148,17);
    r.epoch=r3_update_u32(b+168);
    if (!r3_parameters_decode(b+176,&r.parameters) || !r3_config_encode(canonical,&r) ||
        memcmp(canonical,b,sizeof(canonical))) return 0;
    *out=r; return 1;
}
static inline int r3_config_same(const R3ConfigRecord *a,const R3ConfigRecord *b)
{
    uint8_t x[R3_CONFIG_RECORD_BYTES],y[R3_CONFIG_RECORD_BYTES];
    return r3_config_encode(x,a) && r3_config_encode(y,b) && !memcmp(x,y,sizeof(x));
}
/* Startup scan only. An invalid/uncertain key cannot be ignored just because
 * the other slot is valid. PENDING retains the previous active record but locks
 * admission; it is never silently promoted, rolled back or repaired here. */
static inline R3ConfigHealth r3_config_load(R3ConfigStore *store,const R3ConfigIo *io)
{
    if (!store) return R3_CONFIG_FAULT;
    R3ConfigStore next={0}; R3ConfigRecord records[2]={{0},{0}};
    uint8_t present[2]={0};
    if (!io || !io->read) { store->health=R3_CONFIG_FAULT; return store->health; }
    for (unsigned slot=0;slot<2;++slot) {
        uint8_t data[R3_CONFIG_RECORD_BYTES]; const int read=io->read(io->context,slot,data);
        if (!read) continue;
        if (read!=1 || !r3_config_decode(data,&records[slot])) {
            store->health=R3_CONFIG_FAULT; return store->health;
        }
        present[slot]=1;
    }
    if (!present[0] && !present[1]) { *store=next; return R3_CONFIG_EMPTY; }
    unsigned high=!present[0]?1:!present[1]?0:records[1].sequence>records[0].sequence?1:0;
    const R3ConfigRecord *r=&records[high],*old=&records[high^1U];
    if (present[high^1U]) {
        if (r->board_crc!=old->board_crc || strcmp(r->uid,old->uid) ||
            (r->sequence==old->sequence?!r3_config_same(r,old):
             (old->phase!=R3_CONFIG_ACTIVE || old->revision+1U!=r->revision))) {
            store->health=R3_CONFIG_FAULT; return store->health;
        }
    } else if (r->revision!=1U) { store->health=R3_CONFIG_FAULT; return store->health; }
    next.latest=*r; next.slot=high;
    next.health=r->phase==R3_CONFIG_ACTIVE?R3_CONFIG_OK:R3_CONFIG_PENDING;
    if (r->phase==R3_CONFIG_ACTIVE) { next.active=*r; next.has_active=1; }
    else if (present[high^1U] && old->phase==R3_CONFIG_ACTIVE) { next.active=*old; next.has_active=1; }
    *store=next; return next.health;
}
static inline int r3_config_locked(const R3ConfigStore *s)
{ return !s || s->health!=R3_CONFIG_OK || s->has_active!=1; }

/* Native owner passes an already parsed, fully bound PREPARED intent. No automatic
 * baseline write, HTTP callback IO, GPIO operation or factory-profile change. */
static inline const char *r3_config_prepare(R3ConfigStore *store,const R3ConfigIo *io,const R3ConfigRecord *intent)
{
    if (store && store->health==R3_CONFIG_FAULT) return "CONFIG_STORAGE_ERROR";
    if (!store || !io || !io->read || !io->write ||
        !r3_config_record_valid(intent) || intent->phase!=R3_CONFIG_PREPARED) return "CONFIG_INVALID";
    R3ConfigStore fresh={0}; const R3ConfigHealth health=r3_config_load(&fresh,io);
    if (health==R3_CONFIG_FAULT) { store->health=R3_CONFIG_FAULT; return "CONFIG_STORAGE_ERROR"; }
    *store=fresh;
    if (health!=R3_CONFIG_EMPTY) {
        if (fresh.latest.board_crc!=intent->board_crc || strcmp(fresh.latest.uid,intent->uid)) return "BOARD_MISMATCH";
        if (!strcmp(fresh.latest.request_id,intent->request_id)) {
            R3ConfigRecord retained=fresh.latest; retained.phase=R3_CONFIG_PREPARED; --retained.sequence;
            if (fresh.latest.phase==R3_CONFIG_PREPARED) ++retained.sequence;
            if (!r3_config_same(&retained,intent)) return "ID_CONFLICT";
            *store=fresh; return health==R3_CONFIG_OK?"ALREADY_COMMITTED":"PENDING";
        }
        if (health==R3_CONFIG_PENDING) { *store=fresh; return "CONFIG_BUSY"; }
    }
    const uint32_t revision=fresh.has_active?fresh.active.revision:0;
    if (intent->expected_revision!=revision) return "REVISION_CONFLICT";
    const unsigned slot=fresh.has_active?fresh.slot^1U:0U;
    uint8_t data[R3_CONFIG_RECORD_BYTES]; (void)r3_config_encode(data,intent);
    (void)io->write(io->context,slot,data);
    if (r3_config_load(&fresh,io)!=R3_CONFIG_PENDING || fresh.slot!=slot || !r3_config_same(&fresh.latest,intent)) {
        store->health=R3_CONFIG_FAULT; return "CONFIG_STORAGE_ERROR";
    }
    *store=fresh; return "PENDING";
}
static inline int r3_config_peer_valid(const R3ConfigRecord *r,const R3ConfigPeerProof *p,uint32_t now)
{
    return r3_config_record_valid(r) && p && p->valid==1 && p->disarmed==1 && p->stopped==1 &&
        p->outputs_inhibited==1 && p->manual_active==0 && p->update_active==0 &&
        now-p->acquired_ms<=R3_CONFIG_SOURCE_MAX_MS && p->board_crc==r->board_crc &&
        p->revision==r->revision && p->parameters_crc==r3_parameters_crc(&r->parameters) && p->request_epoch==r->epoch &&
        r3_config_text(p->request_id,65) && r3_config_text(p->uid,25) && r3_config_text(p->esp,17) &&
        r3_config_text(p->stm,17) && !strcmp(p->request_id,r->request_id) && !strcmp(p->uid,r->uid) &&
        !strcmp(p->esp,r->esp) && !strcmp(p->stm,r->stm);
}
static inline int r3_config_binding_current(const R3ConfigRecord *r,const R3ConfigBinding *live)
{
    return r3_config_identity(r) && live && r3_config_text(live->uid,25) &&
        r3_config_text(live->esp,17) && r3_config_text(live->stm,17) &&
        live->board_crc==r->board_crc && !strcmp(live->uid,r->uid) &&
        !strcmp(live->esp,r->esp) && !strcmp(live->stm,r->stm);
}
static inline const char *r3_config_commit(R3ConfigStore *store,const R3ConfigIo *io,
    const R3ConfigPeerProof *proof,const R3ConfigBinding *live,uint32_t now)
{
    if (!store || store->health!=R3_CONFIG_PENDING || !io || !io->read || !io->write) return "CONFIG_NOT_PENDING";
    R3ConfigStore fresh={0};
    if (r3_config_load(&fresh,io)!=R3_CONFIG_PENDING || !r3_config_same(&fresh.latest,&store->latest)) {
        store->health=R3_CONFIG_FAULT; return "CONFIG_STORAGE_ERROR";
    }
    if (!r3_config_binding_current(&fresh.latest,live) || !r3_config_peer_valid(&fresh.latest,proof,now))
        return "CONFIG_PEER_UNVERIFIED";
    R3ConfigRecord committed=fresh.latest; committed.phase=R3_CONFIG_ACTIVE; ++committed.sequence;
    uint8_t data[R3_CONFIG_RECORD_BYTES]; (void)r3_config_encode(data,&committed);
    (void)io->write(io->context,fresh.slot,data);
    if (r3_config_load(&fresh,io)!=R3_CONFIG_OK || !r3_config_same(&fresh.latest,&committed)) {
        store->health=R3_CONFIG_FAULT; return "CONFIG_STORAGE_ERROR";
    }
    *store=fresh; return "COMMITTED";
}
#endif
