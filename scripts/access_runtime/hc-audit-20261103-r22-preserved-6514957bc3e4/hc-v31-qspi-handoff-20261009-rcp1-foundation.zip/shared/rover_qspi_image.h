#ifndef ROVER_QSPI_IMAGE_H
#define ROVER_QSPI_IMAGE_H
#include "rover_qspi_layout.h"
#include "rover_update_image.h"

typedef struct { uint32_t bytes,profile_crc; char firmware[49]; } RqImageMetadata;

/* Structural validation only, not a hash check or boot/write authorization. */
static inline R3ImageError rq_image_header_fields(const uint8_t *h,size_t header_bytes,
    uint32_t image_bytes,uint32_t profile_crc,RqImageMetadata *out)
{
    if (!h || !out || header_bytes!=256U) return R3_IMAGE_BAD_HEADER;
    if (image_bytes<R3_UPDATE_IMAGE_MIN || image_bytes>RQ_APP_BYTES || image_bytes%32U)
        return R3_IMAGE_BAD_LENGTH;
    if (memcmp(h,"RFU2",4) || r3_update_u16(h+4)!=256U || r3_update_u16(h+6)!=2U ||
        r3_update_u32(h+24)!=RQ_LAYOUT_ID || r3_update_u16(h+46) || !r3_update_zero(h+100,156))
        return R3_IMAGE_BAD_HEADER;
    static const uint8_t target[16]={'S','T','M','3','2','H','7','4','3','V','G',0,0,0,0,0};
    if (memcmp(h+8,target,sizeof(target))) return R3_IMAGE_WRONG_TARGET;
    /* Image destination is always the internal APP, never a QSPI store number. */
    if (r3_update_u32(h+28)!=1U || r3_update_u32(h+32)!=RQ_APP_BASE)
        return R3_IMAGE_WRONG_SLOT;
    if (r3_update_u32(h+36)!=image_bytes) return R3_IMAGE_BAD_LENGTH;
    if (r3_update_u16(h+44)!=RQ_SERVICE_ABI) return R3_IMAGE_ABI_MISMATCH;
    if (r3_update_u16(h+40)!=3U || r3_update_u16(h+42)!=1U) return R3_IMAGE_BAD_HEADER;
    if (r3_update_u32(h+48)!=profile_crc) return R3_IMAGE_PROFILE_MISMATCH;
    RqImageMetadata image={0};
    if (!r3_update_firmware(image.firmware,h+52)) return R3_IMAGE_BAD_HEADER;
    image.bytes=image_bytes; image.profile_crc=profile_crc; *out=image;
    return R3_IMAGE_OK;
}
static inline R3ImageError rq_image_header(const uint8_t *prefix,size_t prefix_bytes,
    uint32_t image_bytes,uint32_t profile_crc,RqImageMetadata *out)
{
    if (!prefix || !out || prefix_bytes<1280U) return R3_IMAGE_BAD_HEADER;
    RqImageMetadata image={0};
    const R3ImageError result=rq_image_header_fields(prefix+1024U,256U,image_bytes,profile_crc,&image);
    if (result!=R3_IMAGE_OK) return result;
    const uint32_t reset=r3_update_u32(prefix+4);
    if (!r3_update_stack(r3_update_u32(prefix)) || !(reset&1U) ||
        (reset&~1U)<RQ_APP_BASE || (reset&~1U)-RQ_APP_BASE>=image_bytes) return R3_IMAGE_BAD_HEADER;
    *out=image; return R3_IMAGE_OK;
}
#endif
