#ifndef ROVER_QSPI_LAYOUT_H
#define ROVER_QSPI_LAYOUT_H
#include <stddef.h>
#include <stdint.h>

/* Separate from H743_2M_AB1; no existing updater may accept this layout. */
#define RQ_LAYOUT_NAME "H743_1M_QSPI_REC2"
#define RQ_LAYOUT_ID 2U
#define RQ_SERVICE_ABI 2U
#define RQ_MCU_TARGET "STM32H743VG"
#define RQ_INTERNAL_FLASH_KIB 1024U
#define RQ_LOADER_BASE 0x08000000U
#define RQ_LOADER_BYTES 0x00078000U
#define RQ_FACTORY_BASE 0x08078000U
#define RQ_FACTORY_BYTES 0x00008000U
#define RQ_APP_BASE 0x08100000U
#define RQ_APP_BYTES 0x00080000U
#define RQ_INTERNAL_SECTOR_BYTES 0x00020000U
#define RQ_NOR_BYTES 0x00800000U
#define RQ_NOR_ERASE_BYTES 4096U
#define RQ_NOR_PAGE_BYTES 256U
#define RQ_JOURNAL_BYTES 0x00020000U
#define RQ_STORE_BYTES 0x00100000U
#define RQ_RESERVED_BASE 0x00440000U

typedef enum {
    RQ_STORE_NONE, RQ_STORE_1, RQ_STORE_2, RQ_STORE_3, RQ_STORE_4
} RqStore;
typedef struct { uint32_t base,bytes; } RqRegion;

static inline int rq_span(uint32_t address,size_t bytes,RqRegion region)
{
    return bytes && region.bytes && address>=region.base &&
        address-region.base<region.bytes && bytes<=region.bytes-(address-region.base);
}
static inline RqRegion rq_store_region(RqStore store)
{
    RqRegion region={0,0};
    if (store>=RQ_STORE_1 && store<=RQ_STORE_4) {
        region.base=2U*RQ_JOURNAL_BYTES+((uint32_t)store-1U)*RQ_STORE_BYTES;
        region.bytes=RQ_STORE_BYTES;
    }
    return region;
}
static inline RqRegion rq_journal_region(unsigned bank)
{
    RqRegion region={0,0};
    if (bank<2U) { region.base=bank*RQ_JOURNAL_BYTES; region.bytes=RQ_JOURNAL_BYTES; }
    return region;
}
static inline int rq_internal_read_span(uint32_t address,size_t bytes)
{
    const RqRegion root={RQ_LOADER_BASE,RQ_LOADER_BYTES+RQ_FACTORY_BYTES};
    const RqRegion app={RQ_APP_BASE,RQ_APP_BYTES};
    return rq_span(address,bytes,root) || rq_span(address,bytes,app);
}
static inline int rq_internal_program_span(uint32_t address,size_t bytes)
{
    const RqRegion app={RQ_APP_BASE,RQ_APP_BYTES};
    return address%32U==0 && bytes%32U==0 && rq_span(address,bytes,app);
}
static inline int rq_internal_erase_address(uint32_t address)
{
    const RqRegion app={RQ_APP_BASE,RQ_APP_BYTES};
    return address%RQ_INTERNAL_SECTOR_BYTES==0 &&
        rq_span(address,RQ_INTERNAL_SECTOR_BYTES,app);
}
static inline int rq_nor_image_span(RqStore store,uint32_t offset,size_t bytes)
{
    const RqRegion region=rq_store_region(store);
    return region.bytes && offset<RQ_APP_BYTES && bytes && bytes<=RQ_APP_BYTES-offset;
}
#endif
