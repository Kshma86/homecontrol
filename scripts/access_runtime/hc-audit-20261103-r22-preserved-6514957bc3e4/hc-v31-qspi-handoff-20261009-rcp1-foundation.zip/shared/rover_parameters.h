#ifndef ROVER_PARAMETERS_H
#define ROVER_PARAMETERS_H
#include "rover_profile.h"
#include "rover_update_image.h"

/* Mutable operational data, distinct from factory/boot identity. No GPIO,
 * qualification, installed/commissioned bit or VESC firmware can enter RCP1.
 * Explicit little-endian serialization, never a persisted C struct. */
#define R3_PARAMETERS_BYTES 256U
#define R3_PARAMETERS_VERSION 1U
typedef struct {
    char robot_id[33];
    uint8_t blade_enabled;
    uint16_t wheel_track_mm,body_radius_mm,wheel_circumference_mm[2],wheel_motor_pole_pairs[2];
    uint32_t wheel_gear_ratio_milli[2];
    int8_t wheel_direction[2],blade_direction;
    uint16_t blade_pole_pairs,max_slope_mdeg;
    uint32_t blade_erpm_limit,blade_rpm_limit;
    int32_t antenna_body_mm[3],imu_mount_q_ppm[4];
    uint32_t wheel_erpm_limit[2],wheel_brake_ma[2],stop_deceleration_mm_s2,stop_test_max_ms;
    uint16_t max_linear_mm_s,max_yaw_mdeg_s,accel_mm_s2,gnss_hacc_limit_mm;
    uint16_t heading_accuracy_limit_mdeg,tilt_limit_mdeg;
    uint32_t yaw_accel_mdeg_s2;
} R3Parameters;

static inline int r3_parameters_valid(const R3Parameters *p)
{
    if (!p) return 0;
    const char *end=(const char *)memchr(p->robot_id,0,sizeof(p->robot_id));
    if (!end || end==p->robot_id || !r3_token(p->robot_id,32,1)) return 0;
    for (const char *c=p->robot_id;c<end;++c)
        if (*c=='.') return 0;
    for (const char *c=end;c<p->robot_id+sizeof(p->robot_id);++c) if (*c) return 0;
    if (p->blade_enabled>1 || p->wheel_track_mm<100 || p->wheel_track_mm>1500 ||
        p->body_radius_mm<100 || p->body_radius_mm>1000 || !p->blade_pole_pairs || p->blade_pole_pairs>100 ||
        (p->blade_direction!=-1 && p->blade_direction!=1) || p->max_slope_mdeg>15000 ||
        !p->blade_erpm_limit || p->blade_erpm_limit>25000 || !p->blade_rpm_limit || p->blade_rpm_limit>25000 ||
        (uint64_t)p->blade_rpm_limit*p->blade_pole_pairs>p->blade_erpm_limit ||
        !p->stop_deceleration_mm_s2 || !p->stop_test_max_ms || p->stop_test_max_ms>2000 ||
        p->max_linear_mm_s<50 || p->max_linear_mm_s>500 || p->max_yaw_mdeg_s<5000 || p->max_yaw_mdeg_s>45000 ||
        p->accel_mm_s2<50 || p->accel_mm_s2>500 || p->yaw_accel_mdeg_s2<5000 || p->yaw_accel_mdeg_s2>90000 ||
        p->gnss_hacc_limit_mm<20 || p->gnss_hacc_limit_mm>100 || p->heading_accuracy_limit_mdeg<1000 ||
        p->heading_accuracy_limit_mdeg>15000 || p->tilt_limit_mdeg<10000 || p->tilt_limit_mdeg>30000) return 0;
    for (unsigned i=0;i<2;++i)
        if (p->wheel_circumference_mm[i]<100 || p->wheel_circumference_mm[i]>2000 ||
            !p->wheel_motor_pole_pairs[i] || p->wheel_motor_pole_pairs[i]>100 ||
            p->wheel_gear_ratio_milli[i]<1000 || p->wheel_gear_ratio_milli[i]>1000000 ||
            (p->wheel_direction[i]!=-1 && p->wheel_direction[i]!=1) ||
            !p->wheel_erpm_limit[i] || p->wheel_erpm_limit[i]>6000 || p->wheel_brake_ma[i]>INT32_MAX) return 0;
    for (unsigned i=0;i<3;++i) if (p->antenna_body_mm[i]<-2000 || p->antenna_body_mm[i]>2000) return 0;
    int64_t norm=0;
    for (unsigned i=0;i<4;++i) {
        const int64_t q=p->imu_mount_q_ppm[i];
        if (q<-1000000 || q>1000000) return 0;
        norm+=q*q;
    }
    return norm>=999000LL*999000LL && norm<=1001000LL*1001000LL;
}
static inline int r3_parameters_encode(uint8_t b[R3_PARAMETERS_BYTES],const R3Parameters *p)
{
    if (!b || !r3_parameters_valid(p)) return 0;
    memset(b,0,R3_PARAMETERS_BYTES); memcpy(b,"RCP1",4);
    r3_update_put(b+4,R3_PARAMETERS_VERSION,2); r3_update_put(b+6,R3_PARAMETERS_BYTES,2);
    b[8]=p->blade_enabled; memcpy(b+12,p->robot_id,33);
#define R3_PARAM_PUT(name,offset,width) r3_update_put(b+(offset),p->name,width)
    R3_PARAM_PUT(wheel_track_mm,48,2); R3_PARAM_PUT(body_radius_mm,50,2);
    for (unsigned i=0;i<2;++i) {
        r3_update_put(b+52+2*i,p->wheel_circumference_mm[i],2);
        r3_update_put(b+56+2*i,p->wheel_motor_pole_pairs[i],2);
        r3_update_put(b+60+4*i,p->wheel_gear_ratio_milli[i],4);
        b[68+i]=(uint8_t)p->wheel_direction[i];
        r3_update_put(b+112+4*i,p->wheel_erpm_limit[i],4);
        r3_update_put(b+120+4*i,p->wheel_brake_ma[i],4);
    }
    b[70]=(uint8_t)p->blade_direction;
    R3_PARAM_PUT(blade_pole_pairs,72,2); R3_PARAM_PUT(max_slope_mdeg,74,2);
    R3_PARAM_PUT(blade_erpm_limit,76,4); R3_PARAM_PUT(blade_rpm_limit,80,4);
    for (unsigned i=0;i<3;++i) r3_update_put(b+84+4*i,(uint32_t)p->antenna_body_mm[i],4);
    for (unsigned i=0;i<4;++i) r3_update_put(b+96+4*i,(uint32_t)p->imu_mount_q_ppm[i],4);
    R3_PARAM_PUT(stop_deceleration_mm_s2,128,4); R3_PARAM_PUT(stop_test_max_ms,132,4);
    R3_PARAM_PUT(max_linear_mm_s,136,2); R3_PARAM_PUT(max_yaw_mdeg_s,138,2);
    R3_PARAM_PUT(accel_mm_s2,140,2); R3_PARAM_PUT(gnss_hacc_limit_mm,142,2);
    R3_PARAM_PUT(heading_accuracy_limit_mdeg,144,2); R3_PARAM_PUT(tilt_limit_mdeg,146,2);
    R3_PARAM_PUT(yaw_accel_mdeg_s2,148,4);
#undef R3_PARAM_PUT
    r3_update_put(b+252,r3_crc_update(UINT32_MAX,b,252)^UINT32_MAX,4); return 1;
}
static inline int r3_parameters_decode(const uint8_t b[R3_PARAMETERS_BYTES],R3Parameters *out)
{
    if (!b || !out || memcmp(b,"RCP1",4) || r3_update_u16(b+4)!=R3_PARAMETERS_VERSION ||
        r3_update_u16(b+6)!=R3_PARAMETERS_BYTES ||
        r3_update_u32(b+252)!=(r3_crc_update(UINT32_MAX,b,252)^UINT32_MAX)) return 0;
    R3Parameters p={0}; uint8_t canonical[R3_PARAMETERS_BYTES];
    p.blade_enabled=b[8]; memcpy(p.robot_id,b+12,33);
#define R3_PARAM_GET16(name,offset) p.name=r3_update_u16(b+(offset))
#define R3_PARAM_GET32(name,offset) p.name=r3_update_u32(b+(offset))
    R3_PARAM_GET16(wheel_track_mm,48); R3_PARAM_GET16(body_radius_mm,50);
    for (unsigned i=0;i<2;++i) {
        p.wheel_circumference_mm[i]=r3_update_u16(b+52+2*i);
        p.wheel_motor_pole_pairs[i]=r3_update_u16(b+56+2*i);
        p.wheel_gear_ratio_milli[i]=r3_update_u32(b+60+4*i);
        p.wheel_direction[i]=b[68+i]==255U?-1:b[68+i]==1U?1:0;
        p.wheel_erpm_limit[i]=r3_update_u32(b+112+4*i); p.wheel_brake_ma[i]=r3_update_u32(b+120+4*i);
    }
    p.blade_direction=b[70]==255U?-1:b[70]==1U?1:0;
    R3_PARAM_GET16(blade_pole_pairs,72); R3_PARAM_GET16(max_slope_mdeg,74);
    R3_PARAM_GET32(blade_erpm_limit,76); R3_PARAM_GET32(blade_rpm_limit,80);
    for (unsigned i=0;i<3;++i) {
        const uint32_t x=r3_update_u32(b+84+4*i);
        p.antenna_body_mm[i]=(int32_t)(x<=INT32_MAX?(int64_t)x:(int64_t)x-INT64_C(4294967296));
    }
    for (unsigned i=0;i<4;++i) {
        const uint32_t x=r3_update_u32(b+96+4*i);
        p.imu_mount_q_ppm[i]=(int32_t)(x<=INT32_MAX?(int64_t)x:(int64_t)x-INT64_C(4294967296));
    }
    R3_PARAM_GET32(stop_deceleration_mm_s2,128); R3_PARAM_GET32(stop_test_max_ms,132);
    R3_PARAM_GET16(max_linear_mm_s,136); R3_PARAM_GET16(max_yaw_mdeg_s,138);
    R3_PARAM_GET16(accel_mm_s2,140); R3_PARAM_GET16(gnss_hacc_limit_mm,142);
    R3_PARAM_GET16(heading_accuracy_limit_mdeg,144); R3_PARAM_GET16(tilt_limit_mdeg,146);
    R3_PARAM_GET32(yaw_accel_mdeg_s2,148);
#undef R3_PARAM_GET16
#undef R3_PARAM_GET32
    if (!r3_parameters_encode(canonical,&p) || memcmp(canonical,b,sizeof(canonical))) return 0;
    *out=p; return 1;
}
static inline uint32_t r3_parameters_crc(const R3Parameters *p)
{
    uint8_t b[R3_PARAMETERS_BYTES];
    return r3_parameters_encode(b,p)?r3_update_u32(b+252):0;
}
/* Construct controller input from mutable parameters plus READ-ONLY installed
 * safety wiring. This is not physical certification or a boot/image CRC. */
static inline int r3_parameters_profile(const R3Parameters *p,const R3Profile *board,R3Profile *out)
{
    if (!out || !board || board->installed!=1 || !board->crc || !r3_parameters_valid(p)) return 0;
    R3Profile v=*board; v.commissioned=0; v.crc=r3_parameters_crc(p);
    memcpy(v.robot_id,p->robot_id,sizeof(v.robot_id)); v.blade_enabled=p->blade_enabled;
#define R3_PARAM_COPY(name) v.name=p->name
    R3_PARAM_COPY(wheel_track_mm); R3_PARAM_COPY(body_radius_mm); R3_PARAM_COPY(blade_direction);
    R3_PARAM_COPY(blade_pole_pairs); R3_PARAM_COPY(max_slope_mdeg); R3_PARAM_COPY(blade_erpm_limit);
    R3_PARAM_COPY(blade_rpm_limit); R3_PARAM_COPY(stop_deceleration_mm_s2); R3_PARAM_COPY(stop_test_max_ms);
    R3_PARAM_COPY(max_linear_mm_s); R3_PARAM_COPY(max_yaw_mdeg_s); R3_PARAM_COPY(accel_mm_s2);
    R3_PARAM_COPY(gnss_hacc_limit_mm); R3_PARAM_COPY(heading_accuracy_limit_mdeg);
    R3_PARAM_COPY(tilt_limit_mdeg); R3_PARAM_COPY(yaw_accel_mdeg_s2);
#undef R3_PARAM_COPY
    memcpy(v.wheel_circumference_mm,p->wheel_circumference_mm,sizeof(v.wheel_circumference_mm));
    memcpy(v.wheel_motor_pole_pairs,p->wheel_motor_pole_pairs,sizeof(v.wheel_motor_pole_pairs));
    memcpy(v.wheel_gear_ratio_milli,p->wheel_gear_ratio_milli,sizeof(v.wheel_gear_ratio_milli));
    memcpy(v.wheel_direction,p->wheel_direction,sizeof(v.wheel_direction));
    memcpy(v.antenna_body_mm,p->antenna_body_mm,sizeof(v.antenna_body_mm));
    memcpy(v.imu_mount_q_ppm,p->imu_mount_q_ppm,sizeof(v.imu_mount_q_ppm));
    memcpy(v.wheel_erpm_limit,p->wheel_erpm_limit,sizeof(v.wheel_erpm_limit));
    memcpy(v.wheel_brake_ma,p->wheel_brake_ma,sizeof(v.wheel_brake_ma));
    *out=v; return 1;
}
#endif
