#ifndef ROVER_GEOMETRY_H
#define ROVER_GEOMETRY_H
#include <stdint.h>
#include <math.h>

typedef struct { int32_t x, y; } R3Point;
typedef struct { uint32_t offset; uint16_t count; } R3Ring;

static inline uint16_t r3_le16(const uint8_t *p) { return (uint16_t)p[0] | ((uint16_t)p[1] << 8); }
static inline uint32_t r3_le32(const uint8_t *p)
{
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}
static inline R3Point r3_point(const uint8_t *p)
{
    R3Point v; v.x = (int32_t)r3_le32(p); v.y = (int32_t)r3_le32(p + 4); return v;
}
static inline R3Point r3_vertex(const uint8_t *p, R3Ring ring, unsigned i)
{
    return r3_point(p + ring.offset + (i % ring.count) * 8U);
}
static inline int r3_coord_valid(R3Point p)
{
    return p.x >= -1000000 && p.x <= 1000000 && p.y >= -1000000 && p.y <= 1000000 &&
           (int64_t)p.x * p.x + (int64_t)p.y * p.y <= INT64_C(1000000000000);
}
static inline int64_t r3_orient(R3Point a, R3Point b, R3Point c)
{
    return ((int64_t)b.x - a.x) * ((int64_t)c.y - a.y) -
           ((int64_t)b.y - a.y) * ((int64_t)c.x - a.x);
}
static inline int r3_on_segment(R3Point a, R3Point b, R3Point p)
{
    return !r3_orient(a, b, p) && p.x >= (a.x < b.x ? a.x : b.x) &&
        p.x <= (a.x > b.x ? a.x : b.x) && p.y >= (a.y < b.y ? a.y : b.y) &&
        p.y <= (a.y > b.y ? a.y : b.y);
}
static inline int r3_intersect(R3Point a, R3Point b, R3Point c, R3Point d)
{
    int64_t ab_c = r3_orient(a, b, c), ab_d = r3_orient(a, b, d);
    int64_t cd_a = r3_orient(c, d, a), cd_b = r3_orient(c, d, b);
    if ((!ab_c && r3_on_segment(a, b, c)) || (!ab_d && r3_on_segment(a, b, d)) ||
        (!cd_a && r3_on_segment(c, d, a)) || (!cd_b && r3_on_segment(c, d, b))) return 1;
    return ((ab_c < 0 && ab_d > 0) || (ab_c > 0 && ab_d < 0)) &&
           ((cd_a < 0 && cd_b > 0) || (cd_a > 0 && cd_b < 0));
}
static inline double r3_point_distance2(R3Point p, R3Point a, R3Point b)
{
    double dx = (double)b.x - a.x, dy = (double)b.y - a.y;
    double px = (double)p.x - a.x, py = (double)p.y - a.y;
    double length = dx * dx + dy * dy;
    double t = length ? (px * dx + py * dy) / length : 0;
    if (t < 0) t = 0; else if (t > 1) t = 1;
    px -= t * dx; py -= t * dy;
    return px * px + py * py;
}
static inline double r3_segment_distance2(R3Point a, R3Point b, R3Point c, R3Point d)
{
    double result, v;
    if (r3_intersect(a, b, c, d)) return 0;
    result = r3_point_distance2(a, c, d);
    v = r3_point_distance2(b, c, d); if (v < result) result = v;
    v = r3_point_distance2(c, a, b); if (v < result) result = v;
    v = r3_point_distance2(d, a, b); if (v < result) result = v;
    return result;
}
/* Division-free winding test: integer orientations make edge decisions exact. */
static inline int r3_inside(const uint8_t *data, R3Ring ring, R3Point p)
{
    unsigned i; int winding = 0;
    for (i = 0; i < ring.count; ++i) {
        R3Point a = r3_vertex(data, ring, i), b = r3_vertex(data, ring, i + 1U);
        int64_t side = r3_orient(a, b, p);
        if (!side && r3_on_segment(a, b, p)) return 0;
        if (a.y <= p.y && b.y > p.y && side > 0) ++winding;
        if (a.y > p.y && b.y <= p.y && side < 0) --winding;
    }
    return winding != 0;
}
#endif
