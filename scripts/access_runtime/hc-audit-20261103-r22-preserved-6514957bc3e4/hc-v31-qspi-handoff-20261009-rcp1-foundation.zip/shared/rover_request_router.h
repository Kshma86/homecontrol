#ifndef ROVER_REQUEST_ROUTER_H
#define ROVER_REQUEST_ROUTER_H

#include "rover_protocol.h"

#define R3_REQUEST_CACHE 64U
#define R3_REQUEST_FINGERPRINT 256U

typedef enum { R3_PENDING, R3_APPLIED, R3_REJECTED, R3_UNKNOWN } R3RequestStatus;

typedef struct {
    char id[65], fingerprint[R3_REQUEST_FINGERPRINT], command[25], peer[17];
    char wire[R3_MAX_FRAME_BYTES + 1U], code[25], state[17];
    uint32_t request, started, detail, epoch, state_seq, timeout_ms, resource;
    uint16_t wire_length;
    uint8_t used, stop, retries, mqtt, dirty, has_state;
    R3RequestStatus status;
} R3Request;

typedef struct {
    R3Request entries[R3_REQUEST_CACHE];
    R3Request transfer;
    unsigned cursor, rate_count, rate_cursor;
    uint32_t admitted[5];
    uint8_t reconcile;
} R3Requests;

typedef struct {
    uint32_t request, detail, epoch, state_seq;
    const char *code, *state, *store, *outcome;
    uint8_t ok;
} R3Ack;

static inline int r3_ack_code(int ok, const char *code)
{
    return ok ? !strcmp(code, "OK") : r3_enum(code,
        "UPDATE_MODE|INVALID_PAYLOAD|OUT_OF_RANGE|UNKNOWN_COMMAND|BAD_STATE|BUSY|NOT_READY|"
        "NOT_STOPPED|NOT_COMMISSIONED|SAFETY_ACTIVE|FAULT_ACTIVE|GNSS_STALE|GNSS_QUALITY|"
        "IMU_STALE|HEADING_QUALITY|HEADING_UNREFERENCED|MOTOR_UNAVAILABLE|MISSION_MISMATCH|"
        "REPOSITION_REQUIRED|GEOFENCE|INCOMPATIBLE_VERSION|PROFILE_MISMATCH|STALE_SESSION|"
        "STALE_EPOCH|STALE_REQUEST|ID_CONFLICT|LEASE_MISMATCH|UPLOAD_MISMATCH|BAD_OFFSET|"
        "CANCELLED|INTERNAL|BAD_MAGIC|BAD_VERSION|BAD_LENGTH|BAD_CRC|BAD_UUID|BAD_REVISION|"
        "BAD_RESERVED|LIMIT_EXCEEDED|BAD_ORIGIN|BAD_POLYGON|BAD_SEGMENT|BAD_SPEED|BAD_BLADE|"
        "PATH_OUTSIDE|VALIDATION_TIMEOUT");
}

static inline int r3_ack_decode(char *body, R3Ack *out)
{
    char *f[9];
    R3Ack ack = {0};
    if (r3_fields(body, f, 9U) != 9U ||
        !r3_u32(f[0], &ack.request) || !ack.request || !r3_enum(f[1], "OK|ERR") ||
        !r3_ack_code(!strcmp(f[1], "OK"), f[2]) || !r3_u32(f[3], &ack.detail) ||
        !r3_u32(f[4], &ack.epoch) || !r3_u32(f[5], &ack.state_seq) ||
        !r3_enum(f[6], "DISARMED|IDLE|MANUAL|AUTO|PAUSED|FAULT|MAINTENANCE") ||
        !r3_enum(f[7], "EMPTY|RECEIVING|VALIDATING|READY") ||
        !r3_enum(f[8], "NONE|RUNNING|PAUSED|COMPLETED|STOPPED|FAULTED")) return 0;
    ack.ok = (uint8_t)!strcmp(f[1], "OK");
    ack.code = f[2]; ack.state = f[6]; ack.store = f[7]; ack.outcome = f[8];
    *out = ack;
    return 1;
}

static inline int r3_request_id(const char *id)
{
    size_t i, n = id ? strlen(id) : 0U;
    if (!n || n > 64U) return 0;
    for (i = 0; i < n; ++i) {
        char c = id[i];
        if (!((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') ||
              (c >= '0' && c <= '9') || c == '_' || c == '-')) return 0;
    }
    return 1;
}

static inline R3Request *r3_request_find(R3Requests *q, const char *id)
{
    unsigned i;
    for (i = 0; i < R3_REQUEST_CACHE; ++i)
        if (q->entries[i].used && !strcmp(q->entries[i].id, id)) return &q->entries[i];
    return NULL;
}

static inline int r3_request_match(R3Requests *q, const char *id, const char *fingerprint,
                                    R3Request **result)
{
    *result = r3_request_find(q, id);
    if (!*result) return 0;
    return strcmp((*result)->fingerprint, fingerprint) ? -1 : 1;
}

static inline R3Request *r3_request_pending(R3Requests *q, int stop)
{
    unsigned i;
    if (!stop && q->transfer.used && q->transfer.status == R3_PENDING) return &q->transfer;
    for (i = 0; i < R3_REQUEST_CACHE; ++i) {
        R3Request *r = &q->entries[i];
        if (r->used && r->status == R3_PENDING && r->wire_length && r->stop == !!stop) return r;
    }
    return NULL;
}

/* The rolling window counts original UART admissions, never retries/cache hits. */
static inline int r3_request_rate_ready(const R3Requests *q, uint32_t now)
{
    return q->rate_count < 5U || (uint32_t)(now - q->admitted[q->rate_cursor]) >= 1000U;
}

static inline void r3_request_rate_commit(R3Requests *q, uint32_t now)
{
    q->admitted[q->rate_cursor] = now;
    q->rate_cursor = (q->rate_cursor + 1U) % 5U;
    if (q->rate_count < 5U) ++q->rate_count;
}

/* Pending entries, including coalesced STOP observers, are never evicted. */
static inline R3Request *r3_request_store(R3Requests *q, const char *id,
    const char *fingerprint, const char *command, const char *peer,
    uint32_t request, const char *wire, uint32_t now, int stop)
{
    unsigned i;
    size_t n = wire ? strlen(wire) : 0U;
    if (!r3_request_id(id) || strlen(fingerprint) >= R3_REQUEST_FINGERPRINT ||
        strlen(command) > 24U || !r3_hex(peer, 16U) || n > R3_MAX_FRAME_BYTES ||
        r3_request_find(q, id)) return NULL;
    for (i = 0; i < R3_REQUEST_CACHE; ++i) {
        unsigned slot = (q->cursor + i) % R3_REQUEST_CACHE;
        R3Request *r = &q->entries[slot];
        if (r->used && r->status == R3_PENDING) continue;
        memset(r, 0, sizeof(*r));
        strcpy(r->id, id); strcpy(r->fingerprint, fingerprint);
        strcpy(r->command, command); strcpy(r->peer, peer);
        if (n) memcpy(r->wire, wire, n + 1U);
        r->wire_length = (uint16_t)n;
        r->used = 1; r->stop = (uint8_t)!!stop;
        r->request = request; r->started = now; r->timeout_ms = 1000U;
        r->status = R3_PENDING;
        q->cursor = (slot + 1U) % R3_REQUEST_CACHE;
        return r;
    }
    return NULL;
}

static inline void r3_request_finish(R3Request *r, R3RequestStatus status, const char *code)
{
    r->status = status;
    strncpy(r->code, code, sizeof(r->code) - 1U);
    r->code[sizeof(r->code) - 1U] = 0;
    r->dirty = 1;
}

static inline void r3_request_unknown(R3Requests *q, uint32_t request,
                                      const char *peer, const char *code)
{
    unsigned i;
    for (i = 0; i <= R3_REQUEST_CACHE; ++i) {
        R3Request *r = i == R3_REQUEST_CACHE ? &q->transfer : &q->entries[i];
        if (r->used && r->status == R3_PENDING && r->request == request && !strcmp(r->peer, peer))
            r3_request_finish(r, R3_UNKNOWN, code);
    }
    q->reconcile = 1;
}

static inline void r3_request_link_lost(R3Requests *q)
{
    unsigned i;
    for (i = 0; i <= R3_REQUEST_CACHE; ++i) {
        R3Request *r = i == R3_REQUEST_CACHE ? &q->transfer : &q->entries[i];
        if (r->used && r->status == R3_PENDING) r3_request_finish(r, R3_UNKNOWN, "LINK_LOST");
    }
    q->reconcile = 1;
}

/* A terminal result is immutable. Late ACKs cannot rewrite UNKNOWN or STATE. */
static inline int r3_request_ack(R3Requests *q, const char *peer, uint32_t request, uint32_t now,
    int ok, const char *code, uint32_t detail, uint32_t epoch, uint32_t seq, const char *state)
{
    unsigned i;
    int matched = 0;
    if (!r3_ack_code(ok, code) || strlen(state) > 16U) return 0;
    for (i = 0; i <= R3_REQUEST_CACHE; ++i) {
        R3Request *r = i == R3_REQUEST_CACHE ? &q->transfer : &q->entries[i];
        if (!r->used || r->status != R3_PENDING || !request ||
            r->request != request || strcmp(r->peer, peer)) continue;
        if ((uint32_t)(now - r->started) >= (r->timeout_ms ? r->timeout_ms : 1000U)) {
            r3_request_finish(r, R3_UNKNOWN, "TIMEOUT");
            q->reconcile = 1;
            continue;
        }
        r->detail = detail; r->epoch = epoch; r->state_seq = seq;
        strcpy(r->state, state); r->has_state = 1;
        r3_request_finish(r, ok ? R3_APPLIED : R3_REJECTED, code);
        matched = 1;
    }
    return matched;
}

/* At most one retry per worker pass; expired requests never get a catch-up send. */
static inline R3Request *r3_request_retry(R3Requests *q, uint32_t now)
{
    int priority;
    for (priority = 1; priority >= 0; --priority) {
        R3Request *r = r3_request_pending(q, priority);
        uint32_t age;
        if (!r) continue;
        age = (uint32_t)(now - r->started);
        if (age >= (r->timeout_ms ? r->timeout_ms : 1000U)) {
            r3_request_unknown(q, r->request, r->peer, "TIMEOUT");
            continue;
        }
        if (r->retries < 2U && age >= 250U * (r->retries + 1U)) {
            ++r->retries;
            return r;
        }
    }
    return NULL;
}

#endif
