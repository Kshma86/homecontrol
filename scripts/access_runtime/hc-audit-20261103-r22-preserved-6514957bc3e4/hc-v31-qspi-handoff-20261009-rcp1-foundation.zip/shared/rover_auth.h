#ifndef ROVER_AUTH_H
#define ROVER_AUTH_H
#include <stddef.h>
#include <stdint.h>
#include <string.h>

static inline int r3_api_token(const char *token)
{
    if (!token || strlen(token)!=64U) return 0;
    for (unsigned i=0;i<64U;++i)
        if (!((token[i]>='0' && token[i]<='9') || (token[i]>='a' && token[i]<='f') ||
              (token[i]>='A' && token[i]<='F'))) return 0;
    return 1;
}
static inline int r3_bearer_authorized(const char *token, const char *header, size_t length)
{
    if (!r3_api_token(token) || !header || length!=71U || memcmp(header,"Bearer ",7U)) return 0;
    volatile uint8_t difference=0;
    for (unsigned i=0;i<64U;++i) difference=(uint8_t)(difference | (uint8_t)(token[i]^header[i+7U]));
    return difference==0;
}
#endif
