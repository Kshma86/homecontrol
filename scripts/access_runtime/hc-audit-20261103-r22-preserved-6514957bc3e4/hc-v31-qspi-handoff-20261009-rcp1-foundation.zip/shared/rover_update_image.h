#ifndef ROVER_UPDATE_IMAGE_H
#define ROVER_UPDATE_IMAGE_H
#include "rover_protocol.h"

#define R3_UPDATE_LAYOUT_ID 1U
#define R3_UPDATE_SLOT_A_BASE 0x08040000U
#define R3_UPDATE_SLOT_B_BASE 0x08140000U
#define R3_UPDATE_IMAGE_MAX 786432U
#define R3_UPDATE_IMAGE_MIN 1280U
#define R3_UPDATE_HEADER_OFFSET 1024U
#define R3_UPDATE_HEADER_BYTES 256U
#define R3_UPDATE_FLASH_WORD 32U
typedef enum { R3_SLOT_NONE, R3_SLOT_A, R3_SLOT_B } R3UpdateSlot;
typedef enum {
    R3_IMAGE_OK, R3_IMAGE_BAD_LENGTH, R3_IMAGE_BAD_HEADER, R3_IMAGE_WRONG_TARGET,
    R3_IMAGE_WRONG_SLOT, R3_IMAGE_PROFILE_MISMATCH, R3_IMAGE_ABI_MISMATCH
} R3ImageError;
typedef struct {
    R3UpdateSlot slot;
    uint32_t bytes, profile_crc;
    uint16_t major, minor, abi;
    char firmware[49];
} R3ImageMetadata;

static inline uint32_t r3_update_u32(const uint8_t *b)
{
    return (uint32_t)b[0] | (uint32_t)b[1]<<8 | (uint32_t)b[2]<<16 | (uint32_t)b[3]<<24;
}
static inline uint16_t r3_update_u16(const uint8_t *b)
{
    return (uint16_t)((uint16_t)b[0] | (uint16_t)b[1]<<8);
}
static inline uint64_t r3_update_u64(const uint8_t *b)
{
    return (uint64_t)r3_update_u32(b) | (uint64_t)r3_update_u32(b+4)<<32;
}
static inline void r3_update_put(uint8_t *b,uint64_t value,unsigned bytes)
{
    for (unsigned i=0;i<bytes;++i) b[i]=(uint8_t)(value>>(8U*i));
}
static inline int r3_update_zero(const uint8_t *b,size_t bytes)
{
    for (size_t i=0;i<bytes;++i) if (b[i]) return 0;
    return 1;
}
static inline int r3_update_length(uint32_t bytes)
{
    return bytes>=R3_UPDATE_IMAGE_MIN && bytes<=R3_UPDATE_IMAGE_MAX && bytes%R3_UPDATE_FLASH_WORD==0;
}
static inline uint32_t r3_update_slot_base(R3UpdateSlot slot)
{
    return slot==R3_SLOT_A?R3_UPDATE_SLOT_A_BASE:slot==R3_SLOT_B?R3_UPDATE_SLOT_B_BASE:0;
}
static inline R3UpdateSlot r3_update_inactive(R3UpdateSlot confirmed)
{
    return confirmed==R3_SLOT_A?R3_SLOT_B:confirmed==R3_SLOT_B || confirmed==R3_SLOT_NONE?R3_SLOT_A:R3_SLOT_NONE;
}
static inline int r3_update_firmware(char out[49],const uint8_t bytes[48])
{
    size_t n=0; while (n<48U && bytes[n]) { out[n]=(char)bytes[n]; ++n; }
    out[n]=0;
    return r3_token(out,48U,1) && r3_update_zero(bytes+n,48U-n);
}
static inline int r3_update_stack(uint32_t stack)
{
    static const uint32_t ram[][2]={{0x20000000U,0x20020000U},{0x24000000U,0x24080000U},
        {0x30000000U,0x30048000U},{0x38000000U,0x38010000U}};
    if (stack&7U) return 0;
    for (unsigned i=0;i<sizeof(ram)/sizeof(ram[0]);++i)
        if (stack>ram[i][0] && stack<=ram[i][1]) return 1;
    return 0;
}
/* Metadata/vector validation only: the caller must independently verify full SHA-256. */
static inline R3ImageError r3_update_image_header(const uint8_t *prefix,size_t prefix_bytes,
    uint32_t image_bytes,R3UpdateSlot expected_slot,uint32_t expected_profile,int require_v31,R3ImageMetadata *out)
{
    R3ImageMetadata image={R3_SLOT_NONE,0,0,0,0,0,{0}};
    if (!prefix || !out) return R3_IMAGE_BAD_HEADER;
    if (!r3_update_length(image_bytes)) return R3_IMAGE_BAD_LENGTH;
    if (prefix_bytes<R3_UPDATE_HEADER_OFFSET+R3_UPDATE_HEADER_BYTES) return R3_IMAGE_BAD_HEADER;
    const uint8_t *h=prefix+R3_UPDATE_HEADER_OFFSET;
    if (memcmp(h,"RFU1",4) || r3_update_u16(h+4)!=256U || r3_update_u16(h+6)!=1U ||
        r3_update_u32(h+24)!=R3_UPDATE_LAYOUT_ID || r3_update_u16(h+46) || !r3_update_zero(h+100,156))
        return R3_IMAGE_BAD_HEADER;
    static const uint8_t target[16]={'S','T','M','3','2','H','7','4','3','V','I',0,0,0,0,0};
    if (memcmp(h+8,target,sizeof(target))) return R3_IMAGE_WRONG_TARGET;
    const uint32_t slot=r3_update_u32(h+28);
    if ((slot!=R3_SLOT_A && slot!=R3_SLOT_B) || slot!=(uint32_t)expected_slot) return R3_IMAGE_WRONG_SLOT;
    image.slot=(R3UpdateSlot)slot; image.bytes=r3_update_u32(h+36); image.profile_crc=r3_update_u32(h+48);
    image.major=r3_update_u16(h+40); image.minor=r3_update_u16(h+42); image.abi=r3_update_u16(h+44);
    if (image.bytes!=image_bytes) return R3_IMAGE_BAD_LENGTH;
    if (image.abi!=1U) return R3_IMAGE_ABI_MISMATCH;
    if (!image.major || (require_v31 && (image.major!=3U || image.minor!=1U))) return R3_IMAGE_BAD_HEADER;
    if (image.profile_crc!=expected_profile) return R3_IMAGE_PROFILE_MISMATCH;
    const uint32_t base=r3_update_slot_base(image.slot),reset=r3_update_u32(prefix+4);
    if (r3_update_u32(h+32)!=base || !r3_update_stack(r3_update_u32(prefix)) || !(reset&1U) ||
        (reset&~1U)<base || (reset&~1U)>=base+image_bytes || !r3_update_firmware(image.firmware,h+52))
        return R3_IMAGE_BAD_HEADER;
    *out=image; return R3_IMAGE_OK;
}
#endif
