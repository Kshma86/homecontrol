#ifndef ROVER_PROTOCOL_H
#define ROVER_PROTOCOL_H

#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define R3_MAX_FRAME_BYTES 512U
#define R3_MAX_FIELDS 32U
#define R3_PEER_TIMEOUT_MS 750U
#define R3_STATE_TIMEOUT_MS 1500U
#define R3_PARTIAL_TIMEOUT_MS 100U

typedef struct {
    char *src;
    char *dst;
    uint32_t seq;
    char *kind;
    char *body;
} R3Frame;

typedef struct {
    char line[R3_MAX_FRAME_BYTES + 1U];
    uint16_t length;
    uint8_t dropping;
    uint8_t cr_seen;
    uint32_t last_byte_ms;
    uint32_t errors;
} R3Stream;

typedef struct {
    uint32_t seq, epoch, event;
    char state[12], phase[6], store[11], uuid[33], outcome[10], reason[24];
    uint32_t revision, crc, index, count, faults, lease, input_seq;
    uint8_t stopped, ready_start, ready_resume;
} R3State;

typedef struct {
    uint32_t epoch, seq, age_ms, received_ms;
    uint8_t seen, valid;
} R3Sample;

typedef struct {
    uint32_t id, received, total, detail;
    char store[11], code[25];
} R3Upload;

typedef struct {
    int32_t lat, lon, height, yaw, pitch, roll;
    uint32_t itow, hacc, speed, course, accuracy;
    uint8_t fix_type, fix_ok, carrier, satellites;
} R3SensorValues;

static inline int r3_hex(const char *s, size_t n)
{
    size_t i;
    if (s == NULL || strlen(s) != n) return 0;
    for (i = 0; i < n; ++i)
        if (!((s[i] >= '0' && s[i] <= '9') || (s[i] >= 'A' && s[i] <= 'F'))) return 0;
    return 1;
}

static inline int r3_u32(const char *s, uint32_t *out)
{
    uint32_t v = 0;
    if (s == NULL || *s == '\0') return 0;
    while (*s != '\0') {
        uint32_t digit;
        if (*s < '0' || *s > '9') return 0;
        digit = (uint32_t)(*s++ - '0');
        if (v > (UINT32_MAX - digit) / 10U) return 0;
        v = v * 10U + digit;
    }
    *out = v;
    return 1;
}

static inline int r3_i32(const char *s, int32_t *out)
{
    uint32_t v;
    int negative;
    if (s == NULL) return 0;
    negative = *s == '-';
    if (!r3_u32(s + negative, &v) || v > (negative ? 2147483648U : 2147483647U)) return 0;
    *out = negative ? (int32_t)(-(int64_t)v) : (int32_t)v;
    return 1;
}

static inline int r3_hex_u32(const char *s, uint32_t *out)
{
    uint32_t v = 0;
    size_t i;
    if (!r3_hex(s, 8U)) return 0;
    for (i = 0; i < 8U; ++i)
        v = (v << 4U) | (uint32_t)(s[i] <= '9' ? s[i] - '0' : s[i] - 'A' + 10);
    *out = v;
    return 1;
}

static inline uint32_t r3_crc_update(uint32_t crc, const uint8_t *data, size_t n)
{
    static const uint32_t nibble[16]={
        0x00000000U,0x1DB71064U,0x3B6E20C8U,0x26D930ACU,0x76DC4190U,0x6B6B51F4U,0x4DB26158U,0x5005713CU,
        0xEDB88320U,0xF00F9344U,0xD6D6A3E8U,0xCB61B38CU,0x9B64C2B0U,0x86D3D2D4U,0xA00AE278U,0xBDBDF21CU
    };
    size_t i;
    for (i = 0; i < n; ++i) {
        crc ^= data[i];
        crc=(crc>>4U)^nibble[crc&15U];
        crc=(crc>>4U)^nibble[crc&15U];
    }
    return crc;
}

static inline uint32_t r3_mission_crc_update(uint32_t crc, const uint8_t *data,
                                            size_t n, uint32_t offset)
{
    size_t i;
    for (i = 0; i < n; ++i) {
        const uint8_t b = (offset + i >= 12U && offset + i < 16U) ? 0U : data[i];
        crc = r3_crc_update(crc, &b, 1U);
    }
    return crc;
}

static inline int r3_newer(uint32_t seq, uint32_t previous)
{
    const uint32_t delta = seq - previous;
    return delta != 0U && delta < 0x80000000U;
}

static inline size_t r3_fields(char *body, char **fields, size_t capacity)
{
    size_t count = 0;
    char *p = body;
    if (body == NULL || *body == '\0') return 0;
    for (;;) {
        char *comma;
        if (count == capacity || *p == '\0') return 0;
        fields[count++] = p;
        comma = strchr(p, ',');
        if (comma == NULL) return count;
        *comma = '\0';
        p = comma + 1;
    }
}

static inline int r3_token(const char *s, size_t max, int identifier)
{
    size_t i, n = strlen(s);
    if (n == 0 || n > max) return 0;
    for (i = 0; i < n; ++i) {
        const char c = s[i];
        if ((c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_') continue;
        if (identifier && ((c >= 'a' && c <= 'z') || c == '.' || c == '-')) continue;
        return 0;
    }
    return 1;
}

/* Decode only a complete line without its LF; reject before mutating fields. */
static inline int r3_decode(char *line, R3Frame *out)
{
    char *fields[7], *p, *last;
    uint32_t crc, seq;
    size_t i, n = strlen(line);
    if (n == 0 || n + 1U > R3_MAX_FRAME_BYTES) return 0;
    for (i = 0; i < n; ++i) if (line[i] < 33 || line[i] > 126) return 0;
    last = strrchr(line, '|');
    if (last == NULL || !r3_hex_u32(last + 1, &crc) ||
        (r3_crc_update(UINT32_MAX, (const uint8_t *)line, (size_t)(last - line)) ^ UINT32_MAX) != crc) return 0;
    p = line;
    for (i = 0; i < 6U; ++i) {
        char *pipe = strchr(p, '|');
        if (pipe == NULL) return 0;
        fields[i] = p;
        *pipe = '\0';
        p = pipe + 1;
    }
    fields[6] = p;
    if (strchr(p, '|') || strcmp(fields[0], "R3") ||
        !r3_hex(fields[1], 16U) || !strcmp(fields[1], "0000000000000000") ||
        !r3_hex(fields[2], 16U) || !r3_u32(fields[3], &seq) || seq == 0U ||
        !r3_token(fields[4], 24U, 0) || fields[5][0] == '\0') return 0;
    if (!strcmp(fields[2], "0000000000000000") && strcmp(fields[4], "HELLO") &&
        strcmp(fields[4], "U_HELLO") && strcmp(fields[4], "STOP")) return 0;
    out->src = fields[1]; out->dst = fields[2]; out->seq = seq;
    out->kind = fields[4]; out->body = fields[5];
    return 1;
}

static inline size_t r3_encode(char *out, size_t capacity, const char *src,
                                const char *dst, uint32_t seq,
                                const char *kind, const char *body)
{
    int n, tail;
    uint32_t crc;
    const char *p;
    if (seq == 0U || !r3_hex(src, 16U) || !r3_hex(dst, 16U) ||
        !strcmp(src, "0000000000000000") || !r3_token(kind, 24U, 0) || body == NULL || !*body) return 0;
    for (p = body; *p; ++p) if (*p < 33 || *p > 126 || *p == '|') return 0;
    n = snprintf(out, capacity, "R3|%s|%s|%lu|%s|%s", src, dst, (unsigned long)seq, kind, body);
    if (n < 0 || (size_t)n + 10U >= capacity || (size_t)n + 10U > R3_MAX_FRAME_BYTES) return 0;
    crc = r3_crc_update(UINT32_MAX, (const uint8_t *)out, (size_t)n) ^ UINT32_MAX;
    tail = snprintf(out + n, capacity - (size_t)n, "|%08lX\n", (unsigned long)crc);
    return tail == 10 ? (size_t)n + 10U : 0;
}

/* One shared wire counter per boot. Failed encodes do not consume it; zero
 * permanently marks exhaustion instead of reusing an old frame identity. */
static inline size_t r3_encode_next(char *out, size_t capacity, const char *src,
    const char *dst, uint32_t *sequence, const char *kind, const char *body)
{
    if (!out || !capacity) return 0;
    out[0]=0;
    if (!sequence || !*sequence) return 0;
    const size_t length=r3_encode(out,capacity,src,dst,*sequence,kind,body);
    if (!length) { out[0]=0; return 0; }
    *sequence=*sequence==UINT32_MAX?0:*sequence+1U;
    return length;
}

/* 1 = complete line, 0 = collecting/discarding. Timeout recovery waits for LF. */
static inline int r3_stream_byte(R3Stream *s, uint8_t byte, uint32_t now)
{
    if (s->length && now - s->last_byte_ms > R3_PARTIAL_TIMEOUT_MS) {
        s->length = 0; s->dropping = 1; ++s->errors;
    }
    s->last_byte_ms = now;
    if (byte == '\n') {
        const int complete = !s->dropping && s->length > 0;
        s->line[s->length] = '\0';
        s->length = 0; s->dropping = 0; s->cr_seen = 0;
        return complete;
    }
    if (s->dropping) return 0;
    if (byte == '\r' && !s->cr_seen) { s->cr_seen = 1; return 0; }
    if (s->cr_seen || byte < 33U || byte > 126U || s->length >= R3_MAX_FRAME_BYTES - 1U) {
        s->length = 0; s->dropping = 1; ++s->errors;
        return 0;
    }
    s->line[s->length++] = (char)byte;
    return 0;
}

static inline int r3_enum(const char *s, const char *values)
{
    const size_t n = strlen(s);
    const char *p = values;
    while (*p) {
        const char *end = strchr(p, '|');
        const size_t length = end ? (size_t)(end - p) : strlen(p);
        if (length == n && !strncmp(p, s, n)) return 1;
        if (!end) break;
        p = end + 1;
    }
    return 0;
}

static inline int r3_state_decode(char *body, R3State *out)
{
    char *f[R3_MAX_FIELDS];
    R3State s;
    uint32_t stopped, start, resume;
    memset(&s, 0, sizeof(s));
    if (r3_fields(body, f, R3_MAX_FIELDS) != 19U ||
        !r3_u32(f[0], &s.seq) || !r3_u32(f[1], &s.epoch) || !r3_u32(f[2], &s.event) ||
        !r3_enum(f[3], "DISARMED|IDLE|MANUAL|AUTO|PAUSED|FAULT|MAINTENANCE") ||
        !r3_enum(f[4], "NONE|ALIGN|TRACK") || !r3_enum(f[5], "EMPTY|RECEIVING|VALIDATING|READY") ||
        !r3_hex(f[6], 32U) || !r3_u32(f[7], &s.revision) || !r3_hex_u32(f[8], &s.crc) ||
        !r3_u32(f[9], &s.index) || !r3_u32(f[10], &s.count) ||
        !r3_enum(f[11], "NONE|RUNNING|PAUSED|COMPLETED|STOPPED|FAULTED") ||
        !r3_enum(f[12], "NONE|OPERATOR|MANUAL_EXPIRED|MANUAL_INVALID|PEER_LOST|GNSS_STALE|GNSS_QUALITY|IMU_STALE|HEADING_QUALITY|HEADING_UNREFERENCED|NO_PROGRESS|PATH_ERROR|GEOFENCE|BLADE_NOT_READY|COMPLETED|RESET|ESTOP|LIFT|BUMPER|TILT|CAN_BUS|MOTOR_FEEDBACK|CONTROL_DEADLINE|INTERNAL") ||
        !r3_hex_u32(f[13], &s.faults) || !r3_u32(f[14], &s.lease) || !r3_u32(f[15], &s.input_seq) ||
        !r3_u32(f[16], &stopped) || !r3_u32(f[17], &start) || !r3_u32(f[18], &resume) ||
        s.seq == 0U || s.epoch == 0U || s.count > 4096U || s.index > s.count ||
        stopped > 1U || start > 1U || resume > 1U) return 0;
    strcpy(s.state, f[3]); strcpy(s.phase, f[4]); strcpy(s.store, f[5]);
    strcpy(s.uuid, f[6]); strcpy(s.outcome, f[11]); strcpy(s.reason, f[12]);
    s.stopped = (uint8_t)stopped; s.ready_start = (uint8_t)start; s.ready_resume = (uint8_t)resume;
    *out = s;
    return 1;
}

static inline int r3_upload_decode(char *body, R3Upload *out)
{
    char *f[6]; R3Upload u;
    memset(&u,0,sizeof(u));
    if (r3_fields(body,f,6U) != 6U || !r3_u32(f[0],&u.id) ||
        !r3_enum(f[1],"EMPTY|RECEIVING|VALIDATING|READY") ||
        !r3_u32(f[2],&u.received) || !r3_u32(f[3],&u.total) ||
        u.total > 131072U || u.received > u.total ||
        !r3_enum(f[4],"EMPTY|PENDING|OK|CANCELLED|BAD_MAGIC|BAD_VERSION|BAD_LENGTH|BAD_CRC|BAD_UUID|BAD_REVISION|BAD_RESERVED|LIMIT_EXCEEDED|PROFILE_MISMATCH|BAD_ORIGIN|BAD_POLYGON|BAD_SEGMENT|BAD_SPEED|BAD_BLADE|PATH_OUTSIDE|VALIDATION_TIMEOUT") ||
        !r3_u32(f[5],&u.detail)) return 0;
    if (r3_enum(f[1],"RECEIVING|VALIDATING") && (!u.id || u.total < 96U)) return 0;
    if (!strcmp(f[1],"VALIDATING") && u.received != u.total) return 0;
    strcpy(u.store,f[1]); strcpy(u.code,f[4]); *out=u; return 1;
}

static inline const char *r3_command_syntax(char *body)
{
    char *f[8];
    uint32_t req, epoch, value;
    size_t n = r3_fields(body, f, 8U), expected;
    if (n < 3U || !r3_u32(f[0], &req) || !req || !r3_u32(f[1], &epoch) || !epoch)
        return "INVALID_PAYLOAD";
    if (r3_enum(f[2], "ARM|DISARM|PAUSE|RESET_FAULT|MANUAL_BEGIN|MAINT_BEGIN|MAINT_END|GET_STATE")) expected = 3U;
    else if (r3_enum(f[2], "HEADING_SET|MANUAL_END|UP_END|UP_ABORT")) expected = 4U;
    else if (!strcmp(f[2], "UP_BEGIN")) expected = 5U;
    else if (r3_enum(f[2], "START|RESUME")) expected = 6U;
    else if (!strcmp(f[2], "UP_DATA")) expected = 7U;
    else return "UNKNOWN_COMMAND";
    if (n != expected) return "INVALID_PAYLOAD";
    if (!strcmp(f[2], "HEADING_SET")) {
        if (!r3_u32(f[3], &value)) return "INVALID_PAYLOAD";
        if (value >= 360000U) return "OUT_OF_RANGE";
    } else if (r3_enum(f[2], "START|RESUME")) {
        if (!r3_hex(f[3], 32U) || !strcmp(f[3], "00000000000000000000000000000000") ||
            !r3_u32(f[4], &value) || !value || !r3_hex(f[5], 8U)) return "INVALID_PAYLOAD";
    } else if (!strcmp(f[2], "UP_BEGIN")) {
        if (!r3_u32(f[3], &value) || !r3_u32(f[4], &value)) return "INVALID_PAYLOAD";
    } else if (!strcmp(f[2], "UP_DATA")) {
        if (!r3_u32(f[3], &value) || !value || !r3_u32(f[4], &value) ||
            !r3_u32(f[5], &value) || value == 0U || value > 128U || !r3_hex(f[6], value * 2U))
            return "INVALID_PAYLOAD";
    } else if (expected == 4U && strcmp(f[2], "HEADING_SET")) {
        if (!r3_u32(f[3], &value) || !value) return "INVALID_PAYLOAD";
    }
    return NULL;
}

static inline int r3_sample_accept(R3Sample *s, uint32_t epoch, uint32_t seq,
                                    uint32_t age, uint32_t now, uint8_t valid)
{
    if (epoch == 0U || seq == 0U || age >= 0x80000000U) return 0;
    if (s->seen && (epoch == s->epoch ? !r3_newer(seq, s->seq) : !r3_newer(epoch, s->epoch))) return 0;
    s->seen = 1; s->epoch = epoch; s->seq = seq; s->age_ms = age;
    s->received_ms = now; s->valid = valid;
    return 1;
}

static inline int r3_sensor_values_decode(char *body, int imu, R3Sample *sample,
                                         R3SensorValues *values, uint32_t now)
{
    char *f[R3_MAX_FIELDS];
    uint32_t epoch, seq, age, valid, u[8];
    int32_t a, b, c;
    if (r3_fields(body, f, R3_MAX_FIELDS) != (imu ? 8U : 14U) ||
        !r3_u32(f[0], &epoch) || !r3_u32(f[1], &seq) || !r3_u32(f[2], &age)) return 0;
    if (imu) {
        if (!r3_i32(f[3], &a) || a < 0 || a >= 360000 ||
            !r3_i32(f[4], &b) || b < -180000 || b > 180000 ||
            !r3_i32(f[5], &c) || c < -180000 || c > 180000 ||
            !r3_u32(f[6], &u[0]) || !r3_u32(f[7], &valid) || valid > 1U) return 0;
    } else {
        if (!r3_u32(f[3], &u[0]) || u[0] >= 604800000U ||
            !r3_i32(f[4], &a) || a < -900000000 || a > 900000000 ||
            !r3_i32(f[5], &b) || b < -1800000000 || b > 1800000000 ||
            !r3_i32(f[6], &c) || !r3_u32(f[7], &u[1]) || u[1] > 5U ||
            !r3_u32(f[8], &valid) || valid > 1U || !r3_u32(f[9], &u[2]) || u[2] > 2U ||
            !r3_u32(f[10], &u[3]) || !r3_u32(f[11], &u[4]) ||
            !r3_u32(f[12], &u[5]) || u[5] >= 360000U || !r3_u32(f[13], &u[6]) || u[6] > 255U) return 0;
    }
    if (!r3_sample_accept(sample, epoch, seq, age, now, (uint8_t)valid)) return 0;
    if (values) {
        R3SensorValues v;
        memset(&v,0,sizeof(v));
        if (imu) { v.yaw=a; v.pitch=b; v.roll=c; v.accuracy=u[0]; }
        else {
            v.itow=u[0]; v.lat=a; v.lon=b; v.height=c; v.fix_type=(uint8_t)u[1];
            v.fix_ok=(uint8_t)valid; v.carrier=(uint8_t)u[2]; v.hacc=u[3]; v.speed=u[4];
            v.course=u[5]; v.satellites=(uint8_t)u[6];
        }
        *values=v;
    }
    return 1;
}

static inline int r3_sensor_decode(char *body, int imu, R3Sample *sample, uint32_t now)
{
    return r3_sensor_values_decode(body,imu,sample,NULL,now);
}

static inline int r3_sample_fresh(const R3Sample *s, uint32_t now, uint32_t limit)
{
    const uint64_t age = (uint64_t)s->age_ms + (uint32_t)(now - s->received_ms) + 50U;
    return s->seen && s->valid && age <= limit;
}

#endif
