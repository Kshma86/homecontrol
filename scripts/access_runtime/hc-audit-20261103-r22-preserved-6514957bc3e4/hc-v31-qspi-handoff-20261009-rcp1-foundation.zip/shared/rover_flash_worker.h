#ifndef ROVER_FLASH_WORKER_H
#define ROVER_FLASH_WORKER_H
#include <stdint.h>

#define R3_FLASH_PROGRAM_TIMEOUT_MS 100U
typedef struct {
    int (*program_poll)(void *context); /* 0 pending, 1 complete, -1 failed. */
    int (*idle)(void *context); /* Independently observed: 0 busy, 1 idle, -1 fault. */
    uint32_t (*clock)(void *context);
} R3FlashAsyncIo;
/* Empty retains the existing synchronous port. Partial async ports never run. */
static inline int r3_flash_async_valid(const R3FlashAsyncIo *io)
{
    return (!io->program_poll && !io->idle && !io->clock) ||
        (io->program_poll && io->idle && io->clock);
}
static inline uint32_t r3_flash_worker_now(const R3FlashAsyncIo *io,void *context,uint32_t fallback)
{ return io->clock?io->clock(context):fallback; }
#endif
