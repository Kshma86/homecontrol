#ifndef ROVER_BOOT_JOURNAL_H
#define ROVER_BOOT_JOURNAL_H
#include "rover_update_image.h"
#include "rover_flash_worker.h"

#define R3_JOURNAL_SECTOR_BYTES 131072U
#define R3_JOURNAL_RECORD_BYTES 512U
#define R3_JOURNAL_PAYLOAD_BYTES 480U
#define R3_JOURNAL_PAGES 256U
#define R3_JOURNAL_J0_BASE 0x08020000U
#define R3_JOURNAL_J1_BASE 0x08100000U
typedef enum { R3_UPDATE_NONE, R3_UPDATE_STM, R3_UPDATE_ESP } R3UpdateTarget;
typedef enum { R3_BOOT_CONFIRMED, R3_BOOT_RECEIVING, R3_BOOT_TRIAL_PENDING, R3_BOOT_TRIAL_ATTEMPTED } R3BootState;
typedef enum { R3_JOB_READY, R3_JOB_COMPLETE, R3_JOB_ABORTED, R3_JOB_ERROR, R3_JOB_EXITING } R3BootResult;
typedef enum {
    R3_BOOT_ERROR_NONE, R3_BOOT_INTERRUPTED, R3_BOOT_FLASH_ERROR, R3_BOOT_BAD_HASH,
    R3_BOOT_BAD_HEADER, R3_BOOT_TRIAL_FAILED, R3_BOOT_ROLLED_BACK, R3_BOOT_METADATA_ERROR, R3_BOOT_CANCELLED
} R3BootError;
typedef struct {
    R3UpdateSlot slot;
    uint32_t bytes,profile_crc;
    uint8_t hash[32];
    char firmware[49];
} R3BootImage;
typedef struct {
    uint64_t sequence;
    uint8_t locked,update_id[16],trial_attempts;
    R3BootState state;
    R3UpdateTarget target;
    R3BootResult result;
    R3BootError error;
    R3BootImage confirmed,candidate;
} R3BootRecord;

#if defined(R3_JOURNAL_CORE_EXTERNAL) && !defined(R3_JOURNAL_CORE_IMPLEMENTATION)
#ifdef __cplusplus
extern "C" {
#endif
int r3_boot_image_valid(const R3BootImage *);
int r3_boot_record_valid(const R3BootRecord *);
int r3_journal_encode(uint8_t *,const R3BootRecord *);
int r3_journal_decode(const uint8_t *,R3BootRecord *);
#ifdef __cplusplus
}
#endif
#else
#ifdef R3_JOURNAL_CORE_IMPLEMENTATION
#define R3_JOURNAL_CORE_API
#else
#define R3_JOURNAL_CORE_API static inline
#endif
R3_JOURNAL_CORE_API int r3_boot_image_valid(const R3BootImage *image)
{
    if (image->slot==R3_SLOT_NONE)
        return !image->bytes && !image->profile_crc && r3_update_zero(image->hash,32) &&
            r3_update_zero((const uint8_t *)image->firmware,sizeof(image->firmware));
    return (image->slot==R3_SLOT_A || image->slot==R3_SLOT_B) && r3_update_length(image->bytes) &&
        memchr(image->firmware,0,sizeof(image->firmware)) && r3_token(image->firmware,48U,1);
}
R3_JOURNAL_CORE_API int r3_boot_record_valid(const R3BootRecord *r)
{
    if (!r->sequence || r->locked>1U || (unsigned)r->state>R3_BOOT_TRIAL_ATTEMPTED ||
        (unsigned)r->target>R3_UPDATE_ESP || (unsigned)r->result>R3_JOB_EXITING ||
        (unsigned)r->error>R3_BOOT_CANCELLED || r->trial_attempts>1U ||
        !r3_boot_image_valid(&r->confirmed) || !r3_boot_image_valid(&r->candidate) ||
        (r->candidate.slot!=R3_SLOT_NONE && r->candidate.slot==r->confirmed.slot)) return 0;
    if (r->locked && r3_update_zero(r->update_id,16)) return 0;
    if (!r->locked && (r->state!=R3_BOOT_CONFIRMED || (r->result!=R3_JOB_READY && r->result!=R3_JOB_EXITING))) return 0;
    if (r->state==R3_BOOT_CONFIRMED) return r->candidate.slot==R3_SLOT_NONE && !r->trial_attempts;
    return r->locked && r->target==R3_UPDATE_STM && r->candidate.slot!=R3_SLOT_NONE &&
        r->candidate.slot==r3_update_inactive(r->confirmed.slot) && r->error==R3_BOOT_ERROR_NONE &&
        r->result==R3_JOB_READY && r->trial_attempts==(r->state==R3_BOOT_TRIAL_ATTEMPTED?1U:0U);
}
R3_JOURNAL_CORE_API int r3_journal_encode(uint8_t bytes[R3_JOURNAL_RECORD_BYTES],const R3BootRecord *r)
{
    if (!r3_boot_record_valid(r)) return 0;
    memset(bytes,0,R3_JOURNAL_RECORD_BYTES); memcpy(bytes,"RUJ1",4);
    r3_update_put(bytes+4,1,2); r3_update_put(bytes+6,512,2); r3_update_put(bytes+8,r->sequence,8);
    r3_update_put(bytes+16,r->locked,4); r3_update_put(bytes+20,r->state,4); memcpy(bytes+24,r->update_id,16);
    r3_update_put(bytes+40,r->target,4); r3_update_put(bytes+44,r->confirmed.slot,4);
    r3_update_put(bytes+48,r->candidate.slot,4); r3_update_put(bytes+52,r->trial_attempts,4);
    r3_update_put(bytes+56,r->confirmed.bytes,4); r3_update_put(bytes+60,r->candidate.bytes,4);
    memcpy(bytes+64,r->confirmed.hash,32); memcpy(bytes+96,r->candidate.hash,32);
    memcpy(bytes+128,r->confirmed.firmware,strlen(r->confirmed.firmware));
    memcpy(bytes+176,r->candidate.firmware,strlen(r->candidate.firmware));
    r3_update_put(bytes+224,r->confirmed.profile_crc,4); r3_update_put(bytes+228,r->candidate.profile_crc,4);
    r3_update_put(bytes+232,r->error,4); r3_update_put(bytes+236,r->result,4);
    memcpy(bytes+480,"RCM1",4);
    r3_update_put(bytes+484,r3_crc_update(UINT32_MAX,bytes,480)^UINT32_MAX,4);
    r3_update_put(bytes+488,r->sequence,8); return 1;
}
R3_JOURNAL_CORE_API int r3_journal_decode(const uint8_t bytes[R3_JOURNAL_RECORD_BYTES],R3BootRecord *out)
{
    R3BootRecord r={0};
    if (memcmp(bytes,"RUJ1",4) || r3_update_u16(bytes+4)!=1 || r3_update_u16(bytes+6)!=512 ||
        memcmp(bytes+480,"RCM1",4) || !r3_update_zero(bytes+240,240) || !r3_update_zero(bytes+496,16) ||
        r3_update_u64(bytes+8)!=r3_update_u64(bytes+488) ||
        r3_update_u32(bytes+484)!=(r3_crc_update(UINT32_MAX,bytes,480)^UINT32_MAX)) return 0;
    const uint32_t lock=r3_update_u32(bytes+16),state=r3_update_u32(bytes+20),target=r3_update_u32(bytes+40),
        confirmed=r3_update_u32(bytes+44),candidate=r3_update_u32(bytes+48),attempts=r3_update_u32(bytes+52),
        error=r3_update_u32(bytes+232),result=r3_update_u32(bytes+236);
    if (lock>1U || state>3U || target>2U || confirmed>2U || candidate>2U || attempts>1U || error>8U || result>4U) return 0;
    r.sequence=r3_update_u64(bytes+8); r.locked=(uint8_t)lock; r.state=(R3BootState)state;
    memcpy(r.update_id,bytes+24,16); r.target=(R3UpdateTarget)target; r.trial_attempts=(uint8_t)attempts;
    r.confirmed.slot=(R3UpdateSlot)confirmed; r.candidate.slot=(R3UpdateSlot)candidate;
    r.confirmed.bytes=r3_update_u32(bytes+56); r.candidate.bytes=r3_update_u32(bytes+60);
    memcpy(r.confirmed.hash,bytes+64,32); memcpy(r.candidate.hash,bytes+96,32);
    r.confirmed.profile_crc=r3_update_u32(bytes+224); r.candidate.profile_crc=r3_update_u32(bytes+228);
    if (confirmed) { if (!r3_update_firmware(r.confirmed.firmware,bytes+128)) return 0; }
    else if (!r3_update_zero(bytes+128,48)) return 0;
    if (candidate) { if (!r3_update_firmware(r.candidate.firmware,bytes+176)) return 0; }
    else if (!r3_update_zero(bytes+176,48)) return 0;
    r.error=(R3BootError)error; r.result=(R3BootResult)result;
    if (!r3_boot_record_valid(&r)) return 0;
    *out=r; return 1;
}
#undef R3_JOURNAL_CORE_API
#endif

typedef int (*R3JournalRead)(void *context,uint32_t address,uint8_t *out,size_t bytes);
typedef struct { uint64_t sequence; uint16_t location; } R3JournalSeen;
typedef struct {
    R3BootRecord record;
    uint8_t best_bytes[512];
    R3JournalSeen seen[2U*R3_JOURNAL_PAGES];
    uint16_t cursor,seen_count,next_page[2];
    uint8_t best_sector,found,conflict,done;
    uint32_t unreadable,invalid;
} R3JournalScan;
static inline uint32_t r3_journal_address(unsigned sector,unsigned page)
{
    return sector<2U && page<R3_JOURNAL_PAGES?
        (sector?R3_JOURNAL_J1_BASE:R3_JOURNAL_J0_BASE)+page*R3_JOURNAL_RECORD_BYTES:0;
}
static inline int r3_journal_erased(const uint8_t *bytes,size_t length)
{
    for (size_t i=0;i<length;++i) if (bytes[i]!=0xffU) return 0;
    return 1;
}
static inline void r3_journal_scan_init(R3JournalScan *scan) { memset(scan,0,sizeof(*scan)); }
/* At most two bounded reads and 512 sequence comparisons per scan slice. */
static inline int r3_journal_scan_step(R3JournalScan *s,R3JournalRead read,void *context)
{
    if (!s || !read) return 0;
    if (s->done) return 1;
    uint8_t bytes[512]; R3BootRecord record;
    const unsigned sector=s->cursor/R3_JOURNAL_PAGES,page=s->cursor%R3_JOURNAL_PAGES;
    const int readable=read(context,r3_journal_address(sector,page),bytes,sizeof(bytes))==1;
    if (!readable || !r3_journal_erased(bytes,sizeof(bytes))) s->next_page[sector]=(uint16_t)(page+1U);
    if (!readable) ++s->unreadable;
    else if (!r3_journal_erased(bytes,sizeof(bytes))) {
        if (!r3_journal_decode(bytes,&record)) ++s->invalid;
        else {
            unsigned match=s->seen_count;
            for (unsigned i=0;i<s->seen_count;++i) if (s->seen[i].sequence==record.sequence) {
                uint8_t prior[512]; const unsigned old=s->seen[i].location;
                if (read(context,r3_journal_address(old/R3_JOURNAL_PAGES,old%R3_JOURNAL_PAGES),prior,sizeof(prior))!=1 ||
                    memcmp(bytes,prior,sizeof(bytes))) s->conflict=1;
                match=i; break;
            }
            if (match==s->seen_count) {
                s->seen[s->seen_count].sequence=record.sequence;
                s->seen[s->seen_count++].location=s->cursor;
            }
            if (!s->found || record.sequence>s->record.sequence) {
                s->record=record; memcpy(s->best_bytes,bytes,sizeof(bytes)); s->best_sector=(uint8_t)sector; s->found=1;
            }
        }
    }
    if (++s->cursor==2U*R3_JOURNAL_PAGES) s->done=1;
    return s->done;
}
static inline int r3_journal_trusted(const R3JournalScan *s) { return s && s->done && s->found && !s->conflict; }

typedef struct {
    R3JournalRead read;
    int (*erase_start)(void *context,unsigned sector);
    int (*erase_poll)(void *context); /* 0 busy, 1 done, -1 failure */
    int (*program_word)(void *context,uint32_t address,const uint8_t word[32]);
    void *context;
    R3FlashAsyncIo async;
} R3JournalIo;
typedef enum { R3_JWRITE_IDLE,R3_JWRITE_ERASE_START,R3_JWRITE_ERASE_WAIT,R3_JWRITE_PAYLOAD,
    R3_JWRITE_PROGRAM_WAIT,R3_JWRITE_CHECK_WORD,R3_JWRITE_CHECK_PAYLOAD,R3_JWRITE_COMMIT,
    R3_JWRITE_COMMIT_WAIT,R3_JWRITE_CHECK_RECORD,R3_JWRITE_DONE,R3_JWRITE_ERROR } R3JournalWritePhase;
typedef struct {
    uint8_t bytes[512];
    uint32_t address,started_ms,erase_ms,program_ms;
    uint16_t offset;
    uint8_t sector,previous_sector,rollover,hardware_pending,program_started;
    R3JournalWritePhase phase;
} R3JournalWriter;
static inline int r3_journal_write_begin(R3JournalWriter *w,const R3JournalScan *scan,const R3BootRecord *next,uint32_t now)
{
    if (!w || !scan || !next || w->hardware_pending ||
        (w->phase!=R3_JWRITE_IDLE && w->phase!=R3_JWRITE_DONE && w->phase!=R3_JWRITE_ERROR) ||
        !r3_journal_trusted(scan) || scan->record.sequence==UINT64_MAX ||
        (w->phase==R3_JWRITE_DONE && scan->record.sequence<r3_update_u64(w->bytes+8))) return 0;
    R3BootRecord record=*next; record.sequence=scan->record.sequence+1U;
    uint8_t bytes[512]; if (!r3_journal_encode(bytes,&record)) return 0;
    memset(w,0,sizeof(*w)); memcpy(w->bytes,bytes,sizeof(bytes)); w->started_ms=now;
    w->sector=w->previous_sector=scan->best_sector;
    unsigned page=scan->next_page[w->sector];
    if (page==R3_JOURNAL_PAGES) { w->rollover=1; w->sector^=1U; page=0; }
    w->address=r3_journal_address(w->sector,page);
    w->phase=w->rollover?R3_JWRITE_ERASE_START:R3_JWRITE_PAYLOAD; return 1;
}
static inline int r3_journal_program_waiting(const R3JournalWriter *w)
{ return w->phase==R3_JWRITE_PROGRAM_WAIT || w->phase==R3_JWRITE_COMMIT_WAIT; }
/* A start is admission only on async ports. Keep the source word until completion. */
static inline R3JournalWritePhase r3_journal_write_step(R3JournalWriter *w,const R3JournalIo *io,uint32_t now)
{
    uint8_t readback[512];
    if (!w) return R3_JWRITE_ERROR;
    if (w->phase==R3_JWRITE_IDLE || w->phase>=R3_JWRITE_DONE) return w->phase;
    if (!io || !io->read || !io->erase_start || !io->erase_poll || !io->program_word ||
        !r3_flash_async_valid(&io->async)) { w->phase=R3_JWRITE_ERROR; return w->phase; }
    now=r3_flash_worker_now(&io->async,io->context,now);
    if ((uint32_t)(now-w->started_ms)>=90000U) { w->phase=R3_JWRITE_ERROR; return w->phase; }
    if (io->async.idle) {
        const int idle=io->async.idle(io->context);
        if (idle!=0 && idle!=1) { w->phase=R3_JWRITE_ERROR; return w->phase; }
        if (!idle && w->phase!=R3_JWRITE_ERASE_WAIT && !r3_journal_program_waiting(w)) return w->phase;
    }
    const R3JournalWritePhase previous_phase=w->phase;
    w->program_started=0;
    switch (w->phase) {
    case R3_JWRITE_ERASE_START:
        if (w->sector==w->previous_sector) { w->phase=R3_JWRITE_ERROR; break; }
        w->hardware_pending=1; w->erase_ms=now;
        if (io->erase_start(io->context,w->sector)!=1) w->phase=R3_JWRITE_ERROR;
        else w->phase=R3_JWRITE_ERASE_WAIT;
        break;
    case R3_JWRITE_ERASE_WAIT: {
        if ((uint32_t)(now-w->erase_ms)>=10000U) { w->phase=R3_JWRITE_ERROR; break; }
        const int status=io->erase_poll(io->context);
        if (status!=0 && status!=1) w->phase=R3_JWRITE_ERROR;
        else if (status==1) {
            if (io->async.idle && io->async.idle(io->context)!=1) w->phase=R3_JWRITE_ERROR;
            else { w->hardware_pending=0; w->phase=R3_JWRITE_PAYLOAD; }
        }
        break;
    }
    case R3_JWRITE_PAYLOAD:
    case R3_JWRITE_COMMIT: {
        const int commit=w->phase==R3_JWRITE_COMMIT;
        const uint32_t offset=commit?480U:w->offset;
        if (offset>480U || offset%32U || (!commit && offset==480U) ||
            io->read(io->context,w->address+offset,readback,32)!=1 || !r3_journal_erased(readback,32)) {
            w->phase=R3_JWRITE_ERROR; break;
        }
        w->program_ms=r3_flash_worker_now(&io->async,io->context,now);
        if ((uint32_t)(w->program_ms-w->started_ms)>=90000U) { w->phase=R3_JWRITE_ERROR; break; }
        w->hardware_pending=(uint8_t)(io->async.program_poll!=NULL);
        w->program_started=1;
        if (io->program_word(io->context,w->address+offset,w->bytes+offset)!=1) w->phase=R3_JWRITE_ERROR;
        else w->phase=commit?(io->async.program_poll?R3_JWRITE_COMMIT_WAIT:R3_JWRITE_CHECK_RECORD):
            (io->async.program_poll?R3_JWRITE_PROGRAM_WAIT:R3_JWRITE_CHECK_WORD);
        break;
    }
    case R3_JWRITE_PROGRAM_WAIT:
    case R3_JWRITE_COMMIT_WAIT: {
        if (!io->async.program_poll || (uint32_t)(now-w->program_ms)>=R3_FLASH_PROGRAM_TIMEOUT_MS) {
            w->phase=R3_JWRITE_ERROR; break;
        }
        const int result=io->async.program_poll(io->context);
        if (result!=0 && result!=1) w->phase=R3_JWRITE_ERROR;
        else if (result==1) {
            if (io->async.idle(io->context)!=1) w->phase=R3_JWRITE_ERROR;
            else {
                w->hardware_pending=0;
                w->phase=w->phase==R3_JWRITE_COMMIT_WAIT?R3_JWRITE_CHECK_RECORD:R3_JWRITE_CHECK_WORD;
            }
        }
        break;
    }
    case R3_JWRITE_CHECK_WORD:
        if (w->offset>=480U || w->offset%32U ||
            io->read(io->context,w->address+w->offset,readback,32)!=1 || memcmp(readback,w->bytes+w->offset,32))
            w->phase=R3_JWRITE_ERROR;
        else { w->offset+=32U; w->phase=w->offset==480U?R3_JWRITE_CHECK_PAYLOAD:R3_JWRITE_PAYLOAD; }
        break;
    case R3_JWRITE_CHECK_PAYLOAD:
        if (io->read(io->context,w->address,readback,480)!=1 || memcmp(readback,w->bytes,480)) w->phase=R3_JWRITE_ERROR;
        else w->phase=R3_JWRITE_COMMIT;
        break;
    case R3_JWRITE_CHECK_RECORD: {
        R3BootRecord record;
        if (io->read(io->context,w->address,readback,512)!=1 || memcmp(readback,w->bytes,512) ||
            !r3_journal_decode(readback,&record)) w->phase=R3_JWRITE_ERROR;
        else w->phase=R3_JWRITE_DONE;
        break;
    }
    default: w->phase=R3_JWRITE_ERROR; break;
    }
    const uint32_t completed=r3_flash_worker_now(&io->async,io->context,now);
    if ((uint32_t)(completed-w->started_ms)>=90000U ||
        ((previous_phase==R3_JWRITE_ERASE_START || previous_phase==R3_JWRITE_ERASE_WAIT) &&
         (uint32_t)(completed-w->erase_ms)>=10000U) ||
        (((w->program_started && (previous_phase==R3_JWRITE_PAYLOAD || previous_phase==R3_JWRITE_COMMIT)) ||
          previous_phase==R3_JWRITE_PROGRAM_WAIT || previous_phase==R3_JWRITE_COMMIT_WAIT) &&
         io->async.program_poll && (uint32_t)(completed-w->program_ms)>=R3_FLASH_PROGRAM_TIMEOUT_MS))
        w->phase=R3_JWRITE_ERROR;
    return w->phase;
}
#endif
