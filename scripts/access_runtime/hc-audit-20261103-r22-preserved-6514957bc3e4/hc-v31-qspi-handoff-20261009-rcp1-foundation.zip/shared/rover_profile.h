#ifndef ROVER_PROFILE_H
#define ROVER_PROFILE_H
#include <stdint.h>

typedef struct { uint8_t present, port, pin, active_level; } R3SafetyPin;
typedef struct {
    uint32_t crc;
    uint8_t installed, commissioned, blade_enabled;
    char robot_id[33];
    uint16_t wheel_track_mm, wheel_circumference_mm[2], wheel_motor_pole_pairs[2];
    uint32_t wheel_gear_ratio_milli[2];
    int8_t wheel_direction[2], blade_direction;
    uint16_t blade_pole_pairs, body_radius_mm;
    int32_t antenna_body_mm[3], imu_mount_q_ppm[4];
    uint32_t wheel_erpm_limit[2], blade_erpm_limit, blade_rpm_limit, wheel_brake_ma[2];
    uint32_t stop_deceleration_mm_s2, stop_test_max_ms;
    uint16_t max_slope_mdeg, max_linear_mm_s, max_yaw_mdeg_s, accel_mm_s2;
    uint32_t yaw_accel_mdeg_s2;
    uint16_t gnss_hacc_limit_mm, heading_accuracy_limit_mdeg, tilt_limit_mdeg;
    uint32_t safety_installed_mask;
    R3SafetyPin safety_inputs[3];
    char vesc_firmware[3][41];
} R3Profile;
#endif
