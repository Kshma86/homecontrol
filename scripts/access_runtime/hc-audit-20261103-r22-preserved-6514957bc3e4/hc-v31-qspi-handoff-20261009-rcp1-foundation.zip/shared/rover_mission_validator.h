#ifndef ROVER_MISSION_VALIDATOR_H
#define ROVER_MISSION_VALIDATOR_H
#include "rover_protocol.h"
#include "rover_geometry.h"

typedef struct {
    uint32_t profile_crc, body_radius, hacc_limit, stop_deceleration;
    uint16_t max_speed, blade_limit;
    uint8_t installed, blade_enabled;
} R3MissionLimits;
typedef enum { R3_VALIDATE_HEADER, R3_VALIDATE_CRC, R3_VALIDATE_RINGS,
    R3_VALIDATE_SELF, R3_VALIDATE_CROSS, R3_VALIDATE_CONTAINMENT,
    R3_VALIDATE_RECORDS, R3_VALIDATE_PATH, R3_VALIDATE_DONE } R3ValidationPhase;
typedef struct {
    const uint8_t *data;
    uint32_t total, crc, crc_offset, offset, record_offset, records, record, detail, started;
    uint32_t vertices, clearance;
    R3Ring rings[17];
    R3Point previous;
    int64_t area;
    unsigned ring_count, ring, other, i, j, vmax;
    uint8_t blade_required;
    R3ValidationPhase phase;
    const char *code;
    R3MissionLimits limits;
} R3MissionValidator;

static inline int r3_validation_fail(R3MissionValidator *v, const char *code, uint32_t detail)
{
    v->code = code; v->detail = detail; v->phase = R3_VALIDATE_DONE; return -1;
}
static inline void r3_validation_begin(R3MissionValidator *v, const uint8_t *data,
    uint32_t total, R3MissionLimits limits, uint32_t now)
{
    memset(v, 0, sizeof(*v)); v->data = data; v->total = total; v->limits = limits;
    v->started = now; v->crc = UINT32_MAX; v->code = "PENDING";
}
static inline void r3_validation_cancel(R3MissionValidator *v)
{
    r3_validation_fail(v, "CANCELLED", 0);
}

/* One unit checks a bounded record/edge pair or at most 128 CRC bytes. */
static inline int r3_validation_step(R3MissionValidator *v, uint32_t now, unsigned units)
{
    const uint8_t *p = v->data;
    if (v->phase == R3_VALIDATE_DONE) return !strcmp(v->code, "OK") ? 1 : -1;
    if ((uint32_t)(now - v->started) >= 30000U) return r3_validation_fail(v, "VALIDATION_TIMEOUT", 0);
    while (units-- && v->phase != R3_VALIDATE_DONE) {
        if (v->phase == R3_VALIDATE_HEADER) {
            unsigned k; uint8_t nonzero = 0;
            if (v->total < 96U || v->total > 131072U) return r3_validation_fail(v, "BAD_LENGTH", 0);
            if (memcmp(p, "RVM3", 4)) return r3_validation_fail(v, "BAD_MAGIC", 0);
            if (r3_le16(p + 4) != 3 || r3_le16(p + 6)) return r3_validation_fail(v, "BAD_VERSION", 0);
            if (r3_le32(p + 8) != v->total) return r3_validation_fail(v, "BAD_LENGTH", 0);
            for (k = 16; k < 32; ++k) nonzero |= p[k];
            if (!nonzero) return r3_validation_fail(v, "BAD_UUID", 0);
            if (!r3_le32(p + 32)) return r3_validation_fail(v, "BAD_REVISION", 0);
            for (k = 68; k < 96; ++k) if (p[k]) return r3_validation_fail(v, "BAD_RESERVED", k);
            if (!v->limits.installed || !v->limits.stop_deceleration ||
                r3_le32(p + 64) != v->limits.profile_crc) return r3_validation_fail(v, "PROFILE_MISMATCH", 0);
            if ((int32_t)r3_le32(p + 36) < -900000000 || (int32_t)r3_le32(p + 36) > 900000000 ||
                (int32_t)r3_le32(p + 40) < -1800000000 || (int32_t)r3_le32(p + 40) > 1800000000 ||
                !r3_coord_valid(r3_point(p + 48))) return r3_validation_fail(v, "BAD_ORIGIN", 0);
            v->rings[0].count = r3_le16(p + 56); v->rings[0].offset = 96;
            v->ring_count = 1U + r3_le16(p + 58); v->records = r3_le32(p + 60);
            if (v->rings[0].count < 3 || v->rings[0].count > 256 || v->ring_count > 17 ||
                !v->records || v->records > 4096) return r3_validation_fail(v, "LIMIT_EXCEEDED", 0);
            v->vertices = v->rings[0].count; v->phase = R3_VALIDATE_CRC;
        } else if (v->phase == R3_VALIDATE_CRC) {
            uint32_t n = v->total - v->crc_offset;
            if (n > 128) n = 128;
            v->crc = r3_mission_crc_update(v->crc, p + v->crc_offset, n, v->crc_offset);
            v->crc_offset += n;
            if (v->crc_offset == v->total) {
                if ((v->crc ^ UINT32_MAX) != r3_le32(p + 12)) return r3_validation_fail(v, "BAD_CRC", 0);
                v->phase = R3_VALIDATE_RINGS;
            }
        } else if (v->phase == R3_VALIDATE_RINGS) {
            R3Ring ring = v->rings[v->ring];
            R3Point a, b, c;
            if (ring.offset > v->total || ring.count * 8U > v->total - ring.offset)
                return r3_validation_fail(v, "BAD_LENGTH", ring.offset);
            a = r3_vertex(p, ring, v->i); b = r3_vertex(p, ring, v->i + 1U); c = r3_vertex(p, ring, v->i + 2U);
            if (!r3_coord_valid(a)) return r3_validation_fail(v,"BAD_POLYGON",v->i);
            if (!r3_coord_valid(b)) return r3_validation_fail(v,"BAD_POLYGON",(v->i+1U)%ring.count);
            if (!r3_coord_valid(c)) return r3_validation_fail(v,"BAD_POLYGON",(v->i+2U)%ring.count);
            if ((a.x == b.x && a.y == b.y) ||
                (!r3_orient(a,b,c) && ((int64_t)b.x-a.x)*((int64_t)c.x-b.x) +
                  ((int64_t)b.y-a.y)*((int64_t)c.y-b.y) < 0)) return r3_validation_fail(v, "BAD_POLYGON", v->i);
            v->area += (int64_t)a.x*b.y - (int64_t)b.x*a.y;
            if (++v->i == ring.count) {
                if (v->ring == 0 ? v->area <= 0 : v->area >= 0) return r3_validation_fail(v, "BAD_POLYGON", v->ring);
                v->offset = ring.offset + ring.count * 8U; v->i = 0; v->area = 0;
                if (++v->ring == v->ring_count) {
                    v->record_offset = v->offset;
                    if (v->records * 16U != v->total - v->offset) return r3_validation_fail(v, "BAD_LENGTH", v->offset);
                    v->ring = 0; v->j = 1; v->phase = R3_VALIDATE_SELF;
                } else {
                    unsigned count;
                    if (v->offset > v->total || v->total - v->offset < 4) return r3_validation_fail(v, "BAD_LENGTH", v->offset);
                    count = r3_le16(p + v->offset);
                    if (r3_le16(p + v->offset + 2)) return r3_validation_fail(v, "BAD_RESERVED", v->ring);
                    if (count < 3 || count > 128 || v->vertices + count > 2048)
                        return r3_validation_fail(v, "LIMIT_EXCEEDED", v->ring);
                    v->vertices += count; v->rings[v->ring].count = (uint16_t)count;
                    v->rings[v->ring].offset = v->offset + 4U;
                }
            }
        } else if (v->phase == R3_VALIDATE_SELF) {
            R3Ring ring = v->rings[v->ring];
            if (v->j != v->i + 1U && !(v->i == 0 && v->j == ring.count - 1U) &&
                r3_intersect(r3_vertex(p,ring,v->i), r3_vertex(p,ring,v->i+1U),
                             r3_vertex(p,ring,v->j), r3_vertex(p,ring,v->j+1U)))
                return r3_validation_fail(v, "BAD_POLYGON", v->j);
            if (++v->j == ring.count) { ++v->i; v->j = v->i + 1U; }
            if (v->i == ring.count - 1U) {
                v->i = 0; v->j = 1;
                if (++v->ring == v->ring_count) {
                    v->ring = 0; v->other = v->ring_count > 1 ? 1 : 0; v->i = v->j = 0;
                    v->phase = v->ring_count > 1 ? R3_VALIDATE_CROSS : R3_VALIDATE_CONTAINMENT;
                }
            }
        } else if (v->phase == R3_VALIDATE_CROSS) {
            R3Ring a = v->rings[v->ring], b = v->rings[v->other];
            if (r3_intersect(r3_vertex(p,a,v->i), r3_vertex(p,a,v->i+1U),
                             r3_vertex(p,b,v->j), r3_vertex(p,b,v->j+1U)))
                return r3_validation_fail(v, "BAD_POLYGON", v->other);
            if (++v->j == b.count) { v->j = 0; ++v->i; }
            if (v->i == a.count) {
                v->i = 0;
                if (++v->other == v->ring_count) { ++v->ring; v->other = v->ring + 1U; }
                if (v->ring == v->ring_count - 1U) { v->ring = 0; v->other = 0; v->phase = R3_VALIDATE_CONTAINMENT; }
            }
        } else if (v->phase == R3_VALIDATE_CONTAINMENT) {
            /* One winding scan is bounded by 256 vertices; no file-length loop. */
            R3Point point = v->ring ? r3_vertex(p,v->rings[v->ring],0) : r3_point(p+48);
            if (v->other == 0) {
                if (!r3_inside(p,v->rings[0],point)) return r3_validation_fail(v, v->ring ? "BAD_POLYGON" : "PATH_OUTSIDE", v->ring);
            } else if (v->other != v->ring && r3_inside(p,v->rings[v->other],point))
                return r3_validation_fail(v, v->ring ? "BAD_POLYGON" : "PATH_OUTSIDE", v->ring);
            if (++v->other == v->ring_count) {
                v->other = 0;
                if (++v->ring == v->ring_count) {
                    v->ring = 0; v->previous = r3_point(p+48); v->phase = R3_VALIDATE_RECORDS;
                }
            }
        } else if (v->phase == R3_VALIDATE_RECORDS) {
            const uint8_t *record = p + v->record_offset + v->record * 16U;
            R3Point end = r3_point(record);
            int64_t dx = (int64_t)end.x-v->previous.x, dy = (int64_t)end.y-v->previous.y;
            unsigned speed = r3_le16(record+8), blade = r3_le16(record+10);
            if (!r3_coord_valid(end) || dx*dx+dy*dy < 90000) return r3_validation_fail(v, "BAD_SEGMENT", v->record);
            if (speed < 50 || speed > v->limits.max_speed) return r3_validation_fail(v, "BAD_SPEED", v->record);
            if (blade && (!v->limits.blade_enabled || blade > v->limits.blade_limit)) return r3_validation_fail(v, "BAD_BLADE", v->record);
            if (r3_le32(record+12)) return r3_validation_fail(v, "BAD_RESERVED", v->record);
            if (speed > v->vmax) v->vmax = speed;
            v->blade_required |= blade != 0; v->previous = end;
            if (++v->record == v->records) {
                uint64_t braking = ((uint64_t)v->vmax*v->vmax + 2ULL*v->limits.stop_deceleration-1U) /
                                    (2ULL*v->limits.stop_deceleration);
                v->clearance = v->limits.body_radius + 2U*v->limits.hacc_limit + 50U + (v->vmax*8U+9U)/10U + (uint32_t)braking;
                v->record = v->ring = v->i = 0; v->previous = r3_point(p+48); v->phase = R3_VALIDATE_PATH;
            }
        } else if (v->phase == R3_VALIDATE_PATH) {
            R3Point end = r3_point(p + v->record_offset + v->record*16U);
            R3Ring ring = v->rings[v->ring];
            double limit = (double)v->clearance*v->clearance;
            if (r3_segment_distance2(v->previous,end,r3_vertex(p,ring,v->i),r3_vertex(p,ring,v->i+1U)) < limit)
                return r3_validation_fail(v, "PATH_OUTSIDE", v->record);
            if (++v->i == ring.count) { v->i = 0; ++v->ring; }
            if (v->ring == v->ring_count) {
                v->ring = 0; v->previous = end;
                if (++v->record == v->records) { v->code = "OK"; v->phase = R3_VALIDATE_DONE; }
            }
        }
    }
    return v->phase == R3_VALIDATE_DONE ? 1 : 0;
}
#endif
