#ifndef ROVER_UPDATE_PROTOCOL_H
#define ROVER_UPDATE_PROTOCOL_H
#include "rover_boot_journal.h"

typedef enum { R3_SERVICE_OPEN,R3_SERVICE_STATUS,R3_SERVICE_BEGIN,R3_SERVICE_DATA,
    R3_SERVICE_END,R3_SERVICE_ABORT,R3_SERVICE_EXIT } R3ServiceVerb;
typedef struct {
    uint32_t request,bytes,profile_crc,offset,length;
    uint16_t major,minor;
    R3ServiceVerb verb;
    R3UpdateTarget target;
    R3UpdateSlot slot;
    char update_id[33],hash[65],firmware[49];
    uint8_t data[128];
} R3ServiceRequest;
typedef struct { char role[7],firmware[49]; } R3ServiceHello;
typedef struct {
    uint32_t request,next_offset,detail;
    uint8_t ok;
    char update_id[33],code[25],phase[11];
} R3ServiceAck;
typedef struct {
    char update_id[33],phase[11],code[25],hash[65],firmware[49],stop_evidence[14];
    R3UpdateSlot confirmed,candidate;
    uint32_t next_offset,total_bytes,stop_age_ms;
    uint8_t locked,can_active,outputs_inhibited,has_image,has_stop_age;
} R3ServiceStatus;

static inline int r3_service_code(const char *code)
{
    return r3_enum(code,"NONE|INVALID_PAYLOAD|BAD_STATE|BUSY|UPDATE_MODE|ID_CONFLICT|STALE_REQUEST|STALE_SESSION|"
        "BAD_OFFSET|DATA_CONFLICT|BAD_LENGTH|BAD_HASH|BAD_HEADER|WRONG_TARGET|WRONG_SLOT|PROFILE_MISMATCH|"
        "ABI_MISMATCH|LAYOUT_MISMATCH|IMAGE_TOO_LARGE|NO_BUFFER|NOT_STOPPED|BOOTLOADER_UNAVAILABLE|"
        "TRANSFER_TIMEOUT|ERASE_TIMEOUT|FLASH_ERROR|VERIFY_TIMEOUT|TRIAL_FAILED|ROLLED_BACK|INTERRUPTED|"
        "METADATA_ERROR|EXIT_FAILED|CANCELLED|INTERNAL");
}
static inline int r3_service_phase(const char *phase)
{
    return r3_enum(phase,"IDLE|QUIESCING|READY|RECEIVING|ERASING|WRITING|VERIFYING|TRIAL|COMPLETE|ABORTED|ERROR|EXITING");
}
static inline int r3_service_slot(const char *token,R3UpdateSlot *out,int none)
{
    if (!strcmp(token,"A")) *out=R3_SLOT_A;
    else if (!strcmp(token,"B")) *out=R3_SLOT_B;
    else if (none && !strcmp(token,"NONE")) *out=R3_SLOT_NONE;
    else return 0;
    return 1;
}
static inline int r3_service_zero_id(const char *id)
{
    return !strcmp(id,"00000000000000000000000000000000");
}
static inline int r3_service_hello(char *body,R3ServiceHello *out)
{
    char *f[4]; R3ServiceHello hello={0};
    if (r3_fields(body,f,4)!=4 || strcmp(f[0],"1") || strcmp(f[1],"H743_2M_AB1") ||
        !r3_enum(f[2],"ESP|APP|LOADER") || !r3_token(f[3],48,1)) return 0;
    strcpy(hello.role,f[2]); strcpy(hello.firmware,f[3]); *out=hello; return 1;
}
static inline int r3_service_request(char *body,R3ServiceRequest *out)
{
    char *f[8]; R3ServiceRequest request={0};
    const size_t count=r3_fields(body,f,8);
    if (count<3 || !r3_u32(f[0],&request.request) || !request.request || !r3_hex(f[1],32)) return 0;
    strcpy(request.update_id,f[1]);
    if (!strcmp(f[2],"STATUS")) { if (count!=3) return 0; request.verb=R3_SERVICE_STATUS; }
    else {
        if (r3_service_zero_id(f[1])) return 0;
        if (!strcmp(f[2],"OPEN")) {
            if (count!=4 || !r3_enum(f[3],"STM|ESP")) return 0;
            request.verb=R3_SERVICE_OPEN; request.target=!strcmp(f[3],"STM")?R3_UPDATE_STM:R3_UPDATE_ESP;
        } else if (!strcmp(f[2],"BEGIN")) {
            request.verb=R3_SERVICE_BEGIN;
            if (count!=8 || !r3_service_slot(f[3],&request.slot,0) || !r3_u32(f[4],&request.bytes) ||
                !r3_update_length(request.bytes) || !r3_hex(f[5],64) || !r3_token(f[6],48,1) ||
                !r3_hex_u32(f[7],&request.profile_crc)) return 0;
            strcpy(request.hash,f[5]); strcpy(request.firmware,f[6]);
        } else if (!strcmp(f[2],"DATA")) {
            request.verb=R3_SERVICE_DATA;
            if (count!=6 || !r3_u32(f[3],&request.offset) || request.offset%128U ||
                request.offset>=R3_UPDATE_IMAGE_MAX || !r3_u32(f[4],&request.length) ||
                !request.length || request.length>128U || request.length%32U ||
                request.length>R3_UPDATE_IMAGE_MAX-request.offset || !r3_hex(f[5],2U*request.length)) return 0;
            for (unsigned i=0;i<request.length;++i) {
                const char a=f[5][2U*i],b=f[5][2U*i+1U];
                request.data[i]=(uint8_t)(((a<='9'?a-'0':a-'A'+10)<<4) | (b<='9'?b-'0':b-'A'+10));
            }
        } else if (!strcmp(f[2],"END") || !strcmp(f[2],"ABORT")) {
            if (count!=3) return 0;
            request.verb=!strcmp(f[2],"END")?R3_SERVICE_END:R3_SERVICE_ABORT;
        } else if (!strcmp(f[2],"EXIT")) {
            uint32_t major,minor; request.verb=R3_SERVICE_EXIT;
            if (count!=6 || !r3_u32(f[3],&major) || !major || major>UINT16_MAX ||
                !r3_u32(f[4],&minor) || minor>UINT16_MAX || !r3_hex_u32(f[5],&request.profile_crc)) return 0;
            request.major=(uint16_t)major; request.minor=(uint16_t)minor;
        } else return 0;
    }
    *out=request; return 1;
}
static inline int r3_service_request_body(char *out,size_t capacity,const R3ServiceRequest *r)
{
    char encoded[400],hex[257]; int length=0;
    if (!r || !r->request || !memchr(r->update_id,0,sizeof(r->update_id)) || !r3_hex(r->update_id,32)) return 0;
    switch (r->verb) {
    case R3_SERVICE_STATUS: case R3_SERVICE_END: case R3_SERVICE_ABORT:
        length=snprintf(encoded,sizeof(encoded),"%lu,%s,%s",(unsigned long)r->request,r->update_id,
            r->verb==R3_SERVICE_STATUS?"STATUS":r->verb==R3_SERVICE_END?"END":"ABORT"); break;
    case R3_SERVICE_OPEN:
        if (r->target!=R3_UPDATE_STM && r->target!=R3_UPDATE_ESP) return 0;
        length=snprintf(encoded,sizeof(encoded),"%lu,%s,OPEN,%s",(unsigned long)r->request,r->update_id,
            r->target==R3_UPDATE_STM?"STM":"ESP"); break;
    case R3_SERVICE_BEGIN:
        if ((r->slot!=R3_SLOT_A && r->slot!=R3_SLOT_B) || !memchr(r->hash,0,sizeof(r->hash)) ||
            !memchr(r->firmware,0,sizeof(r->firmware)) || !r3_hex(r->hash,64) || !r3_token(r->firmware,48,1)) return 0;
        length=snprintf(encoded,sizeof(encoded),"%lu,%s,BEGIN,%s,%lu,%s,%s,%08lX",(unsigned long)r->request,r->update_id,
            r->slot==R3_SLOT_A?"A":"B",(unsigned long)r->bytes,r->hash,r->firmware,(unsigned long)r->profile_crc); break;
    case R3_SERVICE_DATA:
        if (!r->length || r->length>128U) return 0;
        for (unsigned i=0;i<r->length;++i) snprintf(hex+2U*i,3,"%02X",(unsigned)r->data[i]);
        length=snprintf(encoded,sizeof(encoded),"%lu,%s,DATA,%lu,%lu,%s",(unsigned long)r->request,r->update_id,
            (unsigned long)r->offset,(unsigned long)r->length,hex); break;
    case R3_SERVICE_EXIT:
        length=snprintf(encoded,sizeof(encoded),"%lu,%s,EXIT,%u,%u,%08lX",(unsigned long)r->request,r->update_id,
            (unsigned)r->major,(unsigned)r->minor,(unsigned long)r->profile_crc); break;
    default: return 0;
    }
    if (length<=0 || (size_t)length>=sizeof(encoded) || (size_t)length>=capacity) return 0;
    char copy[400]; R3ServiceRequest checked={0}; strcpy(copy,encoded);
    if (!r3_service_request(copy,&checked)) return 0;
    memcpy(out,encoded,(size_t)length+1U); return 1;
}
static inline int r3_service_ack(char *body,R3ServiceAck *out)
{
    char *f[7]; R3ServiceAck ack={0};
    if (r3_fields(body,f,7)!=7 || !r3_u32(f[0],&ack.request) || !ack.request || !r3_hex(f[1],32) ||
        !r3_enum(f[2],"OK|ERR") || !r3_service_code(f[3]) || !r3_service_phase(f[4]) ||
        !r3_u32(f[5],&ack.next_offset) || ack.next_offset>R3_UPDATE_IMAGE_MAX ||
        !r3_u32(f[6],&ack.detail) || (!strcmp(f[2],"OK")!=!strcmp(f[3],"NONE"))) return 0;
    ack.ok=(uint8_t)!strcmp(f[2],"OK"); strcpy(ack.update_id,f[1]); strcpy(ack.code,f[3]); strcpy(ack.phase,f[4]);
    *out=ack; return 1;
}
static inline int r3_service_status(char *body,R3ServiceStatus *out)
{
    char *f[14]; R3ServiceStatus status={0}; uint32_t lock,can,inhibit;
    if (r3_fields(body,f,14)!=14 || !r3_hex(f[0],32) || !r3_service_phase(f[1]) || !r3_service_code(f[2]) ||
        !r3_service_slot(f[3],&status.confirmed,1) || !r3_service_slot(f[4],&status.candidate,1) ||
        (status.candidate!=R3_SLOT_NONE && status.candidate!=r3_update_inactive(status.confirmed)) ||
        !r3_u32(f[5],&status.next_offset) || !r3_u32(f[6],&status.total_bytes) ||
        status.next_offset>status.total_bytes || status.total_bytes>R3_UPDATE_IMAGE_MAX ||
        (status.total_bytes && !r3_update_length(status.total_bytes)) || !r3_u32(f[7],&lock) || lock>1U ||
        !r3_u32(f[10],&can) || can>1U || !r3_u32(f[11],&inhibit) || inhibit>1U ||
        !r3_enum(f[12],"MEASURED|POWER_INHIBIT|UNKNOWN")) return 0;
    const int hash_known=strcmp(f[8],"~")!=0,fw_known=strcmp(f[9],"~")!=0;
    if (hash_known!=fw_known || (hash_known && (!r3_hex(f[8],64) || !r3_token(f[9],48,1)))) return 0;
    if (!strcmp(f[13],"~")) { if (strcmp(f[12],"UNKNOWN")) return 0; }
    else { if (!strcmp(f[12],"UNKNOWN") || !r3_u32(f[13],&status.stop_age_ms)) return 0; status.has_stop_age=1; }
    if (r3_enum(f[1],"READY|RECEIVING|ERASING|WRITING|VERIFYING|TRIAL|COMPLETE|ABORTED") && (!lock || can || !inhibit)) return 0;
    status.locked=(uint8_t)lock; status.can_active=(uint8_t)can; status.outputs_inhibited=(uint8_t)inhibit;
    status.has_image=(uint8_t)hash_known;
    strcpy(status.update_id,f[0]); strcpy(status.phase,f[1]); strcpy(status.code,f[2]); strcpy(status.stop_evidence,f[12]);
    if (hash_known) { strcpy(status.hash,f[8]); strcpy(status.firmware,f[9]); }
    *out=status; return 1;
}
#endif
