#!/usr/bin/env python3
"""Validate measured reset-time STOP-only CAN qualification; never operate hardware."""
import argparse
import json
from pathlib import Path
import sys
import rover_acceptance as acceptance
import rover_factory as factory
import rover_profile as profile


def validate(p, installation, qualification):
    factory.validate(p, installation)
    template = json.loads((profile.ROOT / "config/rover_loader_can_qualification.template.json").read_text())
    factory.shape(qualification, template, "loader_can_qualification")
    q = qualification
    profile.integer(q["version"], 1, 1, "version")
    if q["profile_crc"] != f"{profile.checksum(p):08X}" or q["mcu_uid"] != installation["mcu"]["uid"]:
        raise ValueError("CAN qualification must bind the exact profile and MCU UID")
    if installation["mcu"]["revision"] != 0x2003:
        raise ValueError("Reviewed loader MCU revision 0x2003 required")
    clock = q["clock"]
    if clock["source"] != "HSE":
        raise ValueError("The reset CAN port supports only the independently measured HSE source")
    profile.integer(clock["kernel_hz"], 25000000, 25000000, "Measured loader HSE")
    n = q["nominal"]
    for name, maximum in (("prescaler", 512), ("sjw", 128), ("seg1", 256), ("seg2", 128)):
        profile.integer(n[name], 1, maximum, "nominal." + name)
    if n["sjw"] > n["seg2"] or n["prescaler"] * (1 + n["seg1"] + n["seg2"]) * 500000 != clock["kernel_hz"]:
        raise ValueError("Measured nominal timing must produce exactly 500000 bit/s with SJW <= seg2")
    for group in ("clock", "wiring", "stop", "timing"):
        factory.flag(q[group]["verified"], group + ".verified", True)
        factory.text(q[group]["evidence_id"], group + ".evidence_id")
    return q


def header(p, installation, qualification):
    q = validate(p, installation, qualification)
    n = q["nominal"]
    values = [json.dumps(q["mcu_uid"])] + [f"{v}U" for v in
        (profile.checksum(p), q["clock"]["kernel_hz"], n["prescaler"], n["sjw"], n["seg1"], n["seg2"])] + ["1"] * 5
    return ("#ifndef ROVER_INSTALLED_LOADER_CAN_H\n#define ROVER_INSTALLED_LOADER_CAN_H\n"
            '#include "rover_loader_can_commission.h"\n'
            "static const RoverLoaderCanCommission rover_installed_loader_can = {" + ",".join(values) + "};\n#endif\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("profile", "installation", "qualification"):
        parser.add_argument(name, type=Path)
    parser.add_argument("--header", type=Path)
    args = parser.parse_args()
    try:
        values = [acceptance.load(path) for path in (args.profile, args.installation, args.qualification)]
        output = header(*values)
        if args.header:
            with args.header.open("x", encoding="ascii") as stream:
                stream.write(output)
        print("CAN qualification validated; no flashing, motion or device operation authorized.")
    except (OSError, ValueError, TypeError) as error:
        print(str(error), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
