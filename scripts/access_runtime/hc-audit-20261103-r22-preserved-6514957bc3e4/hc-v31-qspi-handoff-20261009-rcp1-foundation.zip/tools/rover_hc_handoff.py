#!/usr/bin/env python3
"""Package an explicit non-secret HC source allowlist; never contact a rover."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
FILES = (
    "HC_AI_ATADAS_20261009.md",
    "docs/HC_V31_INTEGRATION_HANDOFF.md", "docs/hc_server_files.md",
    "docs/HC_PARAMETER_MANAGEMENT.md",
    "docs/HC_PARAMETERS_RCP1.md",
    "docs/QSPI_UPDATE_RUNTIME.md", "docs/QSPI_PROVISIONING.md",
    "docs/NATIVE_ESP_RESTART.md", "docs/ESP_RUNTIME.md", "docs/ESP_BOOTSTRAP.md",
    "tools/rover_hc_update.py", "tools/rover_image.py", "tools/rover_qspi_image.py",
    "tools/rover_ram_audit.py", "tools/rover_profile.py", "tools/rover_factory.py",
    "tools/rover_esp_image.py", "tools/rover_hc_handoff.py",
    "tools/rover_parameters.py", "config/rover_parameters.template.json",
    "tests/test_rover_parameters.py", "tests/test_rover_parameters.c", "tests/rover_parameters_fixture.h",
    "tools/rover_acceptance.py", "tools/rover_loader_commission.py",
    "tools/rover_loader_can_commission.py", "tools/rover_esp_ota_commission.py",
    "tests/test_rover_hc_update.py", "tests/test_rover_image.py",
    "tests/test_rover_qspi_image.py", "tests/test_rover_profile.py",
    "config/rover_profile.template.json", "config/installation.template.json",
    "config/acceptance.template.json", "config/rover_loader_qualification.template.json",
    "config/rover_loader_can_qualification.template.json", "config/rover_esp_ota_qualification.template.json",
)
HEADERS = (
    "shared/rover_protocol.h", "shared/rover_profile.h", "shared/rover_auth.h",
    "shared/rover_mission_validator.h", "shared/rover_update_protocol.h",
    "shared/rover_qspi_image.h", "shared/rover_esp_image_verify.h",
    "shared/rover_gnss_config.h",
    "shared/rover_parameters.h", "shared/rover_configuration_store.h",
)


def local(root, name):
    path = root / name
    # Reject file or parent symlinks rather than following a reviewed name to
    # credentials outside the allowlist. All payloads are bounded regular files.
    if not path.resolve().is_relative_to(root.resolve()) or any(
            p.is_symlink() for p in (path, *path.parents) if p != root.parent):
        raise ValueError("Symlink/escaping handoff input: " + name)
    if not path.is_file() or not 0 < path.stat().st_size <= 4*1024*1024:
        raise ValueError("Missing/oversized handoff input: " + name)
    return path.read_bytes()


def payloads(root, spec):
    entries = {name: local(root, name) for name in FILES}
    pending = list(HEADERS)
    while pending:
        name = pending.pop()
        if name in entries:
            continue
        if not re.fullmatch(r"shared/rover_[a-z0-9_]+\.h", name) or "installed" in name:
            raise ValueError("Non-format/installed header dependency rejected: " + name)
        data = local(root, name)
        entries[name] = data
        for include in re.findall(rb'^\s*#include\s+"([^"]+)"', data, re.MULTILINE):
            pending.append("shared/" + include.decode("ascii"))
    if not spec.is_file() or not 0 < spec.stat().st_size <= 1024*1024:
        raise ValueError("Explicit complete v3.1.0 specification required")
    data = spec.read_bytes()
    if not data.startswith("# Rover System Specification — v3.1.0".encode()) or \
            b"### 17.9" not in data or b"## 22." not in data:
        raise ValueError("Wrong/incomplete supplied v3.1.0 specification")
    entries["ROVER_SYSTEM_SPEC_v3.1.0.md"] = data
    manifest = {"schema_version": 1, "purpose": "HC integration handoff, not firmware",
                "secrets_included": False, "device_operations_performed": False,
                "files": [{"path": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
                          for name, data in sorted(entries.items())]}
    entries["MANIFEST.json"] = (json.dumps(manifest, indent=2, ensure_ascii=False)+"\n").encode()
    return entries


def package(root, spec, output):
    entries = payloads(root, spec)  # Validate everything before creating output.
    # Exclusive creation prevents replacement of an earlier handed-off version.
    with output.open("xb") as stream:
        with zipfile.ZipFile(stream, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            for name, data in sorted(entries.items()):
                info = zipfile.ZipInfo(name, (2026, 10, 9, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = 0o100644 << 16
                archive.writestr(info, data)
    return hashlib.sha256(output.read_bytes()).hexdigest(), len(entries)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--spec", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    try:
        sha, count = package(ROOT, args.spec, args.output)
        print(json.dumps({"file": str(args.output), "sha256": sha, "entries": count,
                          "device_operations_performed": False}))
        return 0
    except (OSError, ValueError, UnicodeError) as error:
        print("Handoff rejected: " + str(error), file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
