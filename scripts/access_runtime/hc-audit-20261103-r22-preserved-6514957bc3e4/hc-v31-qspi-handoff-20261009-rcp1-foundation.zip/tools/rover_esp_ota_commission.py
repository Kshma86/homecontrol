#!/usr/bin/env python3
"""Validate measured ESP OTA installation evidence; never flash or enable motion."""
import argparse
import json
from pathlib import Path
import sys
import rover_factory as factory
import rover_profile as profile


def validate(p, q):
    profile.validate(p)
    template = json.loads((profile.ROOT / "config/rover_esp_ota_qualification.template.json").read_text())
    factory.shape(q, template, "esp_ota_qualification")
    profile.integer(q["version"], 1, 1, "version")
    if q["profile_crc"] != f"{profile.checksum(p):08X}":
        raise ValueError("ESP OTA qualification must name the exact installed profile CRC")
    parts = q["partitions"]
    for key in ("a_address", "b_address", "bytes"):
        profile.integer(parts[key], 4096, 0xffffffff, "partitions." + key)
        if parts[key] % 4096:
            raise ValueError("ESP OTA partitions must be 4096-byte aligned")
    a, b, size = parts["a_address"], parts["b_address"], parts["bytes"]
    if max(a, b) + size > 0xffffffff or not (a + size <= b or b + size <= a):
        raise ValueError("ESP OTA partitions must be disjoint and fit the native address range")
    profile.integer(q["watchdog_reset_max_ms"], 1, 10000, "watchdog_reset_max_ms")
    profile.integer(q["watchdog_timeout_ms"], 1, q["watchdog_reset_max_ms"], "watchdog_timeout_ms")
    for name in ("rollback_tested", "entry_reviewed", "loader_service_verified", "timing_verified"):
        factory.flag(q[name], name, True)
    factory.text(q["evidence_id"], "evidence_id")
    return q


def header(p, q):
    validate(p, q)
    parts = q["partitions"]
    values = [profile.checksum(p), parts["a_address"], parts["b_address"], parts["bytes"], q["watchdog_timeout_ms"]]
    return ('#ifndef ROVER_INSTALLED_ESP_OTA_H\n#define ROVER_INSTALLED_ESP_OTA_H\n'
            '#include "rover_esp_ota_installation.h"\n'
            'static const R3EspOtaInstallation r3_installed_esp_ota={' +
            ','.join(str(v) + 'U' for v in values) + ',1,1,1,1,1};\n#endif\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("profile", type=Path)
    parser.add_argument("qualification", type=Path)
    parser.add_argument("--header", type=Path)
    args = parser.parse_args()
    try:
        p, q = [json.loads(path.read_text(), object_pairs_hook=profile.reject_duplicate_keys)
                for path in (args.profile, args.qualification)]
        output = header(p, q)
        if args.header:
            args.header.write_text(output, encoding="ascii")
        print("Measured ESP OTA qualification validated. No flash/reset/motion operation performed.")
    except (OSError, TypeError, ValueError) as error:
        print(str(error), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
