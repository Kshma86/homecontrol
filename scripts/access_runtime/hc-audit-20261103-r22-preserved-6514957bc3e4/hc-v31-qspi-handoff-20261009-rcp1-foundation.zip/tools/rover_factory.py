#!/usr/bin/env python3
"""Build a layout-specific CRC-protected local installation record; never flash it."""
import argparse
import json
from pathlib import Path
import re
import struct
import sys
import zlib
import rover_profile as profile

TEMPLATE = profile.ROOT / "config/installation.template.json"
VI_LAYOUT = "H743_2M_AB1"
VG_LAYOUT = "H743_1M_QSPI_REC2"
NOR_PINS = {("B", 2), ("B", 6), ("D", 11), ("D", 12), ("D", 13), ("E", 2)}


def shape(value, template, path="installation"):
    if type(template) is dict:
        if type(value) is not dict or set(value) != set(template):
            raise ValueError(f"{path}: exact manifest fields required")
        for k, v in template.items():
            shape(value[k], v, path + "." + k)
    elif type(template) is list:
        if path.endswith(".dma_streams"):
            if type(value) is not list or len(value) > 16:
                raise ValueError("dma_streams: at most 16 stream definitions")
            for i, v in enumerate(value):
                shape(v, template[0], f"{path}[{i}]")
            return
        if type(value) is not list or len(value) != len(template):
            raise ValueError(f"{path}: expected {len(template)} entries")
        for i, (v, t) in enumerate(zip(value, template)):
            shape(v, t, f"{path}[{i}]")
    elif value is None:
        raise ValueError(f"{path}: installation value is not supplied")


def text(value, name, limit=80):
    if type(value) is not str or not 1 <= len(value) <= limit or any(ord(c) < 32 or ord(c) > 126 for c in value):
        raise ValueError(f"{name}: nonempty ASCII text, max {limit} characters")


def flag(value, name, required=False):
    if type(value) is not bool or (required and not value):
        raise ValueError(f"{name}: expected {'verified true' if required else 'boolean'}")


def validate(p, m, *, layout=VI_LAYOUT):
    if layout not in (VI_LAYOUT, VG_LAYOUT):
        raise ValueError("Unknown factory layout")
    profile.validate(p)
    shape(m, json.loads(TEMPLATE.read_text()))
    profile.integer(m["manifest_version"], 1, 1, "manifest_version")
    text(m["board_id"], "board_id")
    cpu = m["mcu"]
    model = "STM32H743VG" if layout == VG_LAYOUT else "STM32H743VI"
    flash_bytes = 1048576 if layout == VG_LAYOUT else 2097152
    if cpu["model"] != model:
        raise ValueError(f"Factory layout {layout} requires verified {model}")
    if type(cpu["uid"]) is not str or not re.fullmatch(r"[0-9A-F]{24}", cpu["uid"]):
        raise ValueError("mcu.uid: exact 96-bit uppercase MCU UID required")
    profile.integer(cpu["revision"], 0, 0xffff, "mcu.revision")
    profile.integer(cpu["flash_bytes"], flash_bytes, flash_bytes, "mcu.flash_bytes")
    if layout == VG_LAYOUT:
        profile.integer(cpu["revision"], 0x2003, 0x2003, "reviewed VG revision")
    clocks = m["clock_tree"]
    for key in ("sysclk_source", "usart1_source", "fdcan_source"):
        text(clocks[key], "clock_tree." + key, 40)
    for key in ("sysclk_hz", "hclk_hz", "pclk1_hz", "pclk2_hz"):
        profile.integer(clocks[key], 1, 480000000, "clock_tree." + key)
    if clocks["hclk_hz"] > clocks["sysclk_hz"] or any(clocks[k] > clocks["hclk_hz"] for k in ("pclk1_hz", "pclk2_hz")):
        raise ValueError("Clock tree bus frequencies are inconsistent")
    flag(m["dma_reviewed"], "dma_reviewed", p["commissioned"])
    dma_channels = set()
    for channel in m["dma_streams"]:
        text(channel["peripheral"], "dma.peripheral", 32)
        if channel["controller"] not in ("DMA1", "DMA2", "BDMA", "MDMA", "IDMA"):
            raise ValueError("dma.controller: verified DMA controller required")
        profile.integer(channel["stream"], 0, 15 if channel["controller"] == "MDMA" else 7, "dma.stream")
        profile.integer(channel["request"], 0, 255, "dma.request")
        profile.integer(channel["irq_priority"], 0, 15, "dma.irq_priority")
        if channel["mode"] not in ("NORMAL", "CIRCULAR", "DOUBLE_BUFFER"):
            raise ValueError("dma.mode: unsupported mode")
        key = (channel["controller"], channel["stream"])
        if key in dma_channels:
            raise ValueError("DMA stream conflict")
        dma_channels.add(key)
    used = set(NOR_PINS) if layout == VG_LAYOUT else set()
    for name, instance in (("stm_uart", "USART1"), ("stm_can", "FDCAN1")):
        bus = m[name]
        if bus["instance"] != instance:
            raise ValueError(f"{name}: expected {instance}")
        profile.integer(bus["clock_hz"], 1, 480000000, name + ".clock_hz")
        for direction in ("rx", "tx"):
            pin = bus[direction]
            if type(pin["port"]) is not str or not re.fullmatch("[A-K]", pin["port"]):
                raise ValueError(f"{name}.{direction}: verified GPIO port required")
            profile.integer(pin["pin"], 0, 15, name + ".pin")
            profile.integer(pin["alternate"], 0, 15, name + ".alternate")
            key = (pin["port"], pin["pin"])
            if key in used:
                raise ValueError("Peripheral GPIO pin conflict")
            used.add(key)
    profile.integer(m["stm_uart"]["baud"], 115200, 115200, "stm_uart.baud")
    profile.integer(m["stm_can"]["bitrate"], 500000, 500000, "stm_can.bitrate")
    for pin in p["safety_inputs"].values():
        if pin["present"]:
            key = (pin["port"], pin["pin"])
            if key in used:
                raise ValueError("Safety input conflicts with peripheral GPIO")
            used.add(key)
    stop = m["physical_stop"]
    inhibit = stop["drive_inhibit"]
    flag(inhibit["present"], "drive_inhibit.present")
    profile.integer(inhibit["pin"], 0, 15, "drive_inhibit.pin")
    profile.integer(inhibit["active_level"], 0, 1, "drive_inhibit.active_level")
    if inhibit["present"]:
        if type(inhibit["port"]) is not str or not re.fullmatch("[A-K]", inhibit["port"]):
            raise ValueError("drive_inhibit: present port A..K required")
        if (inhibit["port"], inhibit["pin"]) in used:
            raise ValueError("Drive inhibit conflicts with a peripheral/input")
        used.add((inhibit["port"], inhibit["pin"]))
    elif inhibit["port"] != "NONE" or inhibit["pin"] != 0:
        raise ValueError("Absent drive inhibit requires NONE/pin 0")
    for key in ("power_removal_tested", "sense_pin_tested"):
        flag(stop[key], "physical_stop." + key, p["commissioned"] and
             inhibit["present"] and m["motor_inhibit_feedback_present"])
    text(stop["evidence_id"], "physical_stop.evidence_id")
    feedback = m["motor_inhibit_feedback"]
    present = m["motor_inhibit_feedback_present"]
    flag(present, "motor_inhibit_feedback_present")
    profile.integer(feedback["pin"], 0, 15, "motor_inhibit_feedback.pin")
    profile.integer(feedback["active_level"], 0, 1, "motor_inhibit_feedback.active_level")
    if present:
        if type(feedback["port"]) is not str or not re.fullmatch("[A-K]", feedback["port"]):
            raise ValueError("motor_inhibit_feedback: verified port A..K required")
        if (feedback["port"], feedback["pin"]) in used:
            raise ValueError("Motor inhibit feedback conflicts with a peripheral/input/output")
        profile.integer(m["power_removed_coast_ms"], 1000, 60000, "power_removed_coast_ms")
    else:
        if feedback != {"port": "NONE", "pin": 0, "active_level": 0}:
            raise ValueError("Absent motor inhibit feedback requires NONE/pin 0/level 0")
        profile.integer(m["power_removed_coast_ms"], 0, 0, "power_removed_coast_ms (unavailable)")
    reset = m["esp_reset"]
    profile.integer(reset["gpio"], 13, 13, "esp_reset.gpio")
    for key in ("open_drain_tested", "recovery_tested", "boot0_normal_tested"):
        flag(reset[key], "esp_reset." + key, p["commissioned"])
    gnss = m["gnss"]
    profile.integer(gnss["installed_baud"], 9600, 921600, "gnss.installed_baud")
    profile.integer(gnss["operational_baud"], 115200, 115200, "gnss.operational_baud")
    text(gnss["firmware"], "gnss.firmware", 40)
    text(gnss["protocol"], "gnss.protocol", 16)
    imu = m["imu"]
    profile.integer(imu["i2c_bus_hz"], 100000, 400000, "imu.i2c_bus_hz")
    for key in ("mount_tested", "body_signs_tested", "lever_arm_tested"):
        flag(imu[key], "imu." + key, p["commissioned"])
    for i, driver in enumerate(m["vesc"]):
        profile.integer(driver["id"], i+1, i+1, "vesc.id")
        if driver["firmware"] != p["vesc_firmware"][i]:
            raise ValueError("VESC firmware differs from profile")
        profile.integer(driver["timeout_ms"], 500, 500, "vesc.timeout_ms")
        profile.integer(driver["brake_current_limit_ma"], 0, 0x7fffffff, "vesc.brake_current_limit_ma")
        profile.integer(driver["timeout_brake_ma"], 0, driver["brake_current_limit_ma"], "vesc.timeout_brake_ma")
        expected_timeout_brake = p["wheel_brake_ma"][i] if i < 2 else 0
        if driver["timeout_brake_ma"] != expected_timeout_brake:
            raise ValueError("VESC timeout braking must match profile wheels and zero-current blade coast")
        if i < 2 and p["wheel_brake_ma"][i] > driver["brake_current_limit_ma"]:
            raise ValueError("Profile wheel braking exceeds saved VESC current limit")
        if type(driver["config_export_sha256"]) is not str or not re.fullmatch(r"[0-9A-F]{64}", driver["config_export_sha256"]):
            raise ValueError("VESC config export SHA256 required")
    tests = m["stop_tests"]
    for key in ("wheel_stop_max_ms", "timeout_stop_max_ms"):
        profile.integer(tests[key], 1, p["stop_test_max_ms"], "stop_tests." + key)
    profile.integer(tests["stop_decel_lower_mm_s2"], p["stop_deceleration_mm_s2"], 0xffffffff, "stop_tests.stop_decel_lower_mm_s2")
    profile.integer(tests["blade_stop_max_ms"], 0 if not p["blade_enabled"] else 1, 0xffffffff, "stop_tests.blade_stop_max_ms")
    text(tests["terrain_evidence"], "stop_tests.terrain_evidence")
    return {"profile": p, "installation": m}


def record(p, m, *, layout=VI_LAYOUT):
    data = json.dumps(validate(p, m, layout=layout), sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("ascii")
    if not 1 <= len(data) <= 16384:
        raise ValueError("Factory JSON exceeds 16384 bytes")
    vg = layout == VG_LAYOUT
    head = struct.pack("<4sIII", b"RFI2" if vg else b"RFI1", len(data), zlib.crc32(data) & 0xffffffff, 2 if vg else 0)
    return (head + data).ljust(32768 if vg else 131072, b"\xff")


def gnss_header(p, m, *, layout=VI_LAYOUT):
    validate(p, m, layout=layout)
    g = m["gnss"]
    text(g["firmware"], "gnss.firmware (MON-VER swVersion)", 30)
    if g["protocol"] != "27.11":
        raise ValueError("GNSS runtime currently supports only verified protocol 27.11")
    return ('#ifndef ROVER_INSTALLED_GNSS_H\n#define ROVER_INSTALLED_GNSS_H\n'
            '#include "rover_gnss_config.h"\n'
            f'static const R3GnssInstallation r3_installed_gnss = {{{profile.checksum(p)}U,'
            f'{g["installed_baud"]}U,{json.dumps(g["firmware"])},{json.dumps(g["protocol"])},1}};\n'
            '#endif\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("profile", type=Path)
    parser.add_argument("installation", type=Path)
    parser.add_argument("--layout", choices=(VI_LAYOUT, VG_LAYOUT), default=VI_LAYOUT)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--gnss-header", type=Path, help="Generate the profile-bound ESP receiver setup header")
    args = parser.parse_args()
    try:
        p = json.loads(args.profile.read_text(), object_pairs_hook=profile.reject_duplicate_keys)
        m = json.loads(args.installation.read_text(), object_pairs_hook=profile.reject_duplicate_keys)
        binary = record(p, m, layout=args.layout)
        receiver_header = gnss_header(p, m, layout=args.layout) if args.gnss_header else None
        if args.output:
            args.output.write_bytes(binary)
        if args.gnss_header:
            args.gnss_header.write_text(receiver_header, encoding="ascii")
        print(f"Valid {binary[:4].decode('ascii')} ({args.layout}); profile CRC {profile.checksum(p):08X}; no flash/protection changes performed.")
    except (OSError, ValueError) as error:
        print(str(error), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
