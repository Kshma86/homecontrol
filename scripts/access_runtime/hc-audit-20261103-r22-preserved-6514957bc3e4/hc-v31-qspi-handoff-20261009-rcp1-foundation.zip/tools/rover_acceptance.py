#!/usr/bin/env python3
"""Prepare and audit T01-T52 evidence. Never commission a rover or enable motion."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import sys
import rover_factory
import rover_profile
import rover_image
import rover_esp_image

TITLES = (
    "Coordinates/kinematics", "Heading reference", "Old browser", "HC/MQTT loss",
    "GNSS wire loss", "IMU loss", "Duplicate samples", "Frame length/CRC", "Mixed traffic",
    "Pause/resume", "Displacement", "Mission parameters", "Capacity", "Format rejection",
    "Fault immunity", "Lost START ACK", "Stale commands", "Controller loss", "Priority under load",
    "Reconnect stress", "CAN fault/feedback", "Manual expiry", "Accuracy/units", "Geometry",
    "Runtime fence/quality", "Physical stops", "Interrupted upload", "Restart matrix", "ESP OTA",
    "Soak/headroom", "Legacy removal", "Clock/sequence wrap", "Blade spin-up/coast", "Profile mismatch",
    "Unavailable devices", "State coherence", "Exclusive entry", "Channel isolation", "Image rejection",
    "Power cuts", "Journal rollover/ECC", "Trial rollback", "Successful A/B cycle", "UART transaction faults",
    "Flash scheduling", "Dead-app recovery", "Broken sensors", "Network/MCU restart matrix", "Abort and STOP",
    "Finish and stale replay", "Transfer capacity", "Recovery persistence/protection",
)
HARDWARE = {"T23", "T26", "T29", "T30", "T40", "T41", "T43", "T45", "T46", "T51", "T52"}
ARTIFACTS = ("stm_image", "esp_image", "loader_image", "profile", "installation", "vesc_1", "vesc_2", "vesc_3")


def template():
    return {"schema_version": 1, "contract": "3.1.0", "profile_crc32": None,
            "artifacts": dict.fromkeys(ARTIFACTS),
            "tests": [{"id": f"T{i:02}", "title": title, "status": "NOT_RUN", "environment": None,
                       "method": None, "operator": None, "observed_ms": {}, "evidence": []}
                      for i, title in enumerate(TITLES, 1)]}


def exact(value, keys, name):
    if type(value) is not dict or set(value) != set(keys):
        raise ValueError(f"{name}: exact fields required")


def duplicate_check(pairs):
    out = {}
    for key, value in pairs:
        if key in out:
            raise ValueError(f"Duplicate JSON field: {key}")
        out[key] = value
    return out


def load(path):
    if path.stat().st_size > 1048576:
        raise ValueError("Evidence JSON exceeds 1 MiB")
    return json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=duplicate_check,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(f"Invalid number: {value}")))


def artifact(ref, base):
    exact(ref, ("path", "sha256"), "artifact")
    if type(ref["path"]) is not str or not ref["path"] or Path(ref["path"]).is_absolute():
        raise ValueError("Artifact path must be relative to the evidence file")
    path = (base / ref["path"]).resolve()
    if not path.is_relative_to(base.resolve()) or not path.is_file():
        raise ValueError("Artifact must be an existing file within the evidence directory")
    if type(ref["sha256"]) is not str or not re.fullmatch("[0-9a-f]{64}", ref["sha256"]):
        raise ValueError("Artifact requires its exact lowercase SHA-256")
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(65536), b""):
            digest.update(block)
    if digest.hexdigest() != ref["sha256"]:
        raise ValueError(f"Artifact changed: {ref['path']}")
    return path


def audit(record, base):
    model = template()
    exact(record, model, "acceptance")
    if type(record["schema_version"]) is not int or record["schema_version"] != 1 or record["contract"] != "3.1.0":
        raise ValueError("Acceptance schema 1 / contract 3.1.0 required")
    exact(record["artifacts"], ARTIFACTS, "artifacts")
    paths = {key: artifact(value, base) for key, value in record["artifacts"].items() if value is not None}
    crc = record["profile_crc32"]
    if crc is not None and (type(crc) is not str or not re.fullmatch("[0-9A-F]{8}", crc)):
        raise ValueError("Installed profile CRC must be eight uppercase hex digits")
    profile = None
    if "profile" in paths:
        profile = load(paths["profile"])
        rover_profile.validate(profile)
        if crc != f"{rover_profile.checksum(profile):08X}":
            raise ValueError("Installed profile/CRC mismatch")
    if "installation" in paths:
        if profile is None:
            raise ValueError("Installation evidence requires measured profile")
        installation = load(paths["installation"])
        rover_factory.validate(profile, installation)
        for driver in installation["vesc"]:
            ref = record["artifacts"][f"vesc_{driver['id']}"]
            if ref is not None and ref["sha256"].upper() != driver["config_export_sha256"]:
                raise ValueError("VESC export differs from the installed manifest")
    if "stm_image" in paths:
        with paths["stm_image"].open("rb") as stream:
            metadata = rover_image.inspect(stream.read(rover_image.MAX_BYTES+1))
        if crc != metadata["profile_crc"]:
            raise ValueError("STM firmware differs from the installed profile CRC")
    if "esp_image" in paths:
        size = paths["esp_image"].stat().st_size
        if not 464 <= size < 0x1000000:
            raise ValueError("ESP application evidence has invalid length")
        # Prefix observation binds profile/contract/target, not a claim of SDK
        # signature validation or the installed inactive-partition capacity.
        metadata = rover_esp_image.inspect_prefix(paths["esp_image"].read_bytes(), (size+4095)//4096*4096)
        if crc != metadata["profile_crc"]:
            raise ValueError("ESP firmware differs from the installed profile CRC")
    if "loader_image" in paths and not 8 <= paths["loader_image"].stat().st_size <= 131072:
        raise ValueError("Loader artifact exceeds its protected sector or is empty")
    tests = record["tests"]
    if type(tests) is not list or len(tests) != 52:
        raise ValueError("All T01-T52 entries are required exactly once")
    seen, passed, hardware_passed, host_passed = set(), [], [], []
    for test in tests:
        exact(test, model["tests"][0], "test")
        tid = test["id"]
        if type(tid) is not str or tid not in {f"T{i:02}" for i in range(1, 53)} or tid in seen:
            raise ValueError("Duplicate/unknown test ID")
        seen.add(tid)
        if test["title"] != TITLES[int(tid[1:])-1]:
            raise ValueError(f"{tid}: title changed")
        if test["status"] not in ("NOT_RUN", "BLOCKED", "PASS", "FAIL"):
            raise ValueError(f"{tid}: invalid status")
        if test["environment"] not in (None, "HOST", "INJECTED_IO", "HARDWARE"):
            raise ValueError(f"{tid}: invalid environment")
        if type(test["observed_ms"]) is not dict or len(test["observed_ms"]) > 32:
            raise ValueError(f"{tid}: bounded named observations required")
        for name, value in test["observed_ms"].items():
            if not re.fullmatch("[a-z][a-z0-9_]{0,47}", name) or type(value) is not int or not 0 <= value <= 0xffffffff:
                raise ValueError(f"{tid}: observations must be nonnegative integer milliseconds")
        if type(test["evidence"]) is not list or len(test["evidence"]) > 32:
            raise ValueError(f"{tid}: at most 32 evidence files")
        for ref in test["evidence"]:
            artifact(ref, base)
        for key, limit in (("method", 4096), ("operator", 128)):
            if test[key] is not None and (type(test[key]) is not str or not 1 <= len(test[key]) <= limit):
                raise ValueError(f"{tid}: bounded nonempty {key} required")
        if test["status"] not in ("PASS", "FAIL"):
            continue
        if not test["method"] or not test["operator"] or not test["environment"] or not test["evidence"]:
            raise ValueError(f"{tid}: a result requires method/operator/environment/captured evidence")
        if test["status"] == "FAIL":
            continue
        if test["environment"] == "HOST":
            host_passed.append(tid)
            continue  # A host result is never counted as completed system acceptance.
        required = set(ARTIFACTS) - ({"vesc_3"} if profile and not profile["blade_enabled"] else set())
        if not required <= set(paths) or crc is None:
            raise ValueError(f"{tid}: system PASS requires firmware/profile/installation/VESC artifacts")
        if tid in HARDWARE and test["environment"] != "HARDWARE":
            raise ValueError(f"{tid}: requires physical hardware evidence")
        observed = test["observed_ms"]
        if tid == "T19" and ("stop_enqueue" not in observed or observed["stop_enqueue"] > 100):
            raise ValueError("T19: measured healthy STOP enqueue must be <=100 ms")
        if tid == "T30" and (observed.get("normal_soak", 0) < 3600000 or observed.get("stress_soak", 0) < 900000):
            raise ValueError("T30: 60-minute normal plus 15-minute stress evidence required")
        passed.append(tid)
        if test["environment"] == "HARDWARE":
            hardware_passed.append(tid)
    return {"contract": "3.1.0", "system_passed": passed, "hardware_passed": hardware_passed,
            "host_only_passed": host_passed, "missing_system": sorted(seen-set(passed)),
            "system_acceptance_percent": round(100*len(passed)/52, 1),
            "conformant": False, "motion_enabled": False,
            "note": "Evidence integrity/schema audit only; not commissioning or independent verification of the recorded test result."}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    init = sub.add_parser("init")
    init.add_argument("output", type=Path)
    check = sub.add_parser("check")
    check.add_argument("record", type=Path)
    check.add_argument("--require-complete", action="store_true")
    args = parser.parse_args()
    try:
        if args.command == "init":
            with args.output.open("x", encoding="utf-8") as stream:
                json.dump(template(), stream, indent=2, ensure_ascii=True)
                stream.write("\n")
        else:
            report = audit(load(args.record), args.record.resolve().parent)
            print(json.dumps(report, sort_keys=True, separators=(",", ":")))
            return 2 if args.require_complete and report["missing_system"] else 0
    except (ValueError, OSError, TypeError) as error:
        print(f"Acceptance rejected: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
