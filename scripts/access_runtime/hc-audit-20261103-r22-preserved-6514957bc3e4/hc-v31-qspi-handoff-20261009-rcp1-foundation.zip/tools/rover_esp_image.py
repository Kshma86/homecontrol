#!/usr/bin/env python3
"""Inspect/check ESP app artifacts against their ELF; never flash or enable OTA."""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import re
import struct
import subprocess
import sys
import tempfile
import rover_profile as profile

ESPTOOL_VERSION = "5.1.0"
ELF_MAX_BYTES = 64 * 1024 * 1024
PROFILE_MAX_BYTES = 16384
BUILD_OFFSET = 288
FLASH_MODES = ("qio", "qout", "dio", "dout")
FLASH_SIZES = {i: f"{1 << i}MB" for i in range(8)}
FLASH_FREQS = {0: "40m", 1: "26m", 2: "20m", 15: "80m"}
ESP_MEMORY = ((0x3C000000, 0x3E000000), (0x3FC88000, 0x3FD00000),
              (0x40370000, 0x403E0000), (0x42000000, 0x42800000),
              (0x50000000, 0x50002000), (0x600FE000, 0x60100000))


def capacity_check(capacity):
    if type(capacity) is not int or not 4096 <= capacity < 0x1000000 or capacity % 4096:
        raise ValueError("BAD_LENGTH: explicit aligned OTA partition capacity below 16 MiB required")


def read_bounded(path, limit):
    with Path(path).open("rb") as stream:
        data = stream.read(limit + 1)
    if len(data) > limit:
        raise ValueError("BAD_LENGTH: artifact exceeds bounded input size")
    return data


def inspect_prefix(data, capacity):
    """Metadata observation only; full format is established by ELF regeneration."""
    capacity_check(capacity)
    if not 464 <= len(data) <= capacity:
        raise ValueError("BAD_LENGTH: exact app image must fit the actual inactive partition")
    if data[0] != 0xE9 or not 1 <= data[1] <= 16 or data[23] != 1:
        raise ValueError("BAD_HEADER: standard ESP app with appended SHA256 required")
    if struct.unpack_from("<H", data, 12)[0] != 9:
        raise ValueError("WRONG_TARGET: ESP32-S3 image required")
    address, length = struct.unpack_from("<II", data, 24)
    if not 0x3C000000 <= address < address + length <= 0x3D000000 or address % 65536 != 32:
        raise ValueError("BAD_HEADER: standard 64-KiB mapped first app segment required")
    if not 384 <= length <= len(data) - 32 or struct.unpack_from("<I", data, 32)[0] != 0xABCD5432:
        raise ValueError("BAD_HEADER: first segment must contain SDK and rover descriptors")
    if data[212] not in (0, 16):
        raise ValueError("BAD_HEADER: this artifact policy requires 64-KiB MMU pages")
    h = data[BUILD_OFFSET:BUILD_OFFSET + 128]
    if h[:4] != b"RFE1" or struct.unpack_from("<HH", h, 4) != (128, 1) or any(h[84:]):
        raise ValueError("BAD_HEADER: RFE1 format, size or reserved padding")
    if h[8:24] != b"ESP32S3".ljust(16, b"\0"):
        raise ValueError("WRONG_TARGET: rover descriptor target")
    if struct.unpack_from("<HHHH", h, 24) != (3, 1, 0, 1):
        raise ValueError("ABI_MISMATCH: rover contract 3.1.0 / service ABI 1 required")
    fw = h[36:84]
    nul = fw.find(b"\0")
    if nul >= 0:
        if any(fw[nul:]):
            raise ValueError("BAD_HEADER: firmware ID must be zero padded")
        fw = fw[:nul]
    if not re.fullmatch(rb"[A-Za-z0-9_.-]{1,48}", fw):
        raise ValueError("BAD_HEADER: invalid firmware ID")
    return dict(target="ESP32S3", slot="NONE", image_bytes=len(data),
                image_sha256=hashlib.sha256(data).hexdigest(), fw_id=fw.decode("ascii"),
                profile_crc=f"{struct.unpack_from('<I', h, 32)[0]:08X}",
                contract="3.1.0", service_abi=1, artifact_verified=False, profile_verified=False,
                conformant=False, stm_remote_update=False, esp_ota_enabled=False)


def esptool_path():
    root = Path(os.environ.get("ARDUINO_DATA_DIR", Path.home() / ".arduino15"))
    return Path(os.environ.get("ROVER_ESPTOOL", root / "packages/esp32/tools/esptool_py/5.1.0/esptool"))


def run_esptool(tool, arguments):
    try:
        result = subprocess.run([str(tool), *arguments], capture_output=True, text=True, timeout=60)
    except (OSError, subprocess.TimeoutExpired) as error:
        raise ValueError("DEPENDENCY_ERROR: pinned local esptool unavailable or timed out") from error
    if result.returncode:
        raise ValueError("BAD_HEADER: esptool rejected the ELF artifact: " + (result.stderr or result.stdout).strip()[-1200:])
    return result.stdout.strip()


def sdk_external_ram_reservation(section, sections):
    """The pinned SDK's NOLOAD alias excludes flash rodata from the PSRAM bus.

    Only its exact linker geometry is exempt from overlap checking; actual
    data/BSS, renamed reservations and malformed NOLOAD aliases still reject.
    """
    if section.name != ".ext_ram.dummy":
        return False
    by_name = {}
    for item in sections:
        by_name.setdefault(item.name, []).append(item)
    names = (".ext_ram.dummy", ".flash_rodata_dummy", ".flash.appdesc", ".flash.rodata")
    if any(len(by_name.get(name, [])) != 1 for name in names):
        raise ValueError("BAD_HEADER: SDK external RAM reservation section identity")
    dummy, desc, rodata = (by_name[name][0] for name in names[1:])
    start = 0x3C000020
    end = (rodata["sh_addr"] + rodata["sh_size"] + 65535) & ~65535
    if (section["sh_type"] != "SHT_NOBITS" or section["sh_flags"] != 3 or
            section["sh_addralign"] != 1 or section["sh_addr"] != start or
            section["sh_size"] != end - start or
            dummy["sh_type"] != "SHT_NOBITS" or dummy["sh_flags"] != 3 or
            dummy["sh_addr"] != start or dummy["sh_addr"] + dummy["sh_size"] != desc["sh_addr"] or
            desc["sh_type"] != "SHT_PROGBITS" or desc["sh_flags"] != 2 or
            rodata["sh_type"] != "SHT_PROGBITS" or rodata["sh_flags"] & 6 != 2 or
            rodata["sh_addr"] != desc["sh_addr"] + desc["sh_size"] or
            not start <= desc["sh_addr"] < end <= 0x3E000000):
        raise ValueError("BAD_HEADER: SDK external RAM reservation geometry")
    return True


def verify_elf(elf_bytes, data, tool=None):
    try:
        from elftools.elf.elffile import ELFFile
        from elftools.common.exceptions import ELFError
    except ImportError as error:
        raise ValueError("DEPENDENCY_ERROR: ELF verification requires pyelftools") from error
    if not elf_bytes or len(elf_bytes) > ELF_MAX_BYTES:
        raise ValueError("BAD_LENGTH: bounded nonempty ELF required")
    try:
        elf = ELFFile(io.BytesIO(elf_bytes))
        if elf.elfclass != 32 or not elf.little_endian or elf["e_machine"] != "EM_XTENSA" or elf["e_type"] != "ET_EXEC":
            raise ValueError("BAD_HEADER: executable little-endian Xtensa ELF required")
        if elf["e_entry"] != struct.unpack_from("<I", data, 4)[0]:
            raise ValueError("BAD_HEADER: ELF/image entry point disagreement")
        sections = list(elf.iter_sections())
        intervals, loaded = [], 0
        for section in sections:
            size, address = section["sh_size"], section["sh_addr"]
            reservation = sdk_external_ram_reservation(section, sections)
            if section["sh_type"] != "SHT_NOBITS" and section["sh_offset"] + size > len(elf_bytes):
                raise ValueError("BAD_HEADER: section bytes outside bounded ELF")
            if not address or not size:
                continue
            if section["sh_flags"] & 2:
                if not any(low <= address < address + size <= high for low, high in ESP_MEMORY):
                    raise ValueError("BAD_HEADER: allocated section outside ESP32-S3 memory")
                alignment = section["sh_addralign"]
                if alignment and (alignment > 65536 or alignment & (alignment - 1)):
                    raise ValueError("BAD_HEADER: invalid allocated section alignment")
                if not reservation:
                    if any(address < end and start < address + size for start, end in intervals):
                        raise ValueError("BAD_HEADER: overlapping allocated ELF sections")
                    intervals.append((address, address + size))
            # esptool also reads addressed PROGBITS/array sections without ALLOC.
            if section["sh_type"] in ("SHT_PROGBITS", "SHT_INIT_ARRAY", "SHT_FINI_ARRAY"):
                if not section["sh_flags"] & 2:
                    raise ValueError("BAD_HEADER: addressed image section must be allocated")
                loaded += size
                if loaded > len(data):
                    raise ValueError("BAD_LENGTH: ELF load bytes exceed exact image")
        for segment in elf.iter_segments():
            if segment["p_filesz"] > len(elf_bytes) or segment["p_offset"] + segment["p_filesz"] > len(elf_bytes):
                raise ValueError("BAD_HEADER: segment bytes outside bounded ELF")
        descriptions = [(i, s) for i, s in enumerate(sections) if s.name == ".flash.appdesc"]
        if len(descriptions) != 1:
            raise ValueError("BAD_HEADER: exactly one linked .flash.appdesc section required")
        index, desc = descriptions[0]
        if desc["sh_type"] != "SHT_PROGBITS" or desc["sh_flags"] & 7 != 2 or desc["sh_size"] < 384:
            raise ValueError("BAD_HEADER: allocated read-only SDK/custom app description required")
        first_address = struct.unpack_from("<I", data, 24)[0]
        if desc["sh_addr"] != first_address or desc["sh_size"] > struct.unpack_from("<I", data, 28)[0]:
            raise ValueError("BAD_HEADER: ELF app description must start the first image segment")
        symbols = elf.get_section_by_name(".symtab")
        found = None if symbols is None else symbols.get_symbol_by_name("roverEspBuildDescriptor")
        if not found or len(found) != 1:
            raise ValueError("BAD_HEADER: exactly one rover build descriptor symbol required")
        symbol = found[0]
        if (symbol["st_value"] != desc["sh_addr"] + 256 or symbol["st_size"] != 128 or
                symbol["st_shndx"] != index or symbol["st_info"]["bind"] != "STB_GLOBAL" or
                symbol["st_info"]["type"] != "STT_OBJECT"):
            raise ValueError("BAD_HEADER: ELF rover descriptor placement, size or binding")
        if desc.data()[256:384] != data[288:416]:
            raise ValueError("BAD_HEADER: ELF/image rover descriptor bytes disagree")
        for name in ("verifyOta", "verifyRollbackLater", "__wrap_initArduino", "roverEspBootstrapReady"):
            hooks = symbols.get_symbol_by_name(name)
            if not hooks or len(hooks) != 1:
                raise ValueError("BAD_HEADER: required linked rover boot hook " + name)
            hook = hooks[0]
            if (hook["st_info"]["bind"] != "STB_GLOBAL" or hook["st_info"]["type"] != "STT_FUNC" or
                    type(hook["st_shndx"]) is not int):
                raise ValueError("BAD_HEADER: strong executable boot hook required: " + name)
            section = elf.get_section(hook["st_shndx"])
            if (section["sh_flags"] & 6 != 6 or not hook["st_size"] or
                    not section["sh_addr"] <= hook["st_value"] < hook["st_value"] + hook["st_size"] <= section["sh_addr"] + section["sh_size"]):
                raise ValueError("BAD_HEADER: boot hook must reside in allocated executable code")
        if not any(s["sh_flags"] & 6 == 6 and s["sh_addr"] <= elf["e_entry"] < s["sh_addr"] + s["sh_size"] for s in sections):
            raise ValueError("BAD_HEADER: ELF entry must reside in allocated executable code")
    except (ELFError, struct.error, IndexError, KeyError, TypeError, AssertionError, OverflowError) as error:
        raise ValueError("BAD_HEADER: malformed ELF artifact") from error

    mode, config = data[2:4]
    if mode >= len(FLASH_MODES) or config >> 4 not in FLASH_SIZES or config & 15 not in FLASH_FREQS:
        raise ValueError("BAD_HEADER: unsupported standard flash mode/size/frequency")
    tool = esptool_path() if tool is None else Path(tool)
    if run_esptool(tool, ["version"]).splitlines() != ["esptool v" + ESPTOOL_VERSION, ESPTOOL_VERSION]:
        raise ValueError("DEPENDENCY_ERROR: esptool 5.1.0 required")
    # Regenerate from the same immutable bytes inspected above, not a reopened ELF.
    with tempfile.TemporaryDirectory(prefix="rover-esp-artifact-") as directory:
        source, output = Path(directory, "app.elf"), Path(directory, "app.bin")
        source.write_bytes(elf_bytes)
        run_esptool(tool, ["--chip", "esp32s3", "elf2image", "--flash-mode", FLASH_MODES[mode],
                          "--flash-freq", FLASH_FREQS[config & 15], "--flash-size", FLASH_SIZES[config >> 4],
                          "--min-rev-full", str(struct.unpack_from("<H", data, 15)[0]),
                          "--max-rev-full", str(struct.unpack_from("<H", data, 17)[0]),
                          "--flash-mmu-page-size", "64KB", "--elf-sha256-offset", "0xb0",
                          "--output", str(output), str(source)])
        regenerated = read_bounded(output, len(data))
        if regenerated != data:
            raise ValueError("BAD_HASH: complete image differs from pinned esptool ELF output")
    return hashlib.sha256(elf_bytes).hexdigest()


def inspect(data, elf_bytes, capacity, tool=None):
    metadata = inspect_prefix(data, capacity)
    metadata["elf_sha256"] = verify_elf(elf_bytes, data, tool)
    metadata["artifact_verified"] = True
    metadata["esptool_version"] = ESPTOOL_VERSION
    return metadata


def check(data, elf_bytes, capacity, firmware_id, sha256, installed_profile, tool=None):
    metadata = inspect_prefix(data, capacity)
    profile.validate(installed_profile)
    if not isinstance(firmware_id, str) or not re.fullmatch(r"[A-Za-z0-9_.-]{1,48}", firmware_id) or firmware_id != metadata["fw_id"]:
        raise ValueError("BAD_HEADER: exact embedded firmware ID required")
    if not isinstance(sha256, str) or not re.fullmatch(r"[0-9a-f]{64}", sha256) or sha256 != metadata["image_sha256"]:
        raise ValueError("BAD_HASH: exact lowercase complete-image SHA256 required")
    if metadata["profile_crc"] != f"{profile.checksum(installed_profile):08X}":
        raise ValueError("PROFILE_MISMATCH: image differs from installed profile")
    metadata["elf_sha256"] = verify_elf(elf_bytes, data, tool)
    metadata["artifact_verified"] = metadata["profile_verified"] = True
    metadata["esptool_version"] = ESPTOOL_VERSION
    return metadata


def distinct_paths(paths):
    resolved = [p.resolve() for p in paths]
    if len(set(resolved)) != len(paths):
        raise ValueError("Package inputs and metadata output must be separate files")
    for i, a in enumerate(resolved):
        for b in resolved[i + 1:]:
            if a.exists() and b.exists() and a.samefile(b):
                raise ValueError("Package paths cannot share a hard-linked file")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="operation", required=True)
    for name in ("inspect", "check", "package"):
        command = sub.add_parser(name)
        command.add_argument("image", type=Path)
        command.add_argument("--elf", type=Path, required=True)
        command.add_argument("--capacity", type=lambda s: int(s, 0), required=True)
        command.add_argument("--esptool", type=Path)
        if name != "inspect":
            command.add_argument("--profile", type=Path, required=True)
            command.add_argument("--firmware-id", required=True)
        if name == "check":
            command.add_argument("--sha256", required=True)
        if name == "package":
            command.add_argument("--metadata", type=Path, required=True)
    args = parser.parse_args()
    try:
        capacity_check(args.capacity)
        if args.operation == "package":
            distinct_paths((args.image, args.elf, args.profile, args.metadata))
            if args.metadata.exists():
                raise ValueError("Metadata output already exists; package never overwrites artifacts")
        data = read_bounded(args.image, args.capacity)
        elf_bytes = read_bounded(args.elf, ELF_MAX_BYTES)
        if args.operation == "inspect":
            metadata = inspect(data, elf_bytes, args.capacity, args.esptool)
        else:
            p = json.loads(read_bounded(args.profile, PROFILE_MAX_BYTES).decode("utf-8"),
                           object_pairs_hook=profile.reject_duplicate_keys)
            digest = hashlib.sha256(data).hexdigest() if args.operation == "package" else args.sha256
            metadata = check(data, elf_bytes, args.capacity, args.firmware_id, digest, p, args.esptool)
        rendered = json.dumps(metadata, sort_keys=True, separators=(",", ":"))
        if args.operation == "package":
            with args.metadata.open("x", encoding="ascii") as stream:
                stream.write(rendered + "\n")
        print(rendered)
    except (OSError, ValueError, RecursionError) as error:
        print(str(error), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
