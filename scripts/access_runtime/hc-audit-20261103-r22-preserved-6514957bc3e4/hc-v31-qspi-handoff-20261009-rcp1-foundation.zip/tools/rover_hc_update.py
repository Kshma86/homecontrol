#!/usr/bin/env python3
"""HC integration adapter for explicit v3.1 STM updates; no legacy or motion API."""
import argparse
import json
import os
from pathlib import Path
import re
import sys
import urllib.error
import urllib.parse
import urllib.request
import rover_image
import rover_qspi_image as qspi


def installed_layout(identity):
    if identity.get("contract") != "3.1.0" or identity.get("stm_remote_update") is not True or \
            type(identity.get("update_service_abi")) is not int:
        raise ValueError("Native STM updater is not advertised as installed; no mutation sent")
    pair = identity["update_service_abi"], identity.get("stm_flash_layout")
    if pair == (1, "H743_2M_AB1"):
        return "AB1"
    if pair == (2, "H743_1M_QSPI2"):
        crc = identity.get("profile_crc")
        if type(identity.get("stm_image_max_bytes")) is not int or identity["stm_image_max_bytes"] != qspi.APP_BYTES or \
                type(crc) is not str or not re.fullmatch("[0-9A-F]{8}", crc) or crc == "0"*8:
            raise ValueError("Exact installed VG profile/capacity required; no mutation sent")
        return "QSPI2"
    raise ValueError("Unknown or contradictory native STM ABI/layout; no mutation sent")


def fresh_loader(status, job, *, ready=False):
    age = status.get("source_age_ms")
    if status.get("update_id") != job or status.get("locked") is not True or \
            status.get("source") != "STM_LOADER" or status.get("source_valid") is not True or \
            type(age) is not int or not 0 <= age <= 2000 or status.get("can_active") is not False or \
            status.get("outputs_inhibited") is not True or \
            (ready and (status.get("target") != "STM" or status.get("phase") != "READY" or status.get("error") != "NONE")):
        raise ValueError("Fresh matching quiescent loader evidence required before mutation")


def update_id(value):
    if type(value) is not str or not re.fullmatch("[0-9A-F]{32}", value) or value == "0"*32:
        raise ValueError("Exact nonzero uppercase update ID required")
    return value


class UnknownMutation(RuntimeError):
    """The reply was lost: reconcile with GET; never auto-replay a mutation."""


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def reject_constant(value):
    raise ValueError("Non-finite JSON number rejected: " + value)


class Http:
    def __init__(self, url, token):
        parsed = urllib.parse.urlsplit(url)
        if parsed.scheme not in ("http", "https") or not parsed.hostname or parsed.username or parsed.password or \
                parsed.path not in ("", "/") or parsed.query or parsed.fragment:
            raise ValueError("Use the rover's HTTP(S) origin only; no credentials/path/query")
        if type(token) is not str or not re.fullmatch("[0-9A-Fa-f]{64}", token):
            raise ValueError("The locally provisioned 64-hex bearer token is required")
        self.url, self.token = url.rstrip("/"), token
        self.opener = urllib.request.build_opener(NoRedirect())

    def __call__(self, method, path, body=None, headers=None):
        if not path.startswith("/api/v3/") or "?" in path or "#" in path:
            raise ValueError("Only exact v3 paths are permitted")
        fields = dict(headers or {})
        fields["Authorization"] = "Bearer " + self.token
        fields["Connection"] = "close"
        request = urllib.request.Request(self.url+path, data=body, headers=fields, method=method)
        try:
            try:
                response = self.opener.open(request, timeout=10)
            except urllib.error.HTTPError as error:
                response = error
            with response:
                payload = response.read(16385)
                if len(payload) > 16384:
                    raise ValueError("Oversized HC update response")
                result = json.loads(payload, object_pairs_hook=rover_image.profile.reject_duplicate_keys,
                                    parse_constant=reject_constant)
                if type(result) is not dict or type(result.get("v")) is not int or result["v"] != 3:
                    raise ValueError("Invalid v3 response")
                return response.status, result
        except (OSError, ValueError) as error:
            if method != "GET":
                raise UnknownMutation("Reply unavailable; GET update status before any further mutation") from error
            raise


class Client:
    def __init__(self, transport):
        self.transport = transport

    def get(self, path):
        code, result = self.transport("GET", path)
        if code != 200:
            raise ValueError(f"Read rejected: HTTP {code}, {result.get('code', 'UNKNOWN')}")
        return result

    def status(self, job=None):
        return self.get("/api/v3/update" + ("/"+update_id(job) if job else ""))

    def create(self, request_id):
        if type(request_id) is not str or not re.fullmatch("[A-Za-z0-9_-]{1,64}", request_id):
            raise ValueError("Exact request_id required")
        identity = self.get("/api/v3/identity")
        installed_layout(identity)
        esp_boot = identity.get("esp_boot")
        if type(esp_boot) is not str or not re.fullmatch("[0-9A-F]{16}", esp_boot) or esp_boot == "0"*16:
            raise ValueError("Current nonzero ESP boot identity required; no create sent")
        body = json.dumps({"v": 3, "request_id": request_id, "esp_boot": esp_boot,
                           "target": "STM"}, separators=(",", ":")).encode("ascii")
        return self.transport("POST", "/api/v3/update", body, {"Content-Type": "application/json"})

    def upload(self, job, a, b):
        job = update_id(job)
        status = self.status(job)
        age = status.get("source_age_ms")
        if status.get("update_id") != job or status.get("target") != "STM" or status.get("locked") is not True or \
                status.get("phase") != "READY" or status.get("error") != "NONE" or \
                status.get("source") != "STM_LOADER" or status.get("source_valid") is not True or \
                type(age) is not int or not 0 <= age <= 2000 or status.get("can_active") is not False or \
                status.get("outputs_inhibited") is not True or status.get("candidate_slot") != "NONE":
            raise ValueError("Fresh matching quiescent loader READY required before image selection")
        confirmed, inactive = status.get("confirmed_slot"), status.get("inactive_slot")
        if confirmed not in ("A", "B", "NONE") or inactive != ("B" if confirmed == "A" else "A"):
            raise ValueError("Loader slot selection is contradictory")
        packages = []
        for path, slot in ((Path(a), "A"), (Path(b), "B")):
            with path.open("rb") as stream:
                data = stream.read(rover_image.MAX_BYTES+1)
            metadata = rover_image.inspect(data)
            if metadata["slot"] != slot:
                raise ValueError("A/B variants must actually be linked for their named slots")
            packages.append((data, metadata))
        if any(packages[0][1][key] != packages[1][1][key] for key in ("fw_id", "profile_crc", "contract", "service_abi")):
            raise ValueError("A/B variants are not the same release/profile")
        data, metadata = packages[inactive == "B"]
        headers = {"Content-Type": "application/octet-stream", "Content-Length": str(len(data)),
                   "X-Image-SHA256": metadata["image_sha256"], "X-Firmware-ID": metadata["fw_id"],
                   "X-Profile-CRC32": metadata["profile_crc"], "X-Contract": "3.1.0",
                   "X-Flash-Layout": "H743_2M_AB1", "X-Image-Slot": inactive}
        # No ACTIVATE, FINISH, ARM or retry follows this body, even after HTTP 202.
        return self.transport("POST", "/api/v3/update/"+job+"/image", data, headers)

    def upload_qspi(self, job, app, elf, sha256, firmware):
        job = update_id(job)
        identity = self.get("/api/v3/identity")
        if installed_layout(identity) != "QSPI2":
            raise ValueError("RFU2 requires the advertised VG ABI2 installation")
        boot = identity.get("esp_boot")
        if type(boot) is not str or not re.fullmatch("[0-9A-F]{16}", boot) or boot == "0"*16:
            raise ValueError("Current ESP boot identity required")
        status = self.status(job)
        fresh_loader(status, job, ready=True)
        if status.get("esp_boot") != boot or any(key not in status or status[key] is not None
                for key in ("confirmed_slot", "inactive_slot", "candidate_slot")):
            raise ValueError("VG requires matching boot and explicit null A/B slot fields")
        with Path(app).open("rb") as stream:
            data = stream.read(qspi.APP_BYTES+1)
        # The approved release hash/token come from the operator/release source,
        # not a hash inferred from an arbitrary file selected in the UI.
        metadata = qspi.check(data, sha256, identity["profile_crc"], firmware)
        qspi.verify_elf(Path(elf), data)
        headers = {"Content-Type": "application/octet-stream", "Content-Length": str(len(data)),
                   "X-Image-SHA256": metadata["image_sha256"], "X-Firmware-ID": metadata["fw_id"],
                   "X-Profile-CRC32": metadata["profile_crc"], "X-Contract": "3.1.0",
                   "X-Flash-Layout": qspi.LAYOUT, "X-Image-Slot": "APP"}
        return self.transport("POST", "/api/v3/update/"+job+"/image", data, headers)

    def abort(self, job):
        return self.transport("POST", "/api/v3/update/"+update_id(job)+"/abort", b"")

    def finish(self, job):
        job = update_id(job)
        status = self.status(job)
        fresh_loader(status, job)
        if status.get("update_id") != job or status.get("locked") is not True or status.get("can_finish") is not True or \
                status.get("phase") not in ("COMPLETE", "ABORTED", "ERROR"):
            raise ValueError("Explicit FINISH requires fresh server-side permission for this terminal job")
        return self.transport("POST", "/api/v3/update/"+job+"/finish", b"")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--url", required=True)
    parser.add_argument("--token-env", default="ROVER_API_TOKEN")
    sub = parser.add_subparsers(dest="command", required=True)
    status = sub.add_parser("status")
    status.add_argument("--id")
    create = sub.add_parser("create")
    create.add_argument("--request-id", required=True)
    upload = sub.add_parser("upload")
    upload.add_argument("--id", required=True)
    upload.add_argument("--a", required=True)
    upload.add_argument("--b", required=True)
    vg = sub.add_parser("upload-qspi")
    vg.add_argument("--id", required=True)
    vg.add_argument("--app", required=True)
    vg.add_argument("--elf", required=True)
    vg.add_argument("--sha256", required=True, help="Independently approved release SHA-256")
    vg.add_argument("--firmware-id", required=True)
    for name in ("abort", "finish"):
        sub.add_parser(name).add_argument("--id", required=True)
    args = parser.parse_args()
    try:
        client = Client(Http(args.url, os.environ.get(args.token_env)))
        if args.command == "status":
            result = client.status(args.id)
        elif args.command == "create":
            code, result = client.create(args.request_id)
        elif args.command == "upload":
            code, result = client.upload(args.id, args.a, args.b)
        elif args.command == "upload-qspi":
            code, result = client.upload_qspi(args.id, args.app, args.elf, args.sha256, args.firmware_id)
        else:
            code, result = getattr(client, args.command)(args.id)
        print(json.dumps(result, sort_keys=True))
        return 0 if args.command == "status" or 200 <= code < 300 else 1
    except (OSError, ValueError, UnknownMutation) as error:
        print(f"HC update stopped: {error}", file=sys.stderr)
        return 2 if isinstance(error, UnknownMutation) else 1


if __name__ == "__main__":
    sys.exit(main())
