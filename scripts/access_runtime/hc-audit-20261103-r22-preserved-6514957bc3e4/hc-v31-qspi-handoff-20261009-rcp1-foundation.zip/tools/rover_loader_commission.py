#!/usr/bin/env python3
"""Validate local loader measurements and generate a closed, board-bound header."""
import argparse
import json
from pathlib import Path
import re
import sys
import rover_factory as factory
import rover_profile as profile
import rover_loader_can_commission as can
import rover_acceptance as acceptance


def validate(p, installation, qualification, can_qualification=None, *, layout=factory.VI_LAYOUT):
    factory.validate(p, installation, layout=layout)
    if layout == factory.VG_LAYOUT and can_qualification is not None:
        raise ValueError("VG requires independent power feedback; VI CAN qualification cannot authorize it")
    template = json.loads((profile.ROOT / "config/rover_loader_qualification.template.json").read_text())
    factory.shape(qualification, template, "loader_qualification")
    q = qualification
    profile.integer(q["version"], 1, 1, "version")
    if q["profile_crc"] != f"{profile.checksum(p):08X}" or q["mcu_uid"] != installation["mcu"]["uid"]:
        raise ValueError("Loader qualification must name the exact installed profile and MCU UID")
    if not re.fullmatch(r"[0-9A-F]{24}", q["mcu_uid"]) or q["mcu_uid"] in ("0" * 24, "F" * 24):
        raise ValueError("A non-erased MCU UID is required")
    for name in ("manual_reviewed", "errata_reviewed"):
        factory.flag(q[name], name, True)
    if installation["mcu"]["revision"] != 0x2003:
        raise ValueError("The native flash owner supports reviewed revision 0x2003 only")
    stop = installation["physical_stop"]
    if stop["drive_inhibit"]["present"] and installation["motor_inhibit_feedback_present"]:
        for name in ("power_removal_tested", "sense_pin_tested"):
            factory.flag(stop[name], name, True)
    elif can_qualification is None:
        raise ValueError("Loader restart needs independent power feedback or a bound measured CAN qualification")
    else:
        can.validate(p, installation, can_qualification)
    regs = q["loader_registers"]
    # Recovery deliberately retains the reset HSI clock; this is not the APP PLL.
    profile.integer(regs["hclk_hz"], 64000000, 64000000, "loader HCLK")
    for name in ("flash_acr", "power_cr3", "power_d3cr", "flash_optsr_cur"):
        profile.integer(regs[name], 0, 0xffffffff, name)
    w = q["watchdog"]
    for name in ("lsi_min_hz", "lsi_max_hz"):
        profile.integer(w[name], 1, 1000000, name)
    if w["lsi_min_hz"] > w["lsi_max_hz"] or 4000000 > 200*w["lsi_min_hz"] or 4000000 < 40*w["lsi_max_hz"]:
        raise ValueError("Measured PR=0/RLR=999 watchdog interval must be within 40..200 ms")
    profile.integer(w["reset_max_ms"], 1, 250, "Measured watchdog reset bound")
    factory.text(w["evidence_id"], "watchdog.evidence_id")
    s = q["supply"]
    for name in ("vref_tracks_vdd_verified", "temperature_range_tested"):
        factory.flag(s[name], name, True)
    profile.integer(s["vdd_error_mv"], 1, 100, "Characterized worst-case VDD error")
    factory.text(s["evidence_id"], "supply.evidence_id")
    return q


def header(p, installation, qualification, can_qualification=None, *, layout=factory.VI_LAYOUT):
    q = validate(p, installation, qualification, can_qualification, layout=layout)
    r, w = q["loader_registers"], q["watchdog"]
    numbers = [profile.checksum(p), r["hclk_hz"], r["flash_acr"], r["power_cr3"],
               r["power_d3cr"], r["flash_optsr_cur"], w["lsi_min_hz"], w["lsi_max_hz"], q["supply"]["vdd_error_mv"]]
    fields = [json.dumps(q["mcu_uid"])] + [f"{value}U" for value in numbers] + ["1"] * 5
    guard = "ROVER_INSTALLED_QSPI_LOADER_H" if layout == factory.VG_LAYOUT else "ROVER_INSTALLED_LOADER_H"
    symbol = "rover_installed_qspi_loader" if layout == factory.VG_LAYOUT else "rover_installed_loader"
    return (f"#ifndef {guard}\n#define {guard}\n"
            '#include "rover_loader_commission.h"\n'
            f"static const RoverLoaderCommission {symbol} = {{" + ",".join(fields) + "};\n#endif\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("profile", type=Path)
    parser.add_argument("installation", type=Path)
    parser.add_argument("qualification", type=Path)
    parser.add_argument("--header", type=Path)
    parser.add_argument("--can-qualification", type=Path)
    parser.add_argument("--layout", choices=(factory.VI_LAYOUT, factory.VG_LAYOUT), default=factory.VI_LAYOUT)
    args = parser.parse_args()
    try:
        values = [acceptance.load(path) for path in (args.profile, args.installation, args.qualification)]
        cq = acceptance.load(args.can_qualification) if args.can_qualification else None
        output = header(*values, cq, layout=args.layout)
        if args.header:
            with args.header.open("x", encoding="ascii") as stream:
                stream.write(output)
        print("Local loader qualification validated; no flashing or remote-update permission granted.")
    except (OSError, ValueError, TypeError) as error:
        print(str(error), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
