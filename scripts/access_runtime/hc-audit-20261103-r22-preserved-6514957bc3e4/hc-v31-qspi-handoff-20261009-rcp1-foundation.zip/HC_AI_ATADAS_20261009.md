# HC-oldali AI-átadás — rover v3.1 / VG–QSPI

Ezt a fájlt és a hozzá tartozó ZIP-et add át a másik gépen dolgozó AI-nak.
Frissítve: 2026-10-09. A HC alkalmazás forrása ezen a gépen nincs jelen.

ÚJ FELHASZNÁLÓI KÖVETELMÉNY: a roverparamétereket a HC-ban kell kezelni és a
roveren tartós runtime konfigurációként alkalmazni, firmware újrafordítás nélkül.
Először olvasd el `docs/HC_PARAMETER_MANAGEMENT.md`-t. Ez felülírja a baseline
4.2 immutable-profile előírását, de a roveroldali írási szolgáltatás még nincs
kész. A csomagolt update mintakód a jelenlegi firmware API-ra vonatkozik.
Az RCP1 paraméterséma/codec már futtatható referencia:
`docs/HC_PARAMETERS_RCP1.md`, `tools/rover_parameters.py` és
`config/rover_parameters.template.json`. Használd az editor validálásához;
`runtime_parameters=false` mellett tényleges rover-apply nincs.

## Feladat a másik AI számára

Vizsgáld meg a helyi HC repositoryt és annak saját munkautasításait. Implementáld
a rover v3.1 hitelesített backend-integrációját, a frissítési kezelőfelületet,
az állapotmegjelenítést, a kézi vezérlés backend WS-reléjét és a szükséges
küldetésfeltöltést. Készíts HC paraméterszerkesztőt és roverenkénti drafttárolást
is az új követelmény szerint; tényleges apply csak a roveroldali API elkészülte
után. Ne generált C headert/firmware rebuildet használj paraméterkezelésnek.
Őrizd meg a felhasználó meglévő módosításait. Először a
csomag tesztjeivel és saját HC mockokkal dolgozz; a roverre írás/reset csak külön
kezelői jóváhagyás és előfeltétel-ellenőrzés után történhet. Nem feladatod
rover-gate-eket kikapcsolni, hardveres minősítést kitalálni vagy a régi API-ra
visszaesni. A végén add meg a módosított fájlokat, futtatott teszteket és a
nyitott hardveres előfeltételeket.

## Mit kell elolvasni?

1. A ZIP gyökerében levő teljes `ROVER_SYSTEM_SPEC_v3.1.0.md`, különösen
   4, 5, 10, 12–14 és 17. Ez a baseline specifikáció; 4.2-jét az új
   `docs/HC_PARAMETER_MANAGEMENT.md` követelmény felülírja.
2. `docs/HC_V31_INTEGRATION_HANDOFF.md`: jelenlegi HTTP/HC-integráció és a
   VG/QSPI eltérések. A baseline 17. fejezetének belső A/B-kiosztása nem azonos
   a tényleges 1-MiB VG hardver alternatív QSPI-kiosztásával.
3. `docs/QSPI_UPDATE_RUNTIME.md`, `docs/NATIVE_ESP_RESTART.md` és
   `docs/QSPI_PROVISIONING.md`: helyreállítás, normál újraindítás és telepítés.
4. `tools/rover_hc_update.py` és tesztjei: működő, explicit STM referenciafolyam.
   A referencia nem kész HC alkalmazás és nem teljes ESP-OTA kezelőfelület.
5. `shared/rover_protocol.h` és `shared/rover_mission_validator.h`: pontos
   küldetés-, azonosító- és protokollformátumok. Ne használj történeti v2 dokumentumot.

A ZIP megőrzi a relatív könyvtárakat. `MANIFEST.json` tartalmazza a fájlméreteket
és SHA-256 értékeket; ez sérülésellenőrzés, nem kiadói aláírás. Python 3.10+;
a tényleges ELF-ellenőrzéshez `pyelftools` szükséges. ESP képellenőrzéshez ezen
felül a rover dokumentációjában rögzített esptool 5.1.0 kell.

```sh
python3 tests/test_rover_hc_update.py
python3 tests/test_rover_qspi_image.py
python3 tests/test_rover_image.py
python3 tests/test_rover_profile.py
python3 tests/test_rover_parameters.py
```

A tesztadatok kizárólag szintetikusak; nem telepíthető profilok vagy firmware-ek.

## Jelenlegi roverállapot

A rover szoftverében bekötött a hitelesített HTTP-feltöltés, tartós NVS session,
RFU2-képkezelés, natív STM adapter, TRIAL/CONFIRM/EXIT-egyeztetés és ESP-OTA
együttműködés. Az alapértelmezett telepítési headerek szándékosan üresek;
a valós mérési konfiguráció és a boardtelepítés/hardverminősítés nincs kész.
Fordítás és host teszt nem fizikai elfogadás. `conformant=false` nem írható át.
Az engedélyezést a futó rover hitelesített identity-válasza határozza meg, nem
ez az átadó, egy korábbi QSPI bench vagy a HC-be hardcoded capability.

## Kötelező HC frissítési döntések

| Futó identity | STM képfeltöltés |
| --- | --- |
| `stm_remote_update=false` vagy ismeretlen ABI/layout | Tiltott; ne küldj mutációt |
| ABI 1 + `H743_2M_AB1` | Valódi RFU1 A/B pár, a friss loader szerinti inaktív slot |
| ABI 2 + `H743_1M_QSPI2` | RFU2 APP; image-header layout `H743_1M_QSPI_REC2`, slot `APP` |

VG esetén az identity `stm_image_max_bytes` pontosan 524288, `profile_crc`
nem nulla, nyolc nagybetűs hex karakter. Az image 1280..524288 byte,
32-byte-os igazítású, 0x08100000-ra linkelt RFU2/RTE2. A release hash és firmware
token jóváhagyott kiadásból származzon, ne önmagában a kiválasztott fájlból.
A referencia az ELF-et is ellenőrzi; ezt backend build/release-ellenőrzésben
őrizd meg. Loader, RFI2, QSPI seed, ESP bootloader vagy partíciós tábla nem
küldhető alkalmazás-OTA-nak.

Minden HTTP-kérés backend Bearer-hitelesítésű. A token 64 hex karakter, nincs
böngészőben/URL-ben/logban; redirectet ne kövess hitelesítő adattal. A csomag
nem tartalmaz titkokat. A tényleges LAN origin és token külön megadandó.

Explicit kezelői indítás: `POST /api/v3/update`, pontos JSON:

```json
{"v":3,"request_id":"hc-update-42","esp_boot":"0123456789ABCDEF","target":"STM"}
```

Az ESP boot példaérték helyére mindig a friss identity nem nulla, 16 nagybetűs
hex azonosítója kerül. A target `STM` vagy `ESP`; párhuzamos frissítés nincs.
202 csak befogadás. Tartósan őrizd a kapott 32 nagybetűs hex update ID-t,
pollolj 2 Hz-en: `GET /api/v3/update/{id}`.

VG image előtt ugyanaz a job/ESP boot, `locked=true`, `target=STM`, `phase=READY`,
`error=NONE`, `source=STM_LOADER`, `source_valid=true`, egész `source_age_ms`
0..2000, `can_active=false`, `outputs_inhibited=true` szükséges. A VG három
slotmezője (`confirmed_slot`, `inactive_slot`, `candidate_slot`) explicit null;
nem `NONE`, nem A/B, és a hiányzó mező nem elfogadható null helyett.

Raw `POST /api/v3/update/{id}/image`; pontos `Content-Length`,
`Content-Type: application/octet-stream`, `X-Image-SHA256` 64 kisbetűs hex,
`X-Firmware-ID`, `X-Profile-CRC32` 8 nagybetűs hex, `X-Contract: 3.1.0`,
`X-Flash-Layout: H743_1M_QSPI_REC2`, `X-Image-Slot: APP`. Nem multipart,
chunked, base64, MQTT vagy nyers UART. ESP célhoz standard auditált ESP32-S3
app bináris, `ESP_IDF_OTA` / `INACTIVE`, a tényleges inactive kapacitáson belül;
RFU2 parser nem használható ESP képre.

Külön mutasd RECEIVING/ERASING/WRITING/VERIFYING/TRIAL/COMPLETE állapotokat;
100% byte és APP CONFIRM ACK nem tartós siker. VG-n a friss, egyeztetett loader
committed COMPLETE eredménye számít. Nincs ACTIVATE hívás. Elveszett válasz:
UNKNOWN, csak GET-egyeztetés; ne próbáld automatikusan újraküldeni a mutációt.
ESP reboot után az STM TRIAL eredeti határidejét nem lehet újraindítani.

ABORT és FINISH külön, explicit kezelői művelet, üres POST testtel. ABORT nem
oldja a lockot és már committed képet nem von vissza. FINISH csak friss, azonos
jobhoz tartozó `can_finish=true` és terminal állapot után. VG `can_retry=false`
szándékos: lock alatt ne hozz létre pótló sessiont. FINISH 202/EXIT ACK nem
normál üzem: várd meg az unlocked IDLE és az új kompatibilis STM boot/epoch,
EMPTY mission, nulla target bizonyítékot. Fizikai bemenet miatti FAULT lehet
eredmény; nem ARM engedély. Régi mission/lease/command/sensor objektumok törlendők.

Fontos eltérés: VG maintenance UART-ownership alatt ordinary STOP **503 / NOT_READY**,
mert ABI2 STOP opcode nincs. Ne mutasd APPLIED-nak, ne helyettesítsd ABORT-tal
vagy ABI1/raw UART-tal. A kötelező hardveres inhibit marad a biztonsági alap.
Ez a baseline-tól való eltérés nyíltan jelenjen meg, nem teljes megfelelőség.

## Normál üzem HC oldala

Csak `/api/v3` és a provisioned MQTT base `/v3` interfész használható; régi
drive/route/update/ROM-loader/ArduinoOTA fallback nincs. STM STATE, boot,
control_epoch, profil és eredeti source age az authoritative adat. Null/stale
nem jelent megállást, DISARMED állapotot vagy sikert. MQTT parancsok QoS0,
non-retained, clean-session, reconnect után nincs replay. Elveszett ACK-nál
UNKNOWN és állapotegyeztetés, nem automatikus új mozgásparancs.

Kézi vezérlés: hitelesített backend WS-relé `/api/v3/manual`, subprotocol
`homecontrol.mower.manual.v3`. Egy aktív kezelő, explicit lease/deadman,
10 Hz teljes setpoint, szigorúan növekvő sequence, latest-only friss frame.
Deadman elengedés teljes nulla setpoint/deadman=false; ne szintetizálj heartbeatet
vagy replayt. A server/STM lease-eredmény a döntő, nem optimista böngészőállapot.

Küldetés: specifikáció szerinti RVM3, profil/CRC és teljes geometriai ellenőrzés,
legfeljebb 131072 byte / 4096 szegmens. Raw HTTP a dokumentált mission headerekkel.
STM READY után külön explicit ARM/START. Firmware update/reboot nem folytat
küldetést, kézi vezérlést vagy heading/calibration sessiont automatikusan.

## Átvételi tesztek a HC gépen

Mockold ABI1/ABI2/disabled/ellentmondásos identityt; helyes és hibás képeket;
hiányzó/null/stale mezőket; source/boot/epoch váltást; elveszett create/image/
abort/finish választ; auth hibát; 423/501/503 gate-eket; TRIAL rollbacket;
explicit FINISH normál/FAULT eredményt; token-redactiont; reconnect replay-tiltást;
WS deadman/lease lejáratot és mission CRC hibákat. Mutációs retry és automatikus
FINISH/ARM/START nem fogadható el. Hardveres T37–T52-t mockteszt nem teljesít.
