# Rover System Specification — v3.1.0

**Status:** normative implementation target; not a declaration that existing firmware conforms.  
**Date:** 2026-09-30.  
**Targets:** HomeControl (HC), ESP32-S3 gateway, STM32H743 controller, three VESC-compatible motor controllers.  
**Language:** English. **Operational protocol:** 3.1. **Maintenance service ABI:** 1. **Mission format:** RVM3.  
**Owner's objective:** a simple, predictable, maintainable mower/rover with adequate processing headroom and no competing control paths.

**Revision change:** v3.1.0 supersedes the initial v3.0.0 reform draft and restores mandatory remote STM application updating. §17 now defines exclusive HC–ESP–STM maintenance, the protected recovery loader, A/B images, exact transfer messages, interruption recovery and return to service. Related roles, state rules, identity, HTTP/UART interfaces, scheduling, migration and acceptance tests are updated together. The `/api/v3` and MQTT `/v3` namespaces remain; operational HELLO minor becomes 1.

This document supersedes ROVER–HC Contract v2.0.0 and the behavior of the supplied September 25 firmware wherever they conflict. The ESP source's advertised 2.4.0 contract does not establish compatibility with this specification. HC, ESP and STM MUST migrate together. No compatibility shim may turn old movement commands into v3 commands.

The words **MUST**, **MUST NOT**, **SHOULD** and **MAY** describe requirements, recommendations and permitted choices. All limits without an explicit configuration exception are mandatory. Physical measurements listed in §4 are commissioning inputs, not values an implementer may guess. Passing §22 is required before claiming conformance.

## Contents

1. [Scope and simplification decisions](#1-scope-and-simplification-decisions)
2. [Ownership and architecture](#2-ownership-and-architecture)
3. [Global invariants](#3-global-invariants)
4. [Hardware and commissioning profile](#4-hardware-and-commissioning-profile)
5. [Units, clocks and identities](#5-units-clocks-and-identities)
6. [STM state machine](#6-stm-state-machine)
7. [Stop, pause and fault policy](#7-stop-pause-and-fault-policy)
8. [GNSS and IMU acquisition](#8-gnss-and-imu-acquisition)
9. [Navigation and blade execution](#9-navigation-and-blade-execution)
10. [RVM3 mission format and validation](#10-rvm3-mission-format-and-validation)
11. [ESP–STM UART protocol](#11-espstm-uart-protocol)
12. [HC–ESP MQTT interface](#12-hcesp-mqtt-interface)
13. [Manual WebSocket interface](#13-manual-websocket-interface)
14. [HTTP upload and maintenance interface](#14-http-upload-and-maintenance-interface)
15. [STM–VESC CAN interface](#15-stmvesc-can-interface)
16. [Scheduling, budgets and backpressure](#16-scheduling-budgets-and-backpressure)
17. [Persistence, restart and firmware update](#17-persistence-restart-and-firmware-update)
18. [Telemetry and diagnostics](#18-telemetry-and-diagnostics)
19. [Implementation modules](#19-implementation-modules)
20. [Migration and defect traceability](#20-migration-and-defect-traceability)
21. [Implementation order](#21-implementation-order)
22. [Acceptance tests](#22-acceptance-tests)
23. [Reference algorithms and vectors](#23-reference-algorithms-and-vectors)
24. [Evidence and reference documents](#24-evidence-and-reference-documents)

## 1. Scope and simplification decisions

### 1.1 Required baseline

The baseline supports manual driving; manual blade operation under a live operator lease; upload and execution of straight mission segments; stationary alignment before each segment; start, pause, resume, stop and completion; local geofence supervision; GNSS/IMU acquisition; NTRIP; MQTT status/commands; one manual WebSocket; authenticated remote ESP and STM application firmware updates in exclusive maintenance; local ST-LINK installation/recovery of the protected STM loader; and bounded diagnostics.

An autonomous mission can continue without HC/MQTT connectivity **only while its local operating conditions remain valid**. Loss of Wi-Fi may subsequently remove NTRIP corrections; the resulting GNSS quality change is evaluated by STM independently.

### 1.2 Removed from the v3.1 runtime

| Removed item | Replacement / reason |
|---|---|
| ESP route executor and ESP mission executor | Only STM executes motion. |
| Legacy AUTO demo, AUTO ADD/PLAY, route-record/play HTTP APIs | HC generates RVM3; one executor handles every autonomous path. |
| Independent ESP and STM mission RUNNING/PAUSED decisions | STM state is authoritative; ESP holds a read-only cache. |
| Separate prepare/preview/validate/activate/start state chains on both MCUs | One bounded upload transaction; STM END validates and makes a mission READY. START is separate. |
| HCM1 operation interpreter and obligatory BLADE_ON/OFF instructions | RVM3 explicitly states speed and blade speed for each segment. A blade-free mission is valid. |
| Automatic travel up to 10 m to reach the mission start | Operator positions the robot within the defined start radius. No hidden approach planner. |
| Legacy heading target/assist/auto-north driving engines | One heading calibration operation; one navigation controller. |
| Global link timeout that treats browser, MQTT and sensor links alike | Manual lease, sensor freshness and peer liveness have distinct meanings. |
| START clearing faults or disabling watchdog configuration | START has no safety configuration side effects. |
| START ACK followed by a second success/failure confirmation routine | One correlated STM result; subsequent telemetry describes progress. |
| Debug text mixed with machine UART replies | Framed protocol only; debug logs go to a separate local interface. |
| Unlimited motor-command replay | Every internal motion intent has a local expiry. |
| Periodic ESP RC STOP based on a historical client timestamp | Manual lease expiry is enforced in STM and only affects that lease. |
| Three independent fault_clear / clear_estop / safety_reset actions | One RESET_FAULT with explicit preconditions; then ARM. |
| Generic remote UART/CAN/raw-current/raw-duty commands | Not available in an operational build. Bench tools use a separate build. |
| Legacy STM FWUP, runtime ROM-loader fallback and bank-copy activation | Required HC–ESP–STM remote updater with a protected recovery loader and A/B app slots (§17). The feature is retained; the unsafe/competing mechanisms are replaced. |
| SD/FatFs mission storage, automatic mission recovery after reboot | Mission remains in STM RAM; HC re-uploads after STM reboot. |
| Runtime configuration changes while moving | Hardware profile is installed during maintenance and checked by checksum. |

Remote STM application updating and ESP OTA are mandatory. Both use the same exclusive update policy in §17; remote bootloader, option-byte and VESC firmware changes are excluded. Automatic docking, charging control, sleep scheduling, obstacle bypass planning, dead reckoning through GNSS loss, multiple simultaneous operators, and a coverage planner on either MCU are also outside v3.1.

## 2. Ownership and architecture

| Owner | MUST do | MUST NOT do |
|---|---|---|
| HC | Store garden geometry; generate and preview segments; retain mission files, firmware packages and logs; show authoritative state; send explicit operator/update requests and the correct slot-specific image. | Generate periodic motor setpoints for AUTO; infer successful execution from an ESP receipt; replay movement after reconnect. |
| ESP | Read GNSS and IMU; preserve measurement identity/age; manage Wi-Fi/AP, NTRIP, HTTP, WS and MQTT; validate network syntax and bounds; bridge correlated commands; expose STM state; coordinate the exclusive update session, perform ESP OTA and stream the verified STM image to its recovery loader. | Compute a competing route, decide mission progress, change STM faults, invent heading offsets, or synthesize RUNNING. |
| STM | Own robot state, leases, mission storage/validation/execution, heading reference, geometry conversion, navigation, physical input handling, actuator permission, CAN scheduling and stop policy; revoke/discard runtime work before maintenance. Its protected loader owns STM flash/boot decisions (§17). | Wait for a network service; let a debug command bypass actuator permission; accept expired sensor data as fresh. |
| VESC 1 / 2 / 3 | Close local motor loops; enforce configured electrical/thermal limits and local command timeout. | Depend on the ESP browser connection for its only timeout; run another input application that competes with STM. |

ESP owns sensor **acquisition validity**. STM owns **whether that measurement permits autonomous movement**. These are different responsibilities. HC may preflight a mission for usability; STM alone decides whether to accept it for execution.

In ordinary application operation there is exactly one STM output arbiter. The recovery loader has a separate stop-only preparation worker, active only while the application is not executing; it can never request propulsion/blade RPM. After update quiescence even that CAN worker is stopped (§17.3).

There is exactly one STM output arbiter. Navigation and manual inputs submit intent to it. No other module writes CAN motor commands directly. VESC configuration tools MUST NOT be used concurrently with an armed rover.

## 3. Global invariants

**INV-01:** Only state MANUAL or AUTO can authorize nonzero motion. A stopped state may send the defined braking command, never an old RPM target.

**INV-02:** Every transition out of MANUAL/AUTO atomically invalidates previous intents before acknowledging the transition. Entering a mode never restores a previous nonzero command.

**INV-03:** STOP is independent of ownership and does not wait behind upload, diagnostics, normal command queues or network requests. It cannot override FAULT to a ready state.

**INV-04:** Source measurement freshness, UART peer liveness, operator lease and MCU scheduler health are independent. A heartbeat cannot renew any measurement or manual setpoint.

**INV-05:** ACK means an internal state transition or request result has committed. It does not mean the vehicle or blade has physically stopped. Measured speeds and `stopped` provide that evidence.

**INV-06:** A transient operational interruption becomes PAUSED or ends a manual lease. It is not automatically a latched equipment fault. Latched faults are enumerated in §7; implementers MUST NOT add new latches merely to work around parser/timing defects.

**INV-07:** Recovery of a link, sensor or fault condition never automatically resumes nonzero motion. An explicit new claim/START/RESUME is needed. This is one recovery rule shared by all transports.

**INV-08:** A START is valid only from IDLE and cannot restart a running mission. Retries are deduplicated; they do not execute START twice.

**INV-09:** No blocking UART response loop, CAN TX wait loop, HTTP upload or flash operation may run in a motion/sensor scheduling task.

**INV-10:** All accepted mission fields affect execution as defined. Unsupported semantics are rejected; ignored speeds, turn records and blade settings are forbidden.

**INV-11:** A corrupt, incomplete or overlength frame is never treated as a shorter valid frame. No partial status publication is allowed.

**INV-12:** Operational safety conditions have one implementation in STM. ESP checks transport validity, not a separately maintained copy of all STM start conditions. Loader stopping uses the same profile, stop conversions and evidence rules in a shared stop-only module.

**INV-13:** A persistent firmware-update lock prohibits every operational control path. Only the §17 allowlist runs after quiescence; timeout/reboot/rollback never authorizes motion.

**INV-14:** Remote STM writes never touch the protected loader, factory data or confirmed app slot. No unverified/incomplete image can become the boot target.

## 4. Hardware and commissioning profile

### 4.1 Wiring retained from the supplied source

| Interface | Baseline |
|---|---|
| ESP–STM | 115200 baud, 8N1, 3.3 V logic, common ground; ESP RX GPIO17, TX GPIO16; STM USART1. |
| ESP–F9P | ESP RX GPIO21, TX GPIO18. Boot acquisition starts at the installed receiver baud; operational target is 115200, 8N1. |
| ESP–BNO086 | I2C address 0x4B, SDA GPIO8, SCL GPIO9, INT GPIO10, RST GPIO11; 400 kHz target after bus verification. |
| STM–VESC | Classic CAN, 500 kbit/s, extended IDs, no CAN FD/BRS. IDs: left 1, right 2, blade 3. |
| STM CAN pins | Preserve the verified board configuration; the reviewed implementation uses PB8/PB9 diagnostics. Confirm the `.ioc`/MSP mapping before generation; this document does not invent missing MSP pin assignments. |
| STM reset/boot | Verify ESP GPIO13 → STM NRST as open-drain reset for dead-app recovery. Hold BOOT0 at normal-flash boot; GPIO12 must not select ROM mode. Protected loader always starts at reset; §17.9 specifies entry and one-time ST-LINK provisioning. |

STM GPIO definitions, clock tree, DMA streams, VESC firmware versions, motor types and physical safety input pins MUST be recorded in the installation manifest. Only `main.c` and the sketch were supplied; their surrounding board/support files were not audited. Working pin mappings MUST NOT be changed to satisfy an assumed schematic.

### 4.2 One immutable operational profile

Both firmware repositories and HC receive the same `rover_profile.json`. STM is the authority for its installed checksum. ESP exposes the matching profile only when that checksum matches STM. Profile edits require stopped/disarmed maintenance and a controlled installation; no runtime tuning API is provided.

All profile numbers are integers. The canonical checksum is CRC-32/ISO-HDLC of UTF-8 JSON with ASCII-sorted keys at every level, compact separators, no whitespace/newline, no checksum field. Arrays keep their order. The JSON is built from the fields below only; names are case-sensitive. `profile_crc` is carried as eight uppercase hexadecimal digits. It covers both calibration and behavioral limits.

| Field | Type / permitted values | Installation rule |
|---|---|---|
| `profile_version` | integer, 1 | Fixed. |
| `robot_id` | ASCII string `[A-Za-z0-9_-]{1,32}` | Installation identity. |
| `commissioned` | boolean | False until the corresponding motion tests pass. Never changed automatically. |
| `blade_enabled` | boolean | False for initial drive testing; a blade-requesting mission is rejected when false. |
| `wheel_track_mm` | 100..1500 | Measured distance between wheel contact centers. |
| `wheel_circumference_mm` | array of two integers, each 100..2000 | Loaded rolling circumference, left/right. |
| `wheel_motor_pole_pairs` | array of two integers, each 1..100 | Verified motor parameters. |
| `wheel_gear_ratio_milli` | array of two integers, each 1000..1000000 | Motor revolutions per wheel revolution ×1000. |
| `wheel_direction` | array of two integers, each -1 or +1 | Converts positive robot-forward wheel speed to the required signed VESC target. |
| `blade_pole_pairs` | integer 1..100 | Required even with blade disabled; verified before enabling. |
| `blade_direction` | -1 or +1 | Installed cutter direction. |
| `body_radius_mm` | 100..1000 | Conservative radius containing chassis, wheels and blade sweep about control point. |
| `antenna_body_mm` | three signed integers, each -2000..2000 | Antenna offset from wheel midpoint in forward/left/up coordinates. |
| `imu_mount_q_ppm` | four signed integers, norm within 0.1% of 1000000 | Fixed sensor-to-body mounting quaternion, ordered w,x,y,z. |
| `wheel_erpm_limit` | two positive integers <=6000 | Preserve tested driver limits, not an assumed physical vehicle speed. |
| `blade_erpm_limit` | positive integer <=25000 | Motor electrical RPM ceiling. |
| `blade_rpm_limit` | positive mechanical RPM | MUST satisfy `rpm_limit × pole_pairs <= erpm_limit`. |
| `wheel_brake_ma` | two nonnegative integers | Tested braking currents, within saved VESC limits. Zero is allowed only if coast stopping tests meet the declared bound. |
| `stop_deceleration_mm_s2` | positive integer | Conservative measured lower bound on deceleration for normal stop AND VESC timeout on the permitted terrain. |
| `max_slope_mdeg` | 0..15000 | Measured operating envelope; zero restricts operation to a level test area. |
| `max_linear_mm_s` | 50..500 | Initial value 250; reduce if stopping/space limits require it. |
| `max_yaw_mdeg_s` | 5000..45000 | Initial value 30000. |
| `accel_mm_s2` | 50..500 | Initial value 250; ordinary acceleration only. |
| `yaw_accel_mdeg_s2` | 5000..90000 | Initial value 60000. |
| `gnss_hacc_limit_mm` | 20..100 | Initial value 100. Receiver estimate is not a guaranteed position bound. |
| `heading_accuracy_limit_mdeg` | 1000..15000 | Initial value 10000. |
| `tilt_limit_mdeg` | 10000..30000 | Initial value 25000; must exceed permitted slope with mounting margin. |
| `safety_installed_mask` | unsigned integer, bits from §7 | Only physically installed, wired and tested inputs are enabled. |
| `safety_inputs` | object | Exactly `estop`, `lift`, `bumper`; each `{present:boolean,port:string,pin:integer,active_level:0|1}`. Present port is A..K, pin 0..15, verified against board wiring. Absent port is `"NONE"`, pin 0. |
| `vesc_firmware` | three strings, each <=40 ASCII characters | Exact installed versions/build identifiers. |
| `stop_test_max_ms` | positive integer <=2000 | Measured time to wheel stop from the allowed maximum speed, including local timeout. |

Physical values have **no fabricated defaults**. An uncommissioned profile allows telemetry, uploads and maintenance, but no ARM. Commissioning motion uses the separate bench build with the cutter disabled and explicit local control. Bench binaries MUST advertise `conformant=false`; they cannot be mistaken for production v3.

Physical emergency stop MUST be installed and tested for an operational mower. At minimum it must independently remove motor-drive authorization/power and report its state to STM; a remote MQTT command is not that circuit. Lift/bumper inputs may be marked absent, but status must then say unavailable, not healthy. Autonomous mowing with absent hazard-detection hardware is limited by the resulting tested operating envelope; this software specification is not certification of the physical machine.

### 4.3 Fixed software constants

| Constant | Value |
|---|---:|
| STM supervisor/output arbiter period | 10 ms |
| Navigation period | 50 ms |
| CAN motor refresh | 20 ms |
| Local generated intent lifetime | 100 ms |
| Manual received setpoint lifetime | 350 ms |
| Peer heartbeat period / peer loss | 250 ms / 750 ms |
| GNSS sample maximum effective age | 600 ms |
| IMU sample maximum effective age | 250 ms |
| Ready stability before START/RESUME | 1000 ms |
| VESC required STATUS maximum age while active | 500 ms |
| VESC local timeout | 500 ms |
| Start / resume position radius | 250 mm / 200 mm |
| Segment arrival radius | 100 mm |
| Navigation lookahead | 400 mm |
| ALIGN exit / TRACK re-align angle | 10000 / 35000 mdeg |
| Geometry fixed margin | 50 mm |
| Maximum source-to-stop reaction allowance for planning | 800 ms |
| HTTP/MQTT command timeout at HC | 1500 ms |
| UART command retry interval / retries | 250 ms / 2 |
| Upload no-progress timeout / total timeout | 5000 ms / 180000 ms |
| Mission validation deadline | 30000 ms |

These are explicit design choices for this low-speed baseline. Changing them requires a reviewed profile/spec revision and repeating affected tests; another project must not quietly select different values.

## 5. Units, clocks and identities

### 5.1 Units and axes

Network and UART motion commands use `linear_mm_s` and `yaw_mdeg_s`. Positive linear velocity is forward. Positive yaw rate turns clockwise viewed from above. Heading is true-north referenced, 0 north, 90000 east, 180000 south, 270000 west; normalized to [0,360000). Heading error normalizes to [-180000,180000); exact 180 degrees selects -180000 deterministically.

Local mission coordinates are east/north/up (ENU), in millimeters. The robot control point is the wheel-axis midpoint projected on the ground. The right-handed body frame is forward/left/up. Positive roll is right side down; positive pitch is nose up. These reporting signs are explicit and must not be inferred from a library's Euler conventions. GNSS course over ground is never used as stationary body heading.

`blade_rpm` is **mechanical blade/motor-shaft RPM**, with direct drive assumed. If the cutter has gearing, it must be represented by a new profile version; silently reusing direct-drive conversion is forbidden. `erpm` always means electrical motor RPM. No public field named only `rpm` may mean different things on different links.

Lat/lon use signed degrees ×10^7 (`lat_e7`, `lon_e7`); altitude is signed millimeters above the ellipsoid (`height_mm`). All UART numbers are decimal integers except explicitly hexadecimal tokens. No float, NaN, exponent, implicit unit or locale comma is accepted on UART. HTTP/MQTT JSON integer fields reject fractional values, numeric strings and booleans.

### 5.2 Clocks and age

Use local monotonic milliseconds for elapsed times. MCU clocks need not be synchronized. Unsigned 32-bit elapsed-time arithmetic is valid only for intervals below 2^31 ms; implement wrap-safe comparisons. UTC is for logging, not motor permission.

A sensor sample is identified by `(esp_boot, sensor_epoch, sample_seq)`. Repeated samples do not refresh its age. `sample_age_ms` is calculated at UART serialization from the original acquisition timestamp, including time spent waiting in an ESP queue. STM effective age is:

`age_at_send + (stm_now - frame_received_at) + 50 ms`.

The 50 ms transport allowance covers the maximum 512-byte UART frame at 115200/8N1. If measured transport backlog exceeds it, the implementation is nonconformant and must drop old samples/backpressure, not increase freshness by relabeling them.

### 5.3 Sessions and ordering

Each ESP/STM boot obtains a nonzero unpredictable 64-bit `boot_id`, represented by exactly 16 uppercase hex characters. No sensitive identity is encoded. Sensor reset increments `sensor_epoch`; sequence resets require a new epoch. Transport and command counters are unsigned 32-bit; reconnect/reboot binds a new peer session before they can restart.

STM owns `control_epoch` (u32, starts at 1). It increments on entry/exit of MANUAL or AUTO, on PAUSE/RESUME, STOP, DISARM, FAULT, RESET_FAULT and maintenance entry/exit. Increment exactly once per committed transition/event, even if several descriptions apply; an idempotent no-op PAUSE does not increment. Epoch changes invalidate queued non-stop requests and old manual leases. ARM also increments it. A duplicate already-completed request returns its cached result **before** epoch validation, without applying another transition.

## 6. STM state machine

### 6.1 Authoritative states

| State | Meaning | Nonzero motion |
|---|---|---|
| `DISARMED` | Boot/default or explicitly disarmed; mission may be READY. | Forbidden |
| `IDLE` | Armed, stationary, waiting for a fresh command. | Forbidden |
| `MANUAL` | One STM-authorized operator lease; fresh full setpoints required. | Per fresh setpoint |
| `AUTO` | STM executes a READY mission. | Per valid navigation intent |
| `PAUSED` | Mission checkpoint preserved, all propulsion and blade targets stopped. | Forbidden |
| `FAULT` | Enumerated latched equipment/physical safety fault. | Forbidden |
| `MAINTENANCE` | Output permission revoked; service only. Firmware update adds the persistent lock and QUIESCING/transfer/recovery phases in §17; QUIESCING is still proving physical stop. | Forbidden |

`armed` is derived: true in IDLE/MANUAL/AUTO/PAUSED, false otherwise. There is no independently mutable armed flag that can contradict state.

Mission storage has only `EMPTY`, `RECEIVING`, `VALIDATING`, `READY`. Execution outcome is `NONE`, `RUNNING`, `PAUSED`, `COMPLETED`, `STOPPED`, `FAULTED`. These describe different dimensions; neither ESP nor HC creates a second execution machine. A READY mission remains in memory after ordinary STOP or completion and can be explicitly restarted from segment 0. Firmware-update entry deliberately deletes that mission and every checkpoint (§17.3).

### 6.2 Transitions

| Request/event | Allowed origin | Committed result |
|---|---|---|
| ARM | DISARMED | IDLE if profile commissioned, peer/profile compatible, physical stop released, no active fault, wheel drivers fresh and stopped, and IMU tilt data fresh/valid. GNSS is not required. |
| DISARM | Any except MAINTENANCE | Stop outputs, clear lease/checkpoint and any upload; DISARMED unless a fault remains, then FAULT. |
| MANUAL_BEGIN | IDLE | MANUAL only with fresh IMU/wheels and no upload/validation; STM creates a lease, targets initially zero. A fresh full setpoint is needed. |
| MANUAL_END | MANUAL with matching lease | Stop targets, invalidate lease, IDLE. Otherwise reject without affecting AUTO. |
| START | IDLE, mission READY | AUTO at segment 0/ALIGN after §6.3 checks. |
| PAUSE | AUTO | Stop targets; save checkpoint; PAUSED, reason OPERATOR. |
| RESUME | PAUSED | AUTO at saved segment/ALIGN after §6.3; no return to mission start. |
| STOP | Any | Invalidate motion/lease/checkpoint. Moving/paused/idle -> IDLE; DISARMED/FAULT/MAINTENANCE remain their respective state. Outcome STOPPED if a mission was active/paused. |
| Manual lease expiry | MANUAL | Stop, invalidate lease, IDLE; reason MANUAL_EXPIRED, no fault latch. |
| Operational AUTO interruption | AUTO | PAUSED with checkpoint and specific reason. |
| Mission end | AUTO | Stop outputs, IDLE, outcome COMPLETED, index=count. |
| Latched fault | Any operational state | Stop outputs, invalidate lease and any upload, FAULT; active mission outcome FAULTED and checkpoint invalidated. During locked update, keep output inhibit and report physical inputs/update error without starting operational work (§17.3). |
| RESET_FAULT | FAULT | DISARMED only after all underlying causes have cleared for 1000 ms and measured stop is true. No automatic ARM. |
| MAINT_BEGIN | DISARMED, no update lock | Ordinary MAINTENANCE after measured stop. Physical stop may remain asserted. No uploads active. This command does not open a firmware updater. |
| MAINT_END | Ordinary MAINTENANCE, no update lock | DISARMED or FAULT if an underlying physical fault is active; no automatic restart. |
| Update OPEN | Any operational state | MAINTENANCE/QUIESCING immediately revokes output and discards all runtime work; §17 is the authority for stopping, lock and loader handoff. |
| Update FINISH | Terminal locked update | §17.8 only; restart DISARMED/EMPTY or FAULT for an active physical input. MAINT_END cannot substitute for it. |
| MCU reset | Any | Outputs prohibited and mission EMPTY; persistent update lock selects recovery/maintenance, otherwise DISARMED (or active-input FAULT). |

PAUSE repeated in PAUSED is successful and has no additional side effects. STOP remains successful when already stopped; it invalidates queued movement once per new request. Other invalid transitions return `BAD_STATE` and leave state unchanged. New MANUAL_BEGIN while PAUSED is rejected: STOP explicitly discards the checkpoint first.

### 6.3 Autonomous start and resume checks

STM requires: commissioned profile; READY mission matching installed profile; healthy required VESC feedback; released physical safety inputs; GNSS/IMU quality and freshness stable for 1000 ms; valid heading reference for the current sensor epoch; valid runtime geofence; and measured wheel stop. START additionally requires position within 250 mm of the mission start. RESUME requires position within 200 mm of the saved checkpoint. Otherwise return `REPOSITION_REQUIRED`; do not invent an approach route.

If a mission uses the blade, blade driver status and stop must also be healthy. A blade-free mission does not require an absent/disabled cutter controller. Neither START nor RESUME changes feedback requirements, limits, fault bits or link configuration.

### 6.4 Pause checkpoint

Save mission ID/revision/CRC, segment index, fixed segment start/end, last valid control-point position, and the reason. Keep it only in STM RAM. A position-loss pause uses the last valid position, not a newly invalid coordinate. Resume re-aligns to the remaining portion of that same segment; completed segments are not replayed. STOP, mission replacement, FAULT, DISARM, firmware-update entry or STM reboot invalidates the checkpoint. ESP reconnect alone does not delete it.

## 7. Stop, pause and fault policy

### 7.1 Operational interruptions: recoverable without fault clearing

| Condition | MANUAL | AUTO |
|---|---|---|
| HC/MQTT unavailable | Continue only while WS full setpoints remain fresh. | Continue if local inputs remain valid. |
| Operator WS closes/expires | End matching manual lease and stop. | No effect; there is no manual lease in AUTO. |
| ESP–STM peer lost / ESP reboot | End manual lease and stop. | PAUSED `PEER_LOST`; new heading reference may be required after sensor epoch changes. |
| GNSS too old, invalid, FLOAT/non-FIX, or hAcc excessive | No navigation dependency. | PAUSED `GNSS_STALE` or `GNSS_QUALITY`. |
| IMU too old/invalid or heading accuracy unacceptable | Stop if tilt supervision becomes unavailable for >250 ms; IDLE `IMU_STALE`. | PAUSED `IMU_STALE` / `HEADING_QUALITY`. |
| Heading reference invalidated | Manual steering still allowed with valid tilt data. | PAUSED `HEADING_UNREFERENCED`. |
| No path progress / excessive path error | Not applicable. | PAUSED `NO_PROGRESS` / `PATH_ERROR`. |
| Geofence operating-clearance violation | Manual has no autonomous geofence dependency. | PAUSED `GEOFENCE`; outputs stopped immediately. |

The automatic response is stopped PAUSED, not autonomous restart after a grace period. Recovered inputs set `ready_for_resume=true` after 1000 ms; operator RESUME is still required. A single bad packet is discarded; only the loss of usable current data or a new valid report of bad quality changes navigation permission.

### 7.2 Latched faults

| Bit | Name | Trigger |
|---:|---|---|
| 0x00000001 | ESTOP | Active installed physical emergency stop or explicit emergency input. |
| 0x00000002 | LIFT | Installed lift input active. |
| 0x00000004 | BUMPER | Installed bumper active continuously for 30 ms. |
| 0x00000008 | TILT | Valid IMU exceeds profile pitch/roll limit for 100 ms; above limit+10000 mdeg acts immediately. |
| 0x00000010 | CAN_BUS | Bus-off, TX failure preventing refresh for 100 ms, or exhausted required motor TX deadline. |
| 0x00000020 | MOTOR_FEEDBACK | Required moving/commanded motor's STATUS age >500 ms. |
| 0x00000040 | CONTROL_DEADLINE | Motion intent expired while its generating control task was due to produce fresh intent, or supervisor scheduling limit violated (§16). |
| 0x00000080 | INTERNAL | Detected invariant violation, corrupted configuration or unrecoverable internal queue/memory failure affecting control. |

No LINK_TIMEOUT or GNSS fault bit exists. Missing drivers before ARM/START yield a rejected command, not a new fault just for being powered off. Runtime failure of a required active driver does latch. Unknown fault bits are displayed as unknown and always block motion.

Physical ESTOP/lift assertion is handled promptly; filtering is only as specified, not a blanket second-long debounce. GPIO interrupt may latch an assertion, but state changes and telemetry occur in the supervisor. Safety inputs cannot be set through public network commands. Missing inputs have availability bits, never synthesized `false=healthy` values.

For SAFE/HC safety masks, bits 0..2 reuse ESTOP/LIFT/BUMPER above. Bit 3 denotes IMU tilt supervision, always configured in v3; its current availability is reported separately as imu_valid. All other safety mask bits must be zero. `safety_installed_mask` must agree with the three profile input `present` values and include bit 3. Reasserting an already latched condition does not create a new state transition or event on every loop.

### 7.3 Actuator stop procedure

Immediately invalidate every nonzero intent and pending RPM CAN frame. Within the next 10 ms supervisor step, schedule the wheel braking-current command specified by the profile and cutter zero-current command. Repeat stopped output commands at 50 Hz for 1000 ms; remain stopped afterward. Idle brake/hold behavior is the measured profile behavior; software must not claim that zero current actively brakes.

Wheel physical stop is both measured wheel velocities <=20 mm/s continuously for 300 ms, from fresh STATUS packets. Blade physical stop is measured mechanical speed <=100 RPM for 1000 ms. `stopped` means both required wheel and blade stop conditions are known true; missing feedback makes it unknown/false. Ordinary maintenance requires this measured stop. Exclusive updating uses the same evidence, or the explicitly commissioned independent power-inhibit alternative in §17.9. During update QUIESCING the output gate is already closed but physical stop is not yet asserted as proven.

CAN delivery failure is not a successful physical stop. Each VESC must independently time out within 500 ms of loss of fresh setpoints, with the tested timeout brake setting. Hardware ESTOP remains effective when the STM or CAN bus fails. Brake currents and actual stopping distance are commissioning evidence, not software assumptions.

### 7.4 Deterministic reason selection

If events coincide, report the first occurrence at the highest priority: physical ESTOP/lift/tilt/bumper; CAN/motor/internal/control fault; operator STOP/DISARM; peer loss; IMU; GNSS; geofence/path; operator PAUSE; completion. Preserve `last_stop_reason` and its event sequence until the next intentional transition; debug output cannot replace it. The full active fault mask remains available even when one primary reason is shown.

## 8. GNSS and IMU acquisition

### 8.1 GNSS

Use a checksum-valid UBX-NAV-PVT epoch as the canonical navigation sample, configured at 5 Hz. Parse one coherent epoch: iTOW, fixType, gnssFixOK, carrSoln, lat/lon, ellipsoid height, hAcc, ground speed, course and satellite count. The receiver's installed firmware/protocol version must be logged and its message layout verified against its u-blox interface manual. Do not combine coordinates from RMC with stale quality from GGA.

Operational GNSS validity requires fixType=3, gnssFixOK=1, carrSoln=2 (RTK fixed), hAcc <= configured limit, valid coordinate ranges and effective age <=600 ms. Satellite count and HDOP are displayed if available but introduce no additional hidden start gates. RTK FLOAT is displayed and causes an AUTO pause; there is no untested FLOAT driving mode.

New iTOW is required to advance sample identity. Duplicate epochs are ignored for freshness. Account for GPS-week rollover. A receiver restart or backward discontinuity other than valid rollover creates a new sensor epoch and invalidates the old sample. An epoch first received after a blocked acquisition backlog must not be stamped as newly measured; the I/O task must stay within §16, discard stale backlog, and re-establish epoch progression.

For this baseline, acquisition timestamp means completion of a new checksum-valid source report in the continuously serviced sensor task. IMU source timestamps are mapped to that local monotonic time; GNSS iTOW verifies epoch progression. If GNSS service is interrupted for >50 ms, invalidate the sample, discard queued input through a clean frame boundary, and require two increasing 5 Hz epochs received at least 100 ms apart before declaring acquisition valid again. Do not clock-synchronize ESP and STM or stamp buffered reports at the time a network handler happens to return. Receiver processing latency remains part of the measured reaction envelope.

NMEA GGA at 1 Hz may be retained solely for NTRIP caster reporting. NTRIP RTCM age is diagnostic, not a second mission latch based on a sometimes-missing GGA field. No `correction_age=-1` can independently prevent an otherwise valid canonical fixed solution. On actual correction loss the receiver's FIX/accuracy status and data freshness determine continuation.

NTRIP runs in the network task with nonblocking connection/read states, maximum 1500 ms connection attempt, retries at 2/4/8/16/30 s capped at 30 s. A socket wait may block only its dedicated low-priority network context, never sensor acquisition/UART/STOP processing. RTCM packets use a bounded 4096-byte queue; on overflow discard an entire oldest packet, increment a counter, and reconnect if integrity cannot be preserved. Never send arbitrary truncated correction packets as if complete.

### 8.2 IMU and heading

Acquire BNO086 rotation-vector reports at 50 Hz; publish the newest available body orientation to STM at 20 Hz. Keep original sensor timestamps. ESP applies the fixed mounting quaternion once, converts to canonical body yaw/pitch/roll, and reports the sensor heading-accuracy estimate in mdeg. STM MUST NOT apply the mounting transform again.

Yaw is clockwise body orientation relative to the sensor's current reference. STM computes true heading as `wrap360(body_yaw + heading_offset)`. Exactly one offset exists, owned by STM. There is no second ESP north-zero and no automatic driving-based north calibration.

`HEADING_SET,true_heading_mdeg` is allowed only in DISARMED or IDLE while measured wheel stop is true and IMU is fresh. It sets `heading_offset=wrap360(requested_heading-body_yaw)` for the current `(esp_boot,imu_epoch)`. Operator must align the rover with a known garden bearing/true direction. Calibration is not implicit on ARM/START. A sensor or ESP restart invalidates this volatile reference; STM pause and explicit recalibration are required before AUTO resumes.

Yaw orientation conversion must pass north/east/south/west and clockwise-turn tests before commissioning. No implementer may fix a yaw sign error by changing an unrelated wheel-direction sign. GNSS antenna lever arm and quaternion mounting must be validated with the blade motor both stopped and running without a blade during commissioning.

Sensor errors, invalid quaternion norm or explicit accuracy invalidity produce an invalid sample, never zero heading. A failed read does not reset sample age. Missing IMU prohibits ARM because tilt supervision is then unavailable; missing GNSS prohibits AUTO only. IMU recovery is bounded and does not block ESP network/UART service.

## 9. Navigation and blade execution

### 9.1 Coordinate conversion

HC creates an ENU frame using mission origin WGS84 latitude/longitude/ellipsoid height. STM uses the same WGS84 ECEF-to-ENU equations in §23. Convert each new GNSS epoch once, not on every 10 ms supervisor tick. The maximum distance from origin is 1000 m. Subtract the antenna offset rotated by current body orientation to obtain wheel-midpoint position. If current IMU is unavailable, do not produce a new valid control-point position.

### 9.2 Minimal segment executor

Only two moving phases exist: `ALIGN` and `TRACK`; stopped phase is `NONE`. Each record describes a straight segment from the preceding endpoint (or mission start) to the record endpoint. The executor reads records directly from the accepted mission buffer. No separate limited-size copy of all route points is built.

At every segment boundary, stop translation and blade target, then ALIGN. This deliberately favors simple, reproducible motion over fast continuous cornering. Alignment targets the endpoint from current position. Once absolute error <=10000 mdeg for 200 ms, enter TRACK. During ALIGN the blade target is always zero. A zero-length segment is invalid.

Alignment yaw command in rad/s is `clamp(1.5 * heading_error_rad, -omega_max, +omega_max)`, with zero linear command. There is no minimum-forward-wheel-speed clamp. Opposite wheel velocities are explicitly allowed. If alignment does not achieve the exit condition within 15 s, PAUSE `NO_PROGRESS`.

TRACK uses a pure-pursuit target on the **current segment only**. Project current position onto the segment; advance the projected distance by 400 mm, clamped to the endpoint. Let target distance be d and clockwise target-heading error alpha. Curvature is `2*sin(alpha)/max(d,0.10 m)`. Cap forward speed by `omega_max/abs(curvature)` when curvature is nonzero, then compute yaw rate as `linear_velocity * curvature`; do not independently clip yaw and silently change the requested curvature. If abs(alpha)>35000 mdeg, stop translation/blade and return to ALIGN; do not repeatedly alternate at a single threshold.

Requested forward speed is the record's exact `speed_mm_s`, reduced by profile limits, curvature and approach deceleration. Approach speed ceiling is `sqrt(2*a*max(distance_to_end-0.10 m,0))`, using `a=min(accel,stop_deceleration)` in m/s². Within arrival radius, output stop while awaiting a second distinct valid GNSS epoch inside that radius; then advance the segment. Do not count repeated copies of one GNSS sample as two arrivals. Reverse AUTO segments are unsupported and rejected.

Common scaling of left and right target speeds enforces wheel eRPM limits while preserving curvature. Saturation is reported. Ordinary slew limits apply to acceleration; a required safety stop bypasses those normal acceleration ramps and uses §7.3.

### 9.3 Kinematics

With wheel separation b, clockwise omega and linear velocity v, both in SI internally:

`v_left = v + omega*b/2`  
`v_right = v - omega*b/2`

For wheel i:

`erpm_i = direction_i * v_i/circumference_i * 60 * gear_ratio_i * pole_pairs_i`.

Apply rounding once to signed integer eRPM. Telemetry reverses this exact mapping to report forward-positive wheel mm/s. Manual requests use these same kinematics; no separate RC mixing convention exists. For blade: `erpm = blade_direction * blade_rpm * blade_pole_pairs`.

### 9.4 Blade semantics

Each segment specifies blade_rpm, including zero for transit. Nonzero blade target is allowed only in AUTO/TRACK or MANUAL with a current held-deadman setpoint. Requested speed is honored; there is no 6000 fallback. Segment changes, ALIGN, PAUSE, STOP, fault, lost lease or reset command blade stop. Target zero does not prove the blade has finished coasting; telemetry must distinguish target and measured speed.

When a TRACK segment requests blade RPM, hold translation until fresh blade feedback reaches 80% of the requested speed for 300 ms. If not achieved within 5 s, PAUSE `BLADE_NOT_READY`. A blade-free segment skips this wait. Blade changes apply only after stopping at a segment boundary. A manual operator may request blade RPM only when the profile enables it and the cutter driver is healthy; every full WS setpoint must renew it explicitly.

### 9.5 Geofence and progress

Mission polygons describe physical allowed garden area and excluded obstacles. The complete body/sweep envelope, not just the antenna, must remain inside. HC plans with the same conservative clearance used by STM validation:

`C = body_radius + 2*gnss_hacc_limit + 50 mm + vmax*0.8 s + vmax²/(2*stop_deceleration)`.

Here vmax is the highest mission record speed. This is a low-speed design envelope, conditional on the measured stopping bound and terrain. It is not a mathematical guarantee about unbounded GNSS errors. HC must show when a garden/obstacle corridor is too narrow for the commissioned envelope; it must not silently shrink C.

STM validation requires each complete planned segment and the start point to stay at least C from boundary/exclusion edges, inside the outer polygon and outside exclusions. Use exact segment intersections and segment-to-edge distance, not point sampling every 0.5 m. Treat polygon edges as outside when required clearance is not satisfied. Polygon self-intersections, touching holes and overlapping holes are invalid.

Runtime at 20 Hz checks current control-point clearance against `body_radius + 2*current_hacc + 50 mm + current_speed*0.8 s + current_speed²/(2*stop_deceleration)`; use max(abs(commanded speed), measured wheel-center speed). Violation immediately pauses with GEOFENCE; no indefinite hysteresis that permits continued boundary crossing. A single corrupt GNSS frame does not become a position input (§8). Repeated false pauses require fixing positioning/geometry or reducing planned speed, not disabling the geofence.

If cross-track distance exceeds 400 mm for 500 ms, PAUSE PATH_ERROR. If TRACK requests >=50 mm/s but progress toward segment end is <50 mm over 10 s, PAUSE NO_PROGRESS. ALIGN/blade spin-up/intentional stops do not count against TRACK progress. These are recoverable pauses, not fault latches. There is no automatic obstacle bypass or automatic route replanning.

## 10. RVM3 mission format and validation

### 10.1 Binary layout

All integers are little-endian. Signed integers are two's complement. There is no alignment padding except the explicit reserved bytes. Maximum file size is **131072 bytes**, maximum segments **4096**, maximum outer vertices **256**, maximum exclusions **16**, maximum vertices per exclusion **128**, maximum total polygon vertices **2048**. These limits apply to HC generation, upload and STM execution identically.

Fixed header: **96 bytes**.

| Offset | Size | Field |
|---:|---:|---|
| 0 | 4 | ASCII `RVM3` |
| 4 | 2 | major=3 |
| 6 | 2 | minor=0 |
| 8 | 4 | total_bytes |
| 12 | 4 | file_crc32; checksum of whole file with bytes 12..15 treated as zero |
| 16 | 16 | UUID bytes, RFC 4122 network/display byte order; all-zero forbidden |
| 32 | 4 | revision, 1..4294967295 |
| 36 | 4 | origin_lat_e7, signed |
| 40 | 4 | origin_lon_e7, signed |
| 44 | 4 | origin_height_mm, signed |
| 48 | 4 | start_east_mm, signed |
| 52 | 4 | start_north_mm, signed |
| 56 | 2 | outer_vertex_count, 3..256 |
| 58 | 2 | exclusion_count, 0..16 |
| 60 | 4 | segment_count, 1..4096 |
| 64 | 4 | profile_crc32 |
| 68 | 28 | reserved, all zero |

Header is followed by outer vertices `(east_mm:i32,north_mm:i32)`, then exclusions. Each exclusion starts with `vertex_count:u16,reserved:u16=0`, followed by its vertices. Outer ring must be counterclockwise in east/north coordinates; exclusions clockwise. Do not repeat the first vertex at the end. Polygon coordinates, start and mission endpoints must lie within +/-1000000 mm per axis and within 1000000 mm radial distance of origin. Degenerate edges/zero area are invalid.

The final part is exactly segment_count × **16-byte records**:

| Record offset | Size | Field |
|---:|---:|---|
| 0 | 4 | endpoint_east_mm, signed |
| 4 | 4 | endpoint_north_mm, signed |
| 8 | 2 | speed_mm_s, 50..profile max |
| 10 | 2 | blade_rpm, 0..profile limit |
| 12 | 2 | flags, must be 0 in v3.1 |
| 14 | 2 | reserved, must be 0 |

Each segment length must be >=300 mm. No operations follow the records; there is no STOP record, implicit BLADE_ON, TURN record, lane/cell metadata or embedded script. End-of-file means completion after the final endpoint. HC keeps coverage/lane metadata outside the execution file, keyed by mission UUID/revision/record index.

### 10.2 Single upload transaction

Upload is allowed in DISARMED or IDLE, never AUTO/MANUAL/PAUSED/FAULT/MAINTENANCE. BEGIN immediately invalidates the old mission and reports RECEIVING; there is one 128 KiB bank, not simultaneous old/new active images. HC retains the previous file for explicit re-upload if needed.

BEGIN declares total bytes and expected CRC from the header. DATA contains 1..128 bytes at an explicit offset. Only next expected offset or an exact retry of an acknowledged identical chunk is accepted. Conflicting duplicate data aborts the transaction. END is accepted only after all bytes arrive. It checks CRC, header, exact table lengths, enums/limits, profile compatibility, polygons and segment geometry incrementally. During this process store=VALIDATING and movement requests return BUSY. Success commits READY; failure clears executable validity and sets EMPTY with the exact validation reason.

There is no separate ACTIVATE or repeated VALIDATE command. START can never observe a partially accepted mission. ABORT only cancels RECEIVING/VALIDATING; it never means an autonomous STOP. Upload lease expires after 5 s without acknowledged progress; total deadline is 180 s. Validation has a separate 30 s deadline and yields to the supervisor throughout.

### 10.3 Validation ownership and codes

ESP checks body length, bounded buffering, content type and CRC as a transport check. It does not reproduce polygon/path/safety semantic validation. STM validates the complete executable file. HC may validate before submission but must report STM's final result.

Validation codes: `BAD_MAGIC`, `BAD_VERSION`, `BAD_LENGTH`, `BAD_CRC`, `BAD_UUID`, `BAD_REVISION`, `BAD_RESERVED`, `LIMIT_EXCEEDED`, `PROFILE_MISMATCH`, `BAD_ORIGIN`, `BAD_POLYGON`, `BAD_SEGMENT`, `BAD_SPEED`, `BAD_BLADE`, `PATH_OUTSIDE`, `VALIDATION_TIMEOUT`. Error detail is the zero-based offending record/vertex index where meaningful, otherwise 0. No unsupported record may be silently skipped.

## 11. ESP–STM UART protocol

### 11.1 Framing

Use one printable ASCII, CRC-protected line protocol. It is deliberately bounded and implementable with fixed buffers and a small parser; JSON parsing is not required on STM.

```text
R3|SRC_BOOT|DST_BOOT|TX_SEQ|KIND|BODY|CRC32\n
```

`SRC_BOOT` and `DST_BOOT` are 16 uppercase hexadecimal characters. `0000000000000000` is a broadcast/unbound destination permitted only for HELLO, service U_HELLO and STOP. `TX_SEQ` is a nonzero decimal u32, incremented for each new outgoing frame. `KIND` and body enum tokens contain only `[A-Z0-9_]`. Body fields are comma-separated. A field cannot contain a comma, pipe, CR, LF or space. Optional unknown **telemetry** numbers are represented by `~`; requests do not use it. UUID tokens are exactly 32 uppercase hex characters on UART. Firmware/profile identifiers are bounded ASCII tokens with `.` and `-` additionally allowed.

CRC-32/ISO-HDLC is calculated over all bytes from `R` through the last byte of BODY, excluding the final pipe, CRC field and LF. It is eight uppercase hexadecimal digits. Polynomial (reflected) 0xEDB88320, initial 0xFFFFFFFF, final XOR 0xFFFFFFFF. Check vector `123456789` -> `CBF43926`. No CR is transmitted; a receiver MAY ignore exactly one CR immediately before LF for service tooling, but CRC is still computed without it.

**Maximum frame length is 512 bytes including LF.** Receivers allocate at least 513 bytes for a frame plus terminator. UART RX ring is at least 2048 bytes. An oversized frame is discarded entirely through LF. A partial frame idle for >100 ms is discarded. CRC/length failure has no effect on motor state or measurement timestamps; it increments counters. Overflow discards the partial frame and recovers at the next LF. No truncation is published.

Only one parser owns UART RX in each MCU. Operational dispatch and service-ABI dispatch share that single ownership; after STM handoff only the loader (or locked trial app) runs. §17.5 defines the additional U_* kinds and their restricted mode. ACKs, state, sensor data and upload replies are dispatched from that parser. No function drains/discards RX to prepare for its own response. No other function calls a private blocking `wait...Response()` reader. Debug print functions cannot access this UART.

### 11.2 Peer discovery

On boot each side sends HELLO every 500 ms until bound. HELLO BODY is `3,1,512,PROFILE_CRC,FW_ID`; FW_ID <=48 characters. Receiver replies HELLO_ACK to the sender's boot ID with the same body form. A valid HELLO establishes the observed peer identity; enable control only if major=3, minor=1, max-frame=512 and profile CRC matches. With a same-format profile mismatch the peer is diagnostic-only: HB, STATE and GET_STATE are allowed, sensor/control/upload frames are not. A different operational major permits only fixed STOP and discovery; unknown telemetry is not decoded as v3. The separately versioned service ABI 1 remains available for explicit recovery irrespective of operational profile/version mismatch (§17.5). It never grants operational permission. A changed peer boot invalidates old requests/leases/samples, causes the state policy in §7, and requires a fresh handshake. Repeated HELLO with the same boot ID does not reset state.

HELLO is the only operational discovery message; §17.5 defines maintenance discovery. Operational heartbeat is `HB` with body `0`, every 250 ms. Only a valid HB/HELLO/HELLO_ACK from the bound peer renews peer liveness. Telemetry cannot masquerade as a heartbeat. UART parser continues to operate after peer loss so that a new handshake can recover.

### 11.3 Requests, replies and duplicate suppression

`CMD` body: `REQ_ID,CONTROL_EPOCH,VERB[,ARG...]`. REQ_ID is a nonzero u32 monotonically allocated by ESP for this boot; it is separate from TX_SEQ. There is one ordinary STM-changing request in flight. STOP has a separate priority slot. An upload uses this same request mechanism, one chunk in flight, and yields to STOP/status/sensors.

`ACK` body: `REQ_ID,RESULT,CODE,DETAIL,CONTROL_EPOCH,STATE_SEQ,STATE,STORE,OUTCOME`.

RESULT is `OK` or `ERR`. CODE is `OK` for success or an enumerated error. DETAIL is u32: lease ID on MANUAL_BEGIN, next byte offset on successful DATA, failing index for validation, otherwise 0. ACK is emitted only after a committed result. START ACK carries the resulting AUTO state; there is no second start-confirmation gate.

Cache the last 32 completed request fingerprints and exact results for the bound peer. A fingerprint includes VERB, args and original epoch. Identical retry returns the cached result without re-execution. Same REQ_ID with a different fingerprint returns `ID_CONFLICT`. Once a request falls outside the cache, a lower/equal ID than the highest admitted request is rejected as `STALE_REQUEST`, never re-executed. STOP invalidates any older pending non-stop request. Do not evict the currently pending request.

ESP may retry the exact same request at 250 ms and 500 ms, within the same peer boot, at most twice. It does not construct a new ID for a retry or edit the original epoch. At 1000 ms unresolved ordinary requests become UNKNOWN; HC's 1500 ms deadline covers bridging/network overhead. ESP requests a fresh STATE to reconcile, but does not manufacture success/failure. No new movement request is derived from a retry. A cached identical request may still retrieve its result after its own committed transition changes the epoch; an unexecuted old-epoch request is rejected. Mission UP_END validation is the sole long-running operational CMD; maintenance U_REQ has separate phase deadlines in §17.5. UP_END ACK may take 30 s; progress is STORE=VALIDATING, and STOP can cancel it.

CMD-specific checks follow CRC/session/duplicate checks. Responses to old requests never overwrite a newer STATE cache. STATE_SEQ ordering is wrap-safe. A received `ACK ERR` is a rejection; missing ACK is UNKNOWN, not a rejection.

### 11.4 Command dictionary

| VERB | Arguments after VERB | Exact meaning |
|---|---|---|
| ARM | none | §6 transition. |
| DISARM | none | §6 transition. |
| START | UUID32,revision,file_crc | Must match the READY mission. No implicit upload or replacement. |
| PAUSE | none | Preserve current checkpoint. |
| RESUME | UUID32,revision,file_crc | Must match paused checkpoint and READY mission. |
| RESET_FAULT | none | §7 reset conditions. |
| HEADING_SET | true_heading_mdeg | Integer 0..359999; §8.2. |
| MANUAL_BEGIN | none | Create lease; lease ID equals this REQ_ID, initially zero targets. |
| MANUAL_END | lease_id | Only affects matching active MANUAL lease. |
| UP_BEGIN | total_bytes,file_crc | Begin one mission transfer. Upload ID equals this REQ_ID. |
| UP_DATA | upload_id,offset,length,HEX_BYTES | 1..128 bytes; exactly 2×length uppercase hex chars. |
| UP_END | upload_id | Validate and commit READY. |
| UP_ABORT | upload_id | Cancel matching receiving/validating transfer. |
| MAINT_BEGIN | none | Enter ordinary non-firmware maintenance; not an update-session entry. |
| MAINT_END | none | Exit ordinary maintenance only; rejected UPDATE_MODE while firmware lock is active. |
| GET_STATE | none | ACK plus immediate current STATE; no mode change. |

STOP is a dedicated frame kind, with BODY=`REQ_ID`. It is accepted even with epoch/profile mismatch and unbound destination, after framing/CRC validation. ACK returns current committed state when a reply destination is available. For a bound peer, normal duplicate semantics apply; an unbound STOP may always reassert stopped outputs but cannot arm or clear a fault. This is a v3 parser guarantee, not a claim that old v2 firmware understands it. During a mixed-firmware upgrade physical stopping remains necessary.

Error CODE enum: `UPDATE_MODE`, `INVALID_PAYLOAD`, `OUT_OF_RANGE`, `UNKNOWN_COMMAND`, `BAD_STATE`, `BUSY`, `NOT_READY`, `NOT_STOPPED`, `NOT_COMMISSIONED`, `SAFETY_ACTIVE`, `FAULT_ACTIVE`, `GNSS_STALE`, `GNSS_QUALITY`, `IMU_STALE`, `HEADING_QUALITY`, `HEADING_UNREFERENCED`, `MOTOR_UNAVAILABLE`, `MISSION_MISMATCH`, `REPOSITION_REQUIRED`, `GEOFENCE`, `INCOMPATIBLE_VERSION`, `PROFILE_MISMATCH`, `STALE_SESSION`, `STALE_EPOCH`, `STALE_REQUEST`, `ID_CONFLICT`, `LEASE_MISMATCH`, `UPLOAD_MISMATCH`, `BAD_OFFSET`, `CANCELLED`, `INTERNAL`, plus §10.3 validation codes. A protocol parser rejects missing/extra positional fields. A human diagnostic message may be generated by ESP from the code; it is not parsed back into a code.

For multiple failed preconditions, report the first in this order: protocol/session/profile; syntax/range; duplicate conflict/stale request; epoch; active physical safety/fault; state/busy store; commissioned profile; required motor availability/stopped state; mission identity; IMU/reference; GNSS; geofence/position; 1000 ms readiness stability. The final stability wait uses NOT_READY; missing data uses its specific code. No global ready flag may hide the actual rejection cause.

### 11.5 Sensor and manual frame bodies

| KIND | BODY field order |
|---|---|
| GNSS | sensor_epoch,sample_seq,sample_age_ms,itow_ms,lat_e7,lon_e7,height_mm,fix_type,fix_ok,carr_soln,hacc_mm,ground_mm_s,course_mdeg,satellites |
| IMU | sensor_epoch,sample_seq,sample_age_ms,yaw_mdeg,pitch_mdeg,roll_mdeg,accuracy_mdeg,valid |
| MAN | control_epoch,lease_id,input_seq,linear_mm_s,yaw_mdeg_s,blade_rpm,deadman |

GNSS and IMU are sent only for new source samples. Invalid new samples may be sent with fix_ok/valid=0; associated numeric fields must remain syntactically valid and MUST NOT be used for control. IMU yaw is normalized [0,360000), pitch/roll within [-180000,180000], accuracy nonnegative. Fix fields are receiver values, `fix_ok`/`valid` and deadman are 0/1; unknown validity is 0. GNSS hAcc is unsigned, satellite count 0..255, course normalized [0,360000). Range-invalid inputs are dropped, not coerced.

MAN has no normal ACK. Only strictly newer input_seq for the matching lease/epoch refreshes its 350 ms STM receive deadline. Duplicate/replayed input does not refresh it. Out-of-range or malformed MAN for the active lease ends that lease and stops with MANUAL_INVALID. Valid `deadman=0` requires all targets zero; a nonzero target with deadman=0 is invalid. MAN frames arriving in AUTO/PAUSED are rejected/ignored without affecting those states. STM reports last accepted input_seq in STATE/telemetry.

ESP does not periodically replay the last MAN. It sends each newly received complete WS drive frame at most once. Network pings and application heartbeats do not generate MAN.

### 11.6 STM telemetry frame bodies

All values are snapshots built from committed state; `~` is permitted only for explicitly unknown numeric measurements. No string parsing of debug logs is involved.

| KIND | BODY field order | Rate |
|---|---|---:|
| STATE | state_seq,control_epoch,event_seq,state,phase,store,UUID32,revision,file_crc,index,count,outcome,reason,fault_mask,lease_id,last_input_seq,stopped,ready_for_start,ready_for_resume | 5 Hz + change |
| POSE | state_seq,gnss_epoch,gnss_seq,gnss_age_ms,imu_epoch,imu_seq,imu_age_ms,lat_e7,lon_e7,height_mm,fix_type,fix_ok,carr_soln,hacc_mm,satellites,east_mm,north_mm,heading_mdeg,heading_valid,pitch_mdeg,roll_mdeg,heading_error_mdeg,cross_track_mm,distance_to_end_mm,linear_cmd_mm_s,yaw_cmd_mdeg_s | 5 Hz |
| MOTOR | id,age_ms,erpm,wheel_mm_s,blade_rpm,current_ma,duty_permille,target_erpm | Each required driver 2 Hz |
| SAFE | installed_mask,active_mask,imu_valid,tilt_active,pitch_mdeg,roll_mdeg | 2 Hz + change |
| PERF | busy_permille,supervisor_wcet_us,nav_wcet_us,deadline_misses,uart_crc_errors,uart_overflows,can_tx_errors,rx_high_water,tx_high_water | 1 Hz |
| UPLOAD | upload_id,store,received_bytes,total_bytes,validation_code,detail | 2 Hz while busy + change |

STATE's UUID32 is all zero with no mission; revision/crc/index/count then zero. `file_crc` and masks use eight uppercase hex characters; other fields decimal. STATE_SEQ increments for each newly produced STATE snapshot, not merely on state changes. POSE references the most recently produced STATE_SEQ and includes one coherent STM input snapshot; ESP must not splice a newer local GNSS position into an older STM POSE. `event_seq` increments on meaningful state/reason/fault transitions. Unknown ages/measurements use `~`; availability is not inferred from zero. `stopped`, ready flags and heading_valid are 0/1 and false when their required data are unknown. Navigation error/distance fields are `~` outside a current mission segment.

`reason` is `NONE`, `OPERATOR`, `MANUAL_EXPIRED`, `MANUAL_INVALID`, `PEER_LOST`, `GNSS_STALE`, `GNSS_QUALITY`, `IMU_STALE`, `HEADING_QUALITY`, `HEADING_UNREFERENCED`, `NO_PROGRESS`, `PATH_ERROR`, `GEOFENCE`, `BLADE_NOT_READY`, `COMPLETED`, `RESET`, or the name of a §7.2 fault. `UUID32`/CRC are mission identity, never an ESP-invented replacement.

Noncritical telemetry is latest-value only. If several snapshots are pending, overwrite the unsent older snapshot. No replay backlog is sent after reconnection. Reply and STOP scheduling outrank telemetry. Every producer checks formatted length; a frame exceeding 512 bytes is an implementation error, never sent partially.

## 12. HC–ESP MQTT interface

### 12.1 Topics and session policy

Use namespace `homecontrol/mower/v3`. Broker address, credentials and robot IP are deployment settings, not source-code literals. Operational deployment is a trusted local network with broker authentication and per-device ACLs; no public Internet exposure is part of this baseline.

| Relative topic | Direction | QoS / retain | Purpose |
|---|---|---|---|
| `availability` | ESP -> HC | 1 / true | JSON online/offline including ESP boot ID; LWT offline. |
| `identity` | ESP -> HC | 1 / true | Firmware/build/profile/protocol identity. |
| `cmd` | HC -> ESP | 0 / false | Bounded discrete requests. |
| `stop` | HC -> ESP | 0 / false | Priority global stop. |
| `ack` | ESP -> HC | 0 / false | Correlated final result or UNKNOWN. |
| `state` | ESP -> HC | 0 / false | Authoritative STM snapshot plus transport freshness. |
| `nav` | ESP -> HC | 0 / false | Current sensor/navigation snapshot. |
| `motor/1`, `motor/2`, `motor/3` | ESP -> HC | 0 / false | Motor snapshots. |
| `health` | ESP -> HC | 0 / false | Performance, link and acquisition health. |
| `event` | ESP -> HC | 0 / false | State/reason/fault transition. |

Use MQTT clean sessions, no persistent command queues and no automatic application replay after reconnect. Receiver MUST be able to inspect and reject retained messages on cmd/stop; libraries that hide retained-delivery information must be adapted or replaced. A retained STOP is rejected as stale input, while an operator can always issue a fresh STOP. Normal payload maximum is 2048 bytes. Maximum accepted ordinary requests is 5/s; STOP is coalesced into one pending stop and remains available under load.

### 12.2 Command and result schema

All fields below are required. Unknown extra fields on command objects are rejected to catch mismatched clients.

```json
{
  "v": 3,
  "request_id": "hc-1234",
  "esp_boot": "0123456789ABCDEF",
  "stm_boot": "FEDCBA9876543210",
  "control_epoch": 7,
  "command": "start",
  "value": {
    "mission_id": "00112233-4455-4677-8899-aabbccddeeff",
    "revision": 1,
    "crc32": "A1B2C3D4"
  }
}
```

`request_id` matches `[A-Za-z0-9_-]{1,64}` and is unique per HC process boot. ESP maps it to a UART REQ_ID and caches the last 64 request fingerprints/results. Same ID with altered data is ID_CONFLICT. An exact repeated ID returns cached status; HC does not automatically resend UNKNOWN movement requests. Commands include current boot IDs and the latest STM control epoch; stale values are rejected. Boot IDs are hexadecimal strings, not JSON integers.

| `command` | `value` | UART mapping |
|---|---|---|
| `arm`, `disarm` | null | ARM / DISARM |
| `start`, `resume` | mission_id,revision,crc32 object | START / RESUME with matching identity |
| `pause` | null | PAUSE |
| `reset_fault` | null | RESET_FAULT |
| `heading_set` | `{ "heading_mdeg": integer }` | HEADING_SET |
| `maintenance_begin`, `maintenance_end` | null | MAINT_BEGIN / MAINT_END |
| `telemetry` | null | GET_STATE plus immediate cached diagnostics with their real ages |

`stop` topic payload is only `{ "v":3,"request_id":"hc-stop-1" }`. It does not require owner, known STM state, profile match or current boot/epoch. ESP sends dedicated UART STOP; it closes any manual lease only after requesting stop, not as an unrelated timeout side effect. Unknown major messages do not authorize movement; STOP with this fixed schema remains the best-effort v3 stop path.

```json
{
  "v": 3,
  "request_id": "hc-1234",
  "command": "start",
  "result": "APPLIED",
  "code": "OK",
  "detail": 0,
  "stm_boot": "FEDCBA9876543210",
  "control_epoch": 8,
  "state_seq": 123,
  "state": "AUTO"
}
```

Result is APPLIED, REJECTED or UNKNOWN. APPLIED requires the correlated STM ACK; ESP-forwarded is not success. REJECTED has a §11 code or gateway code `STM_UNAVAILABLE`, `INVALID_PAYLOAD`, `INCOMPATIBLE_VERSION`, `RATE_LIMITED`. UNKNOWN uses `TIMEOUT` or `LINK_LOST` and may have `state:null`, `state_seq:null`, `control_epoch:null` when not known. `stm_boot` is null only if no peer has ever been established. No ACK means HC shows UNKNOWN after 1500 ms and queries state. The UI never changes to RUNNING solely because it sent START.

### 12.3 Status schemas

Every non-availability/identity status object includes `v:3`, `esp_boot`, `stm_boot` (nullable), `published_ms` (ESP monotonic time), `source_seq` (u32), `source_age_ms` (nullable nonnegative integer), `source_valid` (boolean). For STM-derived data source_seq is the relevant newly received frame's TX_SEQ, and age increases from its receive time. Republish cannot turn a cached snapshot into a new source sample. source_valid means a complete compatible source message no older than 1500 ms with a live bound peer; it does not replace individual sensor validity/age fields. A gateway-local health field remains observable even when the STM part is unknown.

All table fields are mandatory; nullable fields explicitly use JSON null when unavailable. Enum spellings match UART. SI conversions may be displayed by HC, but wire units below remain integer units. HC does not guess aliases from the v2 schema.

| Topic | Additional fields |
|---|---|
| `identity` | `v`, `contract:"3.1.0"`, `esp_boot`, `stm_boot`, `esp_fw`, `stm_fw` (nullable), `profile_crc`, `compatible:boolean`, `conformant:boolean`, `max_mission_bytes:131072`, `max_segments:4096`, `manual_protocol:"homecontrol.mower.manual.v3"`, `stm_remote_update:boolean`, `update_service_abi:1`, `stm_bootloader_fw` (nullable), `stm_flash_layout:"H743_2M_AB1"`, `stm_image_max_bytes:786432`, `stm_confirmed_slot` (A/B/NONE/null), `stm_inactive_slot` (A/B/null), `stm_reset_recovery:boolean`, `update_locked:boolean`, `esp_ota_max_bytes` (actual inactive partition capacity) |
| `availability` | `v`, `esp_boot`, `online:boolean`; LWT uses the same boot and online=false. Online does not assert healthy STM. |
| `state` | `state_seq`, `control_epoch`, `event_seq`, `state`, `phase`, `armed`, `store`, `mission_id` (nullable), `revision` (nullable), `crc32` (nullable), `segment_index`, `segment_count`, `outcome`, `reason`, `fault_mask`, `stopped`, `ready_for_start`, `ready_for_resume`, `manual_lease_id` (nullable), `manual_input_seq` (nullable), `safety_installed_mask`, `safety_active_mask` |
| `nav` | `lat_e7`, `lon_e7`, `height_mm`, `gnss_epoch`, `gnss_seq`, `gnss_age_ms`, `fix_type`, `fix_ok`, `carr_soln`, `hacc_mm`, `satellites`, `imu_epoch`, `imu_seq`, `imu_age_ms`, `heading_mdeg`, `heading_valid`, `pitch_mdeg`, `roll_mdeg`, `east_mm`, `north_mm`, `heading_error_mdeg`, `cross_track_mm`, `distance_to_end_mm`, `linear_cmd_mm_s`, `yaw_cmd_mdeg_s`; measurements nullable if unavailable |
| `motor/id` | `id`, `feedback_age_ms`, `erpm`, `wheel_mm_s` (null for cutter), `blade_rpm` (null for wheels), `current_ma`, `duty_permille`, `target_erpm`; measured fields nullable |
| `health` | `wifi_connected`, `rssi_dbm` (nullable), `stm_peer_alive`, `ntrip_state`, `rtcm_age_ms` (nullable), `esp_core_busy_permille` (two integers), `esp_internal_free_bytes`, `esp_largest_internal_block`, `esp_stack_min_bytes` (object), `stm_busy_permille`, `stm_supervisor_wcet_us`, `stm_nav_wcet_us`, `deadline_misses`, `uart_crc_errors`, `uart_overflows`, `can_tx_errors`, `telemetry_drops`, `gnss_input_errors`, `imu_resets`; unavailable STM values null |
| `event` | `event_seq`, `state`, `reason`, `fault_mask`, `segment_index`, `mission_id` (nullable); emitted from authoritative STM transitions only |

For missing STM state, `state`, state_seq, epoch, phase, outcome and related fields are null and source_valid=false. Do not publish DISARMED as a substitute for unknown. Network booleans remain actual gateway observations. Derived `armed` is false when unknown but source_valid=false must be shown prominently; it is not proof of stopped motors.

During exclusive updating, MQTT and ordinary telemetry are stopped; HTTP identity/update status remains available (§17). `stm_remote_update` is true only when the installed loader/layout and required tests are verified; its advertised capability is not proof a transfer is complete.

Publishing rates during ordinary operation: state/nav 5 Hz; motors 2 Hz each; health 1 Hz; identity on connection/change; events on transition. HC marks state/motor data stale after 1500 ms without a **new source sequence**; nav additionally uses individual measurement ages, with the stricter STM quality rules for ready indications. For display, effective sample age is reported sample age plus source_age_ms plus local time since HC receipt; receiving a republished unchanged source_seq cannot reset the freshness deadline. Retained identity/availability is informational and cannot authorize movement until fresh STATE from the stated boot arrives. Event loss is repaired by the next state snapshot.

## 13. Manual WebSocket interface

Endpoint `/api/v3/manual`, subprotocol `homecontrol.mower.manual.v3`. One authenticated operator connection; maximum message 512 bytes, maximum 20 messages/s. HC's backend relays the authenticated browser's WS setpoints to ESP using an Authorization Bearer header on the ESP upgrade; the API token stays out of the browser. The relay preserves sequence/full-setpoint semantics and does not replay or periodically synthesize last-known commands. MQTT is not a continuous driving channel. Old `/ws` and v1 frame formats return an explicit incompatible response/close.

Claim:

```json
{"type":"claim","request_id":"hc-manual-1","esp_boot":"0123456789ABCDEF","stm_boot":"FEDCBA9876543210","control_epoch":7}
```

ESP sends MANUAL_BEGIN only if this connection has no lease and no other connection owns one. STM's IDLE precondition prevents taking over AUTO/PAUSED. After STM ACK, return:

```json
{"type":"claimed","lease_id":31,"control_epoch":8,"lease_ms":350,"max_linear_mm_s":250,"max_yaw_mdeg_s":30000}
```

Drive frames are complete desired state, at 10 Hz while the operator holds the deadman:

```json
{"type":"drive","lease_id":31,"control_epoch":8,"seq":1,"linear_mm_s":100,"yaw_mdeg_s":0,"blade_rpm":0,"deadman":true}
```

Frame sequence increases strictly for this lease. One latest unsent setpoint per lease is retained, never a queue of historical joystick movements. ESP forwards only newly received frames within 100 ms of receiving them; otherwise drops them and lets the local lease expire. Limits come from the installed profile. Out-of-range input ends the lease and sends MANUAL_END, rather than silently clamping a malformed operator command. Valid commands may still be commonly scaled by physical wheel limits in STM (§9).

Operator deadman release sends a new full zero setpoint with deadman=false. WebSocket `stop` is `{type:"stop",lease_id,control_epoch,seq}` and maps to that same full zero MAN, keeping ownership. `release` is `{type:"release",lease_id,control_epoch}` and maps to MANUAL_END. Global stop uses the separate HTTP/MQTT stop path. No nonzero command is restored after reconnect or reacquisition.

Application heartbeat frames are removed. WS ping/pong is transport liveness only and never renews motion. STM expires the last accepted complete setpoint after 350 ms even if the ESP application is stuck, provided STM/CAN continue running; VESC timeout covers STM failure separately.

ESP returns `{type:"observed",lease_id,last_input_seq,state,stopped}` from STM telemetry, not an optimistic execution ACK. Errors are `{type:"error",code,detail}`. On close, ESP sends MANUAL_END only for that socket's matching active lease. If STM is now AUTO, a late close is harmless and must not become STOP. Global state changes invalidate ownership at both gateway and UI.

Manual mode requires fresh IMU tilt data and healthy wheels, but no GNSS or heading reference. Nonzero manual blade requests additionally require blade_enabled and healthy cutter feedback. All three manual targets share the same full-setpoint expiry.

## 14. HTTP upload and maintenance interface

HTTP serves binary upload, identity/status snapshots, stop and maintenance; it does not introduce a second mission command implementation. The same ESP dispatcher handles HTTP, MQTT and WS requests and uses identical STM semantics. A minimal web page may show state and invoke these APIs; it has no autonomous control engine.

Use provisioned local credentials: a high-entropy API token in `Authorization: Bearer ...`, shared with the authorized HC backend; not in URL/query/logs. WS uses the backend relay defined in §13. Static firmware source must not contain operational Wi-Fi, API, OTA or NTRIP secrets. Authenticated LAN transport is the scope; deployments outside a trusted LAN require TLS and are not enabled by default.

| Method/path | Request | Result |
|---|---|---|
| GET `/api/v3/identity` | none | §12 identity JSON. |
| GET `/api/v3/state` | none | Same state schema and real age as MQTT. |
| GET `/api/v3/profile` | none | Canonical installed profile and CRC; 503 until STM match is established. |
| POST `/api/v3/command` | Same object as MQTT cmd | 202 with request_id while pending; poll result. No blocking handler. |
| GET `/api/v3/command/{request_id}` | none | 202 pending; 200 with §12 ACK; 404 unknown/evicted. |
| POST `/api/v3/stop` | `{v:3,request_id}` | Priority STOP; 202 or completed ACK. |
| POST `/api/v3/mission` | Raw `application/octet-stream`; exact Content-Length; `X-Mission-CRC32`, `X-Request-ID`, `X-ESP-Boot`, `X-STM-Boot`, `X-Control-Epoch` | Stream RVM3 through one bounded transaction, then 202 with upload_id; do not claim READY yet. |
| GET `/api/v3/mission` | none | store, upload_id nullable, bytes, total, mission identity, validation_code, detail; STM-authoritative. |
| DELETE `/api/v3/mission/upload/{id}` | none | Cancel only that upload; 202 until acknowledged. Does not stop an autonomous mission. |
| POST/GET `/api/v3/update` and per-session image/status/abort/finish | Exact methods and schemas in §17.4. | One exclusive session for target STM or ESP; no parallel OTA route. |

HTTP statuses: 400 syntax, 401/403 authentication, 409 state/session/profile conflict, 413 too large, 415 wrong content type, 422 image validation, 423 UPDATE_MODE, 429 busy/rate limit, 503 unavailable STM. §17 defines update job results separately from HTTP transport status. An HTTP 200/202 is not proof of actual physical execution; the returned result/store carries that meaning.

Only one mission or firmware upload is active; firmware entry cancels a mission upload. For a mission, ESP reads at most 1024 bytes of body ahead of STM acknowledgements, using TCP backpressure. It may keep this spool in PSRAM; it must not allocate a second whole mission to run another semantic validator. Chunk transfers are nonblocking UART transactions. If client disconnects before successful END, cancel the transfer; if it disconnects after END was admitted, STM may finish validation, but never START automatically. HC reconciles using GET mission. A new request does not silently replace a pending upload.

Content-Length must match RVM3 total_bytes; chunked HTTP transfer encoding is not accepted in v3.1. X-Mission-CRC32 equals the header checksum defined in §10, not an ordinary whole-file CRC including its own field. Header/body mismatch rejects the upload. Any STOP during receiving/validation cancels that operation before acknowledging stop; progress polling remains available.

Removed endpoints, including `/api/cmd`, legacy drive/blade/route/heading routes every `/api/stm_update*` and `/api/v3/ota/esp`, MUST return 410 or be absent (404). They must not remain as hidden bypasses. `GET /` may provide status and links only; manual controls, if offered, use §13.

## 15. STM–VESC CAN interface

### 15.1 Wire and commands

Use VESC CAN mode, 500 kbit/s, 29-bit extended identifiers, Classic CAN, BRS off. `EID=(packet_id<<8)|controller_id`. Payload integers below are signed big-endian. No broadcast movement is used.

| Packet | ID | Payload | Baseline use |
|---|---:|---|---|
| SET_CURRENT | 1 | i32 milliamps, DLC=4 | Cutter zero-current stop; wheel release when profile requires it. |
| SET_CURRENT_BRAKE | 2 | i32 milliamps, DLC=4 | Tested wheel stop/brake current. |
| SET_RPM | 3 | i32 electrical RPM, DLC=4 | Wheel and blade velocity targets. |
| STATUS | 9 | eRPM:i32, motor current:i16 (0.1 A), duty:i16 (0.001), DLC=8 | Required feedback. |

IDs 1/2/3 refer to left/right/blade. Positive VESC eRPM is not inherently robot forward; §9 direction calibration defines that. Packet STATUS current is motor current, not battery input current. Do not publish a battery current using this value. Additional temperature/voltage STATUS types may be logged only after exact firmware-specific scale verification; they are not required fields in v3.1 and do not refresh the required STATUS age.

Every active/required motor target is refreshed at 50 Hz. The inactive cutter receives stop commands during transitions; disabling a cutter does not send a nonzero keepalive. VESC local timeout is configured to 500 ms and remains enabled. Wheel timeout brake current is the corresponding profile wheel_brake_ma; cutter timeout brake current is zero in this baseline. Wheel stopping and cutter coast time must match the tested behavior of §4/§7. Timeout configuration is verified in the actual installed VESC firmware; VESC Tool application version alone is not a firmware identifier.

### 15.2 Queue discipline and feedback

One latest desired CAN command per motor; never an unbounded list of historical targets. Use nonblocking HAL TX and completion/error notifications. A stop cancels unsent nonzero frames and replaces mailbox targets. Already-submitted hardware frames must be cancelled where supported or followed immediately by stop within the proven bound. The driver reports a failure if it cannot guarantee refresh deadlines.

No per-frame printf, UART TX dump, 20 ms polling loop or CAN recovery scan runs in the active motor path. CAN bus-off immediately inhibits motion, latches CAN_BUS and cancels all nonzero targets. Recovery may run once per second while faulted; successful recovery does not restore motion. Operator RESET_FAULT/ARM is required.

Configure required STATUS at 20 Hz per driver. STM maintains independent timestamps per motor and per packet type. Messages from another ID or another STATUS type cannot keep a missing wheel alive. A physically absent disabled blade is ignored for manual/bladeless missions; wheels are always required for movement. Malformed DLC, standard IDs or unexpected packets do not update feedback age.

SET_RPM being transmitted does not prove it was accepted, nor that the motor turned. During commissioning compare requested/observed direction, wheel speed and cutter speed. Timeout behavior must be tested by removing STM transmission while the VESCs remain powered and still exchange any background traffic; this verifies that unrelated CAN traffic cannot preserve a stale movement target.

## 16. Scheduling, budgets and backpressure

### 16.1 Design objective

The objective is bounded latency and spare capacity, not equal CPU percentages. STM may normally be much less busy than ESP. An idle MCU is not wasted if it meets its deadlines predictably. Increasing loop frequency, duplicating navigation, raising the clock or disabling watchdogs is not a valid substitute for removing blocking work.

The timing figures below are **acceptance budgets**, not measured performance claims about the supplied firmware. Capture actual utilization and worst-case times on the installed boards. An implementation that exceeds a budget must reduce noncritical work or fix scheduling before raising limits through a new revision.

### 16.2 ESP tasks

Use the existing Arduino/ESP-IDF runtime, pinned and version-locked in the repository. A monolithic `loop()` containing synchronous HTTP/MQTT/NTRIP/UART waits is prohibited.

| Task | Suggested core / relative priority | Work | Limit |
|---|---|---|---|
| UART bridge | core 1 / highest application priority | UART RX parsing, STOP, pending-command timers, TX scheduling, immutable STM cache | Service every <=2 ms; no socket/I2C/flash calls. |
| Sensor I/O | core 1 / next | GNSS byte parsing, IMU acquisition and source timestamping, RTCM write to GNSS | GNSS service <=5 ms; I2C transaction timeout <=5 ms; latest samples only. |
| Network frontend | core 0 / medium | HTTP/WS/MQTT state machines, small JSON messages, upload backpressure | Each callback <=2 ms CPU; service <=10 ms while active. No blocking NTRIP connect here. |
| NTRIP worker | core 0 / lower | Socket connection, correction packet framing, GGA send | Bounded blocking permitted only here; queue output to Sensor I/O. |
| Maintenance/logger | core 0 / lowest | Provisioning, OTA, bounded local diagnostics | Flash writes only while MAINTENANCE/stopped. |

Exact numeric priorities must avoid starving vendor Wi-Fi/RTOS tasks; they are implementation details tested under §22. Do not hold a mutex while waiting for a socket, UART ACK or I2C completion. Exchanges use bounded mailboxes and immutable snapshots. Only bridge owns UART and authoritative STM cache writes. Network handlers enqueue validated intent; they cannot write UART directly.

### 16.3 STM scheduler

Use a cooperative superloop with interrupt/DMA-driven UART and CAN. Adding an RTOS is not required. The 1 ms timer only advances a monotonic scheduler counter and sets due flags; it does not run the navigation loop or print logs.

| Work | Rate / schedule | Execution budget |
|---|---|---|
| GPIO assertion latch | Interrupt plus 10 ms supervisor | ISR <=20 us; no formatting/allocations. |
| Supervisor/output arbiter | 100 Hz | WCET <=500 us; start jitter <=2 ms. |
| Navigation | 20 Hz | WCET <=2000 us including runtime fence checks. |
| CAN scheduler | 50 Hz + immediate stop priority | Enqueue work <=500 us; never wait for physical TX completion. |
| UART RX parsing | Each loop, bounded slice | <=256 bytes or 500 us per pass; then service other due work. |
| CAN RX parsing | Each loop, bounded slice | <=16 frames or 500 us per pass; queues provisioned for the expected rate. |
| Mission CRC/geometry validation | Background while stopped | <=2 ms slice; yields between slices. |
| Telemetry formatting | Due snapshots only | <=1 ms per slice; latest-value coalescing. |

Supervisor order: acquire current input snapshots; process highest-priority stop/fault events; evaluate lease/peer/sensor validity; commit state transitions; select one mode's current intent; enforce expiry/limits; update actuator mailboxes; publish transition event. Navigation never performs an independent safety reset.

While MANUAL remains valid, its local generator may derive a new intent from the last still-unexpired MAN every 50 ms; this renews only the 100 ms internal intent deadline, **not** the original 350 ms manual receive deadline. AUTO creates a new intent every 50 ms from current usable snapshots. A stopped or invalid mode clears intent. The CAN task refreshes only the current arbiter-approved intent, never a retained raw target with unlimited lifetime.

If supervisor start is >20 ms late while armed, invalidate output and latch CONTROL_DEADLINE on recovery. If the main loop is completely stuck, IWDG resets within 250 ms; VESC local timeout remains independently active. Feed IWDG only after a completed healthy supervisor cycle and servicing the scheduled CAN/UART workers; a timer interrupt alone cannot feed it. An intentionally absent peer/sensor may cause PAUSED without causing endless watchdog resets. Once update quiescence is committed, use the bounded updater feed condition in §17.6 instead; deliberately stopped CAN/navigation tasks are not watchdog failures.

### 16.4 Fixed memory and queue policy

| Resource | Minimum / policy |
|---|---|
| STM mission bank | One fixed 131072-byte buffer. |
| STM UART RX | 2048-byte circular DMA/IRQ buffer; separate 513-byte frame parser. |
| UART TX | One frame in hardware; separate priority slots for STOP/ACK/HB; bounded ordinary queue of 8 frames; latest per telemetry kind. |
| ESP sensor storage | One latest sample per sensor plus bounded raw RX buffers; no historical sample replay. |
| ESP GNSS RX | At least 4096 bytes; oversized/unknown UBX payload skipped using validated bounded length, not allocated. |
| ESP HTTP mission upload ahead | At most 1024 bytes, one STM DATA outstanding. Exclusive STM firmware updating instead uses the single <=786432-byte PSRAM buffer in §17.7; never during motion. |
| ESP ordinary command queue | At most 4 pending network commands, one forwarded STM command; excess returns BUSY. |
| Manual command slot | One latest unsent full setpoint; a late setpoint is dropped. |
| Event log | Fixed 64-entry ring on STM; overwritten oldest increments dropped count. |
| Dynamic memory | No allocation in STM active control path/ISR; no ESP allocation per sensor sample/drive tick. |

Use overflow-checked size arithmetic and bounded conversion routines. HAL DMA buffers must live in memory reachable by the selected DMA. On STM32H7 use a dedicated non-cacheable MPU region for DMA buffers or a fully tested cache-maintenance scheme; do not assume DTCM/ordinary cached heap is universally suitable. Keep DMA alignment and linker placement explicit. Main application remains within the real SRAM/flash map; the old 256 KiB mission bank/FatFs allocations must not remain allocated alongside the new bank.

If normal telemetry queues fill, drop/replace old telemetry and count it. If a required response queue cannot make progress, stop admitting ordinary requests; STOP's reserved slot remains available. An INTERNAL fault is justified only if control integrity is lost, not simply because a debug log was dropped.

### 16.5 Measurable headroom

During ordinary operation, at maximum accepted sensor/mission/telemetry load, with repeated network reconnect attempts (exclusive updating has its own §17 deadlines):

- STM mean busy time <=40% over any 10 s window, and no supervisor/control deadline misses in a 60-minute run.
- Each ESP core mean busy time <=60% over 10 s; 1 s utilization <=85% except stopped maintenance/startup. Blocked/yielding task time is not CPU busy time.
- ESP internal free heap >=64 KiB, largest internal free block >=16 KiB, and each task's remaining stack >=1024 bytes. A board configuration unable to meet this must resize static/network buffers, not consume reserve unnoticed.
- STM total statically allocated application RAM including stacks <=256 KiB, unless the actual linker map demonstrates a documented higher budget with at least 25% free usable SRAM. Mission bank included.
- UART average occupancy during ordinary operation <=60% per direction over 1 s; it is full-duplex, so the directions have separate budgets. A single priority burst may exceed this briefly. Upload is rate-limited and yields first.
- CAN average occupancy <=15%; standard release target is comfortably below it with three 50 Hz commands and three 20 Hz STATUS sources. Measure actual background traffic.
- From an authenticated STOP received at ESP to stop command enqueue on healthy STM/CAN: <=100 ms under the worst accepted upload/telemetry load. Local physical input to STM stop enqueue: <=20 ms, except independent hardware cutoff which does not wait for software.
- From last valid WS setpoint received by ESP to revocation of its STM nonzero target: <=500 ms, including ESP forwarding, UART serialization and STM lease/scheduler delay. Physical stopping time is additional and is measured separately.

A 512-byte UART frame occupies about 44.45 ms at 115200/8N1. At most one nonpreemptible frame may block STOP. Do not pre-fill a long DMA TX chain with upload frames. Under normal rates the roughly 20 Hz IMU + 5 Hz GNSS + 4 Hz HB stream leaves margin; producers must account actual framed lengths, not assume the budget is satisfied. Upload's token bucket enforces remaining capacity; its target is >=800 payload bytes/s while stopped, so a maximum mission fits the 180 s limit. If that target cannot be met without deadline loss, return BUSY before transfer rather than starve motion-related work.

## 17. Persistence, restart and firmware update

### 17.1 Stored versus volatile data

HC durably stores mission files, garden geometry, run logs and firmware packages. ESP persists provisioned credentials, installed profile/build metadata and one small update-session record. STM persists the commissioned installation data and the boot/update journal in §17.6. Update records are written on committed phase changes, never on every block or telemetry tick. Runtime targets, leases, heading reference, checkpoint and current mission remain volatile.

An ordinary ESP reboot causes the §7 peer policy. An ordinary STM reboot loses its mission, heading reference and leases and starts DISARMED. **An active persistent update lock overrides ordinary startup on either MCU:** start the update services only, with outputs forbidden. A reboot, timeout, cancelled upload or failed image MUST NOT silently clear that lock.

Firmware replacement preserves network credentials and the commissioned profile. The installed profile is provisioned separately from the replaceable application slots. New firmware packages MUST declare the same profile CRC; changing calibration/profile remains a separate stopped commissioning operation. Firmware installation is not a factory reset. No saved mission or retained network command is replayed after any reboot.

### 17.2 Ordinary startup and the update startup branch

1. Set actuator permission false before any task or communication initialization. Safe GPIO defaults also apply during reset and bootloader execution.
2. Inspect persistent update/boot metadata before starting normal producers. ESP must establish whether STM is in its application or recovery loader before enabling its ordinary command routes. If either MCU reports an update lock, both follow §17.3.
3. With no update lock, STM brings up safety, UART and CAN and publishes DISARMED. ESP starts sensor/bridge tasks and asynchronously starts network services.
4. Establish operational v3.1 peer/profile agreement. A sensor configuration failure remains visible and cannot create a fallback motion mode.
5. HC receives current identity and fresh state before issuing explicit upload/calibration/ARM/START requests.

Wi-Fi connects asynchronously. The provisioned AP fallback starts after 15 s without station connectivity and uses a unique strong password. During updating, STA/AP, DHCP and the minimum network stack needed to reach the authenticated update HTTP service remain available. No cloud, MQTT broker, GNSS fix, NTRIP stream or working IMU is required to install or recover firmware. AP activation never claims control.

### 17.3 One exclusive update mode for both targets

**UPD-01 — Mandatory feature.** Remote STM application update through **HC → ESP → STM** is a required baseline feature, also in development builds. ESP application OTA uses the same exclusive maintenance session. Exactly one target image is processed at a time. The old app-level `FWUP`, ROM-loader fallback, raw memory writes and bank-copy activation are removed; there is one documented remote STM update implementation.

**UPD-02 — One user action, one coordinator.** HC's update action creates a session and uploads the image. ESP coordinates the job; STM's recovery bootloader alone chooses/writes/validates STM application slots and commits boot metadata. HC and ESP never select a slot as bootable merely because bytes were sent. Successful transfer automatically proceeds to verification and trial boot; there is no additional hidden ACTIVATE/confirmation sequence for the operator to discover. Leaving update mode is a separate explicit action, and never arms the robot.

**UPD-03 — Entry from any operational state.** An authenticated update request is allowed from DISARMED, IDLE, MANUAL, AUTO, PAUSED or FAULT. No ARM, GNSS, IMU, heading or commissioned-motion precondition applies to requesting maintenance. Entry first revokes movement and then proves the stopping precondition; an HTTP 202 means entry is in progress, not permission to erase flash. Invalid create-request syntax/authentication is rejected before disturbing operation. Image validation occurs after entry and cannot authorize a return to motion on failure. Once a valid update request is admitted, motion does not resume even if preparation fails.

The exact entry sequence is:

1. ESP allocates a new 128-bit update ID and durably records `locked=true`, target and request identity. Image size/hash/build are bound durably when the image request is admitted after READY. It closes the admission gate for ordinary commands immediately. A second session cannot replace an active session.
2. ESP cancels its mission upload, pending requests, manual lease connection, unsent drive slot and ordinary UART TX queue. Requests already forwarded are superseded by STM's update-entry transition. Replies to cancelled requests cannot change update state. HC shows their result as CANCELLED/UNKNOWN according to whether execution was known. STOP remains available.
3. ESP discovers the service ABI (§17.5) and sends OPEN. STM immediately enters MAINTENANCE/QUIESCING, increments control_epoch once, revokes all output permission, and clears **mission bytes/validity, checkpoint, segment progress, manual lease, heading reference, motion intents and pending nonzero CAN frames**. This is destructive to runtime work even if an upload later fails. The normal stop procedure executes. Existing physical stops may remain asserted; they need not be released for flashing.
4. During QUIESCING only the traffic needed to complete stopping, the update connection and local stop handling may remain. Apply §7.3 measured stop, including cutter coast, using fresh CAN feedback. Deadline: 60 s. If no fresh stopping evidence is available, remain locked and report NOT_STOPPED; do not assume silence or elapsed VESC timeout proves physical standstill. A positively monitored hardware motor-power inhibit plus the commissioned worst-case coast interval is the permitted alternative (§17.9); an HC checkbox is not evidence.
5. STM requests reset into the immutable recovery loader. The loader independently establishes the same stopping condition before permitting a write; it does not trust an unverified retained `stopped=true` flag. Its small CAN preparation worker may send only the §7.3 stop commands and read feedback. It contains no navigation, manual driving or nonzero RPM generation.
6. Loader commits the update lock/session to its journal, cancels queued CAN TX, stops CAN RX/TX servicing and disables the CAN peripheral. After the last stop transmission, wait at least 600 ms for the commissioned VESC command timeouts to take effect. Continue to forbid output; the independent physical stop circuit remains effective. No CAN ALIVE, RPM refresh, polling or VESC update traffic follows. This last 600 ms is additional to the measured-stop check, not a substitute for it.
7. ESP has stopped and cleared its ordinary producers/queues before sending OPEN; loader's OK/READY completes the two-party quiescence barrier. Only after both conditions are true may ESP accept the firmware body. Every later startup with the update lock takes this restricted path before a write. A new session replacing a terminal session in the same continuously locked loader need not re-enable CAN or repeat physical stopping; output prohibition has never been lifted.

QUIESCING is an update phase within MAINTENANCE, not a new armed robot mode. A live physical stop keeps its inhibit asserted; update mode may report fault bits without leaving maintenance or restarting a control task. Planned sensor/CAN shutdown does not raise GNSS_STALE, IMU_STALE, CAN_BUS, MOTOR_FEEDBACK or CONTROL_DEADLINE errors. A genuine updater/watchdog/flash error becomes an update error and leaves the lock set. Update success does not clear an active physical safety input.

**UPD-04 — Work/channel allowlist after READY.** The table applies to STM update, ESP OTA, transfer errors and recovery waiting; a missing channel is not replaced by an undocumented fallback.

| Component | Runs during exclusive updating | Stopped and discarded |
|---|---|---|
| HC | Authenticated update client, image sender, progress/error display, reconnect/status queries, explicit abort/finish. | Mission start/resume/manual output for this rover; queued retries of pre-update commands. |
| ESP | Wi-Fi STA/AP and required network plumbing; authenticated update HTTP; identity/update status; priority STOP endpoint; one UART service parser/router; bounded image hashing/transfer; watchdog. | MQTT connection/reconnect, manual WS, NTRIP/RTCM, GNSS UART acquisition/forwarding, IMU acquisition/recovery/forwarding, normal telemetry, mission processing, debug streams, filesystem scans and unrelated background jobs. |
| STM loader / trial app | UART update service, image/metadata work, update status, local physical-stop inputs, output inhibit and watchdog; bounded self-tests during trial only. | Navigation, mission execution/upload, manual control, ordinary telemetry, sensor processing, CAN worker/refresh/ALIVE, blade control, periodic operational diagnostic jobs. |
| VESC | Its own configured command timeout and hardware limits. | No MCU application traffic after quiescence; VESC firmware/configuration update is outside this contract. |

Disable the GNSS/IMU RX/interrupt producers or drain hardware FIFOs without parsing using bounded work; do not merely stop the consumer while interrupts/queues continue accumulating. Stop an ordinary UART DMA frame at its natural boundary (maximum 44.45 ms), discard queued ordinary frames, and switch the **same** parser to the service dispatch. No second task reads UART. No log text shares the UART.

MQTT publishes one final maintenance indication when possible and disconnects without waiting for delivery. Its absence then means the ordinary control service is unavailable; HC reads update progress over HTTP. While locked, otherwise valid ordinary HTTP commands, manual upgrades and mission/config uploads return HTTP 423 `UPDATE_MODE`. Removed legacy/OTA routes retain their 404/410 response. Malformed legacy UART control frames cannot change output permission. STOP is accepted as “outputs remain inhibited”; it does **not** mean abort the flash job. The independent physical emergency stop remains live throughout.

**UPD-05 — Data retained versus erased.** Discarding runtime work does not erase credentials, calibration, the last confirmed firmware, the update journal or HC's saved files/logs. The sole retained request result needed from the old operational session is its cancellation/result record; no command executable can survive. After update, HC must re-upload a mission and establish any required heading reference.

### 17.4 HC–ESP update API and observable progress

These authenticated endpoints are the only update surface. They remain reachable in locked mode. Authentication is the same provisioned Bearer scheme as §14; deployment is through HC's authenticated backend on the trusted local network/VPN. SHA-256 detects corruption and is not claimed to authenticate a publisher. Internet exposure without an authenticated protected transport is not part of this baseline.

| Method/path | Request | Result |
|---|---|---|
| POST `/api/v3/update` | JSON below, <=1024 bytes. | 202 after ESP durably admits the session; returns update ID and progress URL. 409 if another nonterminal job exists or the supplied ESP boot is stale. |
| GET `/api/v3/update` | None. | 200, current/last session object; `update_id:null,locked:false,phase:"IDLE"` if none. |
| GET `/api/v3/update/{id}` | None. | 200 current retained session; 404 unknown. |
| POST `/api/v3/update/{id}/image` | `application/octet-stream`, exact Content-Length and image headers below; body is one slot-specific STM binary or one standard ESP app binary. | 202 after receiving the entire declared body; installation/trial continues asynchronously. 409 before READY or for another image, 413 oversized, 422 size/hash/header mismatch. |
| POST `/api/v3/update/{id}/abort` | Empty body. | 202 while aborting; eventual ABORTED with lock retained. Abort never erases the confirmed image or starts ordinary work. |
| POST `/api/v3/update/{id}/finish` | Empty body. | 202 while leaving; eventual IDLE only after §17.8. Allowed after COMPLETE, ABORTED or ERROR with a valid confirmed STM app and valid ESP app. |

Example create request (preparation needs no known STM slot, so it also works when the application is unresponsive):

```json
{"v":3,"request_id":"hc-update-42","esp_boot":"0123456789ABCDEF","target":"STM"}
```

Create fields are exact; unknown/missing fields reject. `request_id` follows §12 bounds; `target` is STM or ESP. After READY, HC reads the confirmed/inactive slot from fresh loader-derived status and selects the corresponding package variant. Image headers are mandatory: `Content-Length` (positive decimal <= capacity), `X-Image-SHA256` (64 lowercase hex), `X-Firmware-ID` (a §11 token <=48 characters), `X-Profile-CRC32` (eight uppercase hex), `X-Contract: 3.1.0`, `X-Flash-Layout` and `X-Image-Slot`. For STM the last two are `H743_2M_AB1` and A/B, matching the current inactive slot; with no confirmed slot choose A. For ESP they are `ESP_IDF_OTA` and `INACTIVE`. Headers cannot override contradictory binary metadata. Content-Length is the exact padded STM image length or standard ESP app length; HTTP chunked bodies are rejected. On admission ESP durably binds the metadata to the session before accepting bytes. A future operational contract requires an explicit specification revision; service ABI 1 remains available to repair operational incompatibility.

ESP uses request_id + request fingerprint to deduplicate create within the persisted last session. An identical retry returns the same update ID; altered content under the same request ID returns ID_CONFLICT. Image retry is permitted only if the retained phase is READY and zero image body bytes have been accepted. During/after admission of a complete body, an identical repeat returns the existing job location without re-flashing; differing size/hash returns ID_CONFLICT. A failed/interrupted body requires abort and a new session. Do not infer success from a disconnected HTTP request.

The GET object contains all of: `v`, `update_id` (32 uppercase hex or null), `target` (STM/ESP/null), `locked`, `phase`, `error`, `detail`, `esp_boot`, `stm_service_boot` (nullable), `source` (ESP/STM_APP/STM_LOADER/STM_TRIAL/NONE), `source_age_ms` (nullable), `source_valid`, `image_bytes`, `http_received_bytes`, `stm_written_bytes` (nullable for ESP), `image_sha256` (nullable), `fw_id` (nullable), `confirmed_slot` (A/B/NONE/null), `inactive_slot` (A/B/null), `candidate_slot` (A/B/NONE/null), `bootloader_fw` (nullable), `last_phase_ms`, `can_active` (boolean/null), `outputs_inhibited` (boolean/null), `stop_evidence` (MEASURED/POWER_INHIBIT/UNKNOWN), `stop_evidence_age_ms` (nullable), `can_retry`, `can_finish`. Before image admission image_bytes and byte counters are 0, hash/build null. Byte counters are nonnegative and cannot exceed declared size. Inactive slot is B for confirmed A, A for confirmed B or NONE, and null if source identity is unknown. Error NONE means no current error; detail is a bounded token <=48 characters. No progress field is proof of physical standstill after its measurement source has been disabled. During loader execution the ordinary STM application state is unavailable; expose the update state explicitly instead of forging an ordinary STATE frame.

can_active and outputs_inhibited are null when there is no fresh STM service evidence; an ESP admission lock alone cannot prove the STM stopped. U_STATUS evidence fields below supply these values. can_retry is true only for a terminal failed/aborted job while locked; retry means a new create request/full image. can_finish is true only when §17.8 prerequisites are known true. last_phase_ms is ESP monotonic entry time for the current observed phase, never a cross-MCU timestamp.

HC polls at 2 Hz. ESP responds from a coherent snapshot, normally within 250 ms, including while erasing. Loader can_active=0 and outputs_inhibited=1 are required at READY and all image phases. A locked trial app reports the same invariants; APP in QUIESCING reports actual stopping-worker values. The last stopping measurement age increases while CAN is off and is not renewed by heartbeat. Update UART status is sent on each phase change and at 2 Hz; a source becomes stale after 2000 ms without a newly received U_STATUS frame. ESP-local HTTP counters remain local observations. A reboot changes service boot identity and invalidates in-flight requests. If progress becomes stale, show UPDATE CONNECTION LOST with last progress retained; do not show a successful rollback/finish without evidence.

The phase machine is:

```mermaid
stateDiagram-v2
    [*] --> QUIESCING
    QUIESCING --> READY
    READY --> RECEIVING
    RECEIVING --> ERASING: STM body verified at ESP
    ERASING --> WRITING
    WRITING --> VERIFYING
    RECEIVING --> VERIFYING: ESP OTA body received
    VERIFYING --> TRIAL
    TRIAL --> COMPLETE
    QUIESCING --> ERROR
    RECEIVING --> ERROR
    ERASING --> ERROR
    WRITING --> ERROR
    VERIFYING --> ERROR
    TRIAL --> ERROR: rollback or failed test
    READY --> ABORTED
    ERROR --> EXITING: explicit finish
    ABORTED --> EXITING: explicit finish
    COMPLETE --> EXITING: explicit finish
    EXITING --> IDLE
```

ERROR and ABORTED remain locked. Abort from any nonterminal phase is permitted; during a hardware flash operation it takes effect at the next completed flash-word/sector boundary, then enters ABORTED. If candidate confirmation already committed, abort cannot undo that installation: report COMPLETE with detail ALREADY_COMMITTED. A new session may replace a terminal session without leaving maintenance; this permits repairing one target then updating the other. No concurrent target flashing, automatic retry loop or automatic abort-to-normal transition exists.

| Phase/operation | Deadline / action |
|---|---|
| Stopping evidence in QUIESCING | 60 s per entry attempt; NOT_STOPPED and lock retained on failure. |
| Loader discovery after deliberate NRST/reset | 10 s excluding its stopping wait; BOOTLOADER_UNAVAILABLE on failure. |
| Waiting in READY | No automatic exit; explicit abort/finish remains available. |
| HTTP image receipt | 10 s without new body bytes or 120 s total -> TRANSFER_TIMEOUT. |
| STM inactive-slot erase including journal work | 90 s total; each sector <=10 s. Status/HB must continue. |
| STM image DATA transfer | 10 s without newly acknowledged bytes or 900 s total -> TRANSFER_TIMEOUT. Heartbeats/duplicates do not renew progress. |
| Full image readback/hash/header verification | 10 s; VERIFY_TIMEOUT on expiry. |
| Trial health proof | 10 s from the new app's entry; failed proof/reset/expiry rolls back. |
| Leaving maintenance | 15 s for STM/ESP restart, discovery and operational service initialization; otherwise ERROR/EXIT_FAILED, command gates remain closed. Sensor fixes need not be available. |

At 115200 baud with hex framing, STM transfer is expected to take several minutes for a large image. Require >=1800 acknowledged payload bytes/s on a healthy unloaded link for images >=64 KiB, excluding erase/verification/trial. Do not change baud, parity or wire format in the middle of an update to hide throughput problems. UI progress separates receiving, erasing, writing, verifying and boot testing; 100% bytes is not completion.

### 17.5 ESP–STM service ABI 1

The bootloader and the application's small maintenance adapter implement the same **service ABI 1**, independent of operational profile/HELLO compatibility. This ABI is frozen so a broken or mismatching application can be replaced. Frame envelope, CRC, 115200/8N1, 512-byte maximum, parser bounds and boot identities are reused from §11. No generic address read/write, erase-all, option-byte programming, ROM command passthrough or arbitrary jump command is exposed.

| KIND | BODY (exact order) |
|---|---|
| U_HELLO | `1,H743_2M_AB1,ROLE,FW_ID` where ROLE is ESP, APP or LOADER. Broadcast destination permitted. |
| U_HELLO_ACK | Same body, unicast to discovered boot. Validates ABI=1 and layout; operational profile mismatch does not disable it. |
| U_HB | `UPDATE_ID` (32 uppercase hex; all zero before OPEN). Every 250 ms in service mode. |
| U_REQ | `REQ_ID,UPDATE_ID,VERB[,ARGS...]`. REQ_ID is nonzero u32, independent from operational CMD IDs. |
| U_ACK | `REQ_ID,UPDATE_ID,RESULT,CODE,PHASE,NEXT_OFFSET,DETAIL`. RESULT OK/ERR; NEXT_OFFSET u32 bytes, DETAIL u32 otherwise 0. |
| U_STATUS | `UPDATE_ID,PHASE,CODE,CONFIRMED_SLOT,CANDIDATE_SLOT,NEXT_OFFSET,TOTAL_BYTES,LOCK,IMAGE_SHA256,FW_ID,CAN_ACTIVE,OUTPUTS_INHIBITED,STOP_EVIDENCE,STOP_AGE_MS`. Slots A/B/NONE; LOCK 0/1; hash uppercase 64 hex or `~`; FW_ID token or `~`; CAN_ACTIVE/OUTPUTS_INHIBITED 0/1; STOP_EVIDENCE MEASURED/POWER_INHIBIT/UNKNOWN, STOP_AGE_MS u32 or `~`. |

All-zero UPDATE_ID is allowed only for read-only STATUS, including reconciliation when the current update ID is unknown. Discovery never itself enters maintenance. Service frames are unicast after discovery and are rejected for stale source/destination boot. A changed peer boot requires discovery and STATUS before another mutation. OPEN deliberately crosses the APP-to-LOADER reset: its APP receipt is not completion; after new loader discovery ESP reissues OPEN for the same update ID/target, addressed to the new boot. A compatible live service adapter is required in each shipped application; an old app without it is entered through the NRST recovery path. Service discovery runs only on explicit HC update/recovery, at startup identification, or while locked; it is not a second periodic operational heartbeat. During a lock U_HB replaces ordinary HB; ordinary 750 ms peer loss must not exit maintenance or reboot the loader.

| VERB | Arguments | Owner / committed meaning |
|---|---|---|
| OPEN | `TARGET` (STM/ESP) | App revokes operation and enters loader; loader commits lock and completes §17.3. ACK OK/READY only from loader after quiescence. Repeated identical OPEN never clears/wipes a transferred image. |
| STATUS | none | Immediate ACK plus U_STATUS. Read-only, allowed before OPEN. |
| BEGIN | `SLOT,IMAGE_BYTES,IMAGE_SHA256,FW_ID,PROFILE_CRC` | Loader only, target STM. Must match inactive slot/capacity/profile. Commits candidate INVALID before erasing only that slot. ACK after erase; NEXT_OFFSET=0. |
| DATA | `OFFSET,LENGTH,HEX_BYTES` | Loader only; LENGTH=128 except final shorter block; HEX_BYTES exactly 2×LENGTH uppercase hex characters; OFFSET multiple of 128 and exactly next expected; total image size multiple of 32. Program/readback then ACK next offset. |
| END | none | Only after all declared bytes. Re-read/hash image, validate embedded header/vector/target, commit candidate pending trial, then reset into one trial. Its OK ACK means trial scheduled, not COMPLETE. |
| ABORT | none | Invalidate unconfirmed candidate, stop admitting data, finish current hardware operation and retain lock. Confirmed slot is unchanged; terminal status ABORTED. |
| EXIT | `ESP_MAJOR,ESP_MINOR,PROFILE_CRC` | Loader only, no write/trial in progress, a valid confirmed STM image exists and matches supplied installed ESP metadata. Execute §17.8. |

All hex tokens on this UART, including SHA-256, are uppercase. Normalize only at the HTTP boundary. BEGIN values must match the HTTP session and the embedded image metadata, not merely one another. APP accepts OPEN/STATUS/STOP only; all flashing verbs require ROLE=LOADER. A trial app provides U_HELLO/U_HB/U_STATUS and local health proof, never accepts BEGIN/DATA while executing from a candidate slot.

One mutating U_REQ is outstanding; STATUS, heartbeat and STOP have reserved slots. Cache the last eight completed U_REQ fingerprints/results and the active request. Same ID/same bytes returns the same result; same ID/different bytes returns ID_CONFLICT. Old IDs outside cache return STALE_REQUEST. Retransmitted identical DATA already acknowledged is ACKed without programming flash a second time; a duplicate whose contents differ aborts with DATA_CONFLICT. Out-of-order new data returns BAD_OFFSET with NEXT_OFFSET unchanged. Never advance on an ESP write-to-UART event.

For ordinary service requests, retry the identical request after 500 ms and 1000 ms; unresolved at 2000 ms becomes unknown and triggers STATUS reconciliation. OPEN, BEGIN, END and EXIT use their phase deadlines instead; their duplicates must join the original work, not restart an erase. Long operations publish status and service HB. No reconnect retries an unobserved END or BEGIN under a new identity. After a peer reboot during an incomplete image, restart transfer from zero in a **new session**, erasing the inactive slot again; byte-resume across reboot is deliberately not implemented.

Framing/CRC failure drops the whole frame. It cannot refresh a progress deadline. Update error CODE enum: `NONE`, `INVALID_PAYLOAD`, `BAD_STATE`, `BUSY`, `UPDATE_MODE`, `ID_CONFLICT`, `STALE_REQUEST`, `STALE_SESSION`, `BAD_OFFSET`, `DATA_CONFLICT`, `BAD_LENGTH`, `BAD_HASH`, `BAD_HEADER`, `WRONG_TARGET`, `WRONG_SLOT`, `PROFILE_MISMATCH`, `ABI_MISMATCH`, `LAYOUT_MISMATCH`, `IMAGE_TOO_LARGE`, `NO_BUFFER`, `NOT_STOPPED`, `BOOTLOADER_UNAVAILABLE`, `TRANSFER_TIMEOUT`, `ERASE_TIMEOUT`, `FLASH_ERROR`, `VERIFY_TIMEOUT`, `TRIAL_FAILED`, `ROLLED_BACK`, `INTERRUPTED`, `METADATA_ERROR`, `EXIT_FAILED`, `CANCELLED`, `INTERNAL`. U_ACK OK uses CODE NONE. U_STATUS reports the last committed error or NONE. Human-readable messages are generated at ESP/HC and never parsed by STM.

### 17.6 STM immutable loader, flash layout and boot decision

**UPD-06 — Fixed recovery root.** Install a dedicated recovery bootloader once using ST-LINK. It is always the reset entry and is outside every remotely writable image range. Hardware write-protect its sector; preserve SWD recovery. Remote updating MUST NOT modify the loader, factory installation record, option bytes or bank-swap setting. A loader upgrade is a separate local service operation. This is an application OTA design, not a self-updating bootloader.

The following layout is mandatory for the **verified 2 MiB STM32H743VI** target. ST documents two 1 MiB banks with 128 KiB sectors and 32-byte data flash words; addresses/part/flash-size register, option bytes, silicon revision and supply programming range must be checked at installation [§24.2, refs 8–9]. A different-density part reports LAYOUT_MISMATCH; it cannot silently use this layout.

| Region | Inclusive address range | Capacity | Remote write rule |
|---|---|---:|---|
| Recovery loader, bank 1 sector 0 | 0x08000000–0x0801FFFF | 128 KiB | Never; hardware write-protected. |
| Journal J0, bank 1 sector 1 | 0x08020000–0x0803FFFF | 128 KiB | Loader journal writer only. |
| Application A, bank 1 sectors 2–7 | 0x08040000–0x080FFFFF | 768 KiB | Only if A is not confirmed. |
| Journal J1, bank 2 sector 0 | 0x08100000–0x0811FFFF | 128 KiB | Loader journal writer only. |
| Factory installation record, bank 2 sector 1 | 0x08120000–0x0813FFFF | 128 KiB | Never via OTA; provisioned locally and write-protected. |
| Application B, bank 2 sectors 2–7 | 0x08140000–0x081FFFFF | 768 KiB | Only if B is not confirmed. |

There is no active-bank copying or option-byte swap. Loader jumps directly to the selected image's vector. The build produces **A-linked and B-linked variants of the same application**, plus the loader artifact and map files. HC obtains `inactive_slot` from current identity and sends that variant. An A-linked binary is never relocated by renaming it B. Both variants share source, FW_ID, profile and ABI, but have distinct image hashes. A development release package contains both binaries plus their exact size/hash/slot/FW_ID/profile/contract metadata; HC selects after READY. The package is HC-side only, never an opaque ZIP forwarded to STM. CI must check slot bounds and test startup/VTOR for both. The app's SystemInit must preserve its slot vector address.

The image begins with the native vector table. A fixed 256-byte header starts at image offset 0x400; the linker reserves that range. All header integers are little-endian, unaligned casts are forbidden, ASCII strings are NUL-padded and must contain a NUL unless using all 48 FW_ID bytes. Image length includes vector/header/code/data and final 0xFF padding to a 32-byte boundary; maximum 786432 bytes, minimum 1280 bytes. SHA-256 covers exactly those bytes, including padding; no self-hash field is embedded.

| Header offset | Size | Value |
|---:|---:|---|
| 0 | 4 | ASCII `RFU1` |
| 4 | 2 | header length 256 |
| 6 | 2 | header format 1 |
| 8 | 16 | target string `STM32H743VI` padded with NUL |
| 24 | 4 | layout ID 1 (`H743_2M_AB1`) |
| 28 | 4 | slot 1=A, 2=B |
| 32 | 4 | link/vector address, 0x08040000 or 0x08140000 |
| 36 | 4 | exact padded image length |
| 40 | 2 | operational major 3 |
| 42 | 2 | operational minor 1 |
| 44 | 2 | service ABI 1 |
| 46 | 2 | zero |
| 48 | 4 | commissioned profile CRC, numeric CRC value |
| 52 | 48 | FW_ID |
| 100 | 156 | zero; unsupported nonzero bytes reject |

Before erase ESP validates declared bounds, hash and header from its complete STM body buffer. Loader repeats independent readback validation before marking candidate valid. The frozen loader validates header/service ABI and bounded version fields; it compares operational version/profile at EXIT rather than baking this document's minor version into an unchangeable loader. ESP package policy and conforming v3.1 images require operational 3.1 as specified here. It checks target/layout/slot/link address/length/ABI/version-field bounds/profile/FW_ID; vector reset handler bit 0 set and address within this image; initial MSP 8-byte aligned and strictly above base, at or below top of a permitted RAM region. Permitted stack ranges for this target: DTCM 0x20000000–0x20020000, AXI SRAM 0x24000000–0x24080000, D2 SRAM 0x30000000–0x30048000, SRAM4 0x38000000–0x38010000, with the upper value interpreted as the exclusive RAM end/valid initial top-of-stack. No image may overlap a protected or journal region. A package with a matching external hash but wrong embedded metadata is rejected.

**UPD-07 — Power-loss-safe journal.** Only the loader writes the two journal sectors. Each append is one 512-byte record: a 480-byte payload written in fresh 32-byte words, followed by a separately programmed 32-byte commit word. Never program an already programmed flash word to set a flag. A record is valid only when payload/commit CRC, repeated sequence, enums and bounds all validate. An unreadable/ECC-faulting or torn record is invalid; boot recovery must handle it without a reset loop. Journal sequence is u64, strictly increasing, and cannot wrap.

Payload layout (all integers LE): magic `RUJ1` at 0; u16 format=1 at 4; u16 record_bytes=512 at 6; u64 sequence at 8; u32 lock at 16; u32 boot_state at 20; 16 raw update-ID bytes at 24; u32 target at 40; u32 confirmed_slot at 44; u32 candidate_slot at 48; u32 trial_attempts at 52; u32 confirmed_bytes at 56; u32 candidate_bytes at 60; confirmed SHA-256 bytes at 64; candidate SHA-256 bytes at 96; confirmed FW_ID[48] at 128; candidate FW_ID[48] at 176; u32 confirmed_profile_crc at 224; u32 candidate_profile_crc at 228; u32 last_error at 232; u32 job_result at 236; remaining bytes 240..479 zero. Slot codes 0=NONE, 1=A, 2=B; target 0=NONE, 1=STM, 2=ESP; lock 0/1; boot_state 0=CONFIRMED, 1=RECEIVING, 2=TRIAL_PENDING, 3=TRIAL_ATTEMPTED; attempts 0/1. job_result is 0=READY, 1=COMPLETE, 2=ABORTED, 3=ERROR, 4=EXITING. New OPEN commits READY; confirmation commits COMPLETE; abort/error commits its terminal value; EXIT commits EXITING with lock=0. These distinguish an empty prepared session from a completed update after power loss. Stored last_error is 0=NONE, 1=INTERRUPTED, 2=FLASH_ERROR, 3=BAD_HASH, 4=BAD_HEADER, 5=TRIAL_FAILED, 6=ROLLED_BACK, 7=METADATA_ERROR, 8=CANCELLED; other live errors remain status-only.

The commit word at 480 contains ASCII `RCM1`, u32 CRC-32/ISO-HDLC over bytes 0..479, u64 repeated sequence, then 16 zero bytes. Confirmed fields are preserved in every pending record. Confirmation atomically copies candidate descriptors into confirmed descriptors, clears candidate descriptors/attempts, sets boot_state=CONFIRMED and job_result=COMPLETE, and retains lock=1. Abort/failure clears candidate validity without modifying confirmed descriptors. Before overwriting an inactive slot, a committed RECEIVING record removes its candidate validity. Candidate fields never grant boot permission unless boot_state is TRIAL_PENDING/TRIAL_ATTEMPTED and its full image hash validates.

Scan both sectors on boot and use the highest valid sequence. Duplicate identical records are harmless; same sequence with different payload or no trustworthy record means recovery-only METADATA_ERROR, not a guessed boot. When the append sector is full, erase the other sector **while retaining the current committed record**, write/readback/commit a successor snapshot there, and only then allow the old sector to be erased. A cut at any point must leave at least the prior committed snapshot. Power-cut tests include journal rollover, ECC handling and confirmation, not just image-body transfer.

**UPD-08 — Flash execution and watchdog.** Loader may update A in the same bank as its stored code. Therefore all code, constants, vector entries and ISRs used while either bank is busy — including flash polling, UART, physical-stop input handling, clock/tick and watchdog — must execute from verified SRAM placement. A `.ramfunc` tag on one erase function is insufficient if it calls flash-resident helpers. Disable or relocate unrelated interrupts, and apply the vendor cache/barrier rules. Assert these placements from the linker map and test both slots. Program complete aligned 32-byte words once, with readback after programming. Configure flash latency, supply range and error flags for the actual part; do not mass-erase.

Keep STM IWDG active with the existing <=250 ms reset bound. In update mode a healthy update-worker cycle replaces the operational-supervisor feed condition: service UART/stop inputs, check flash status, check the current phase deadline, then feed. A stuck flash operation past its sector deadline stops feeding; a timer ISR alone cannot keep it alive. Erase waits must yield/service from SRAM, not block a task for seconds or provoke repeated watchdog resets. The 20 ms armed-motion deadline and motion-task CPU budget do not apply after quiescence; HTTP/status/watchdog deadlines still do. MCU busy time should fall while waiting for UART/flash, not become 100% spin polling.

**UPD-09 — Trial and rollback.** Boot only a complete readback-verified image. END commits TRIAL_PENDING, then loader commits TRIAL_ATTEMPTED with attempts=1 **before** jumping to the candidate. Keep the former confirmed slot intact. A reset before durable confirmation, a failed image check, or failure to provide health proof within 10 s makes that candidate unbootable and retains/reselects the prior confirmed slot. There is one trial attempt, never an endless trial reboot loop. The trial app must request reset on its own 10 s deadline; ESP independently starts a 10 s trial timer when loader reports TRIAL and asserts NRST if no successful handoff is observed. Ordinary heartbeats cannot extend that trial timer. This covers an app that keeps feeding IWDG but fails its update self-test.

The trial app runs locked: output inhibit asserted, no CAN traffic, no navigation/sensors needed. It verifies its own header/profile, RAM initialization, bounded scheduler/watchdog service and service-UART response to ESP. Missing MQTT/GNSS/IMU is not a failed boot test. Successful local self-test requests a reset back to the loader with a one-shot `TRIAL_OK` handoff naming the update ID and candidate SHA. Loader accepts it only for the matching TRIAL_ATTEMPTED record and a software-requested reset, rechecks image identity, commits the candidate as CONFIRMED, and publishes COMPLETE while remaining in the loader/maintenance lock. This durable commit is the completion point. A power cut before that commit is allowed to roll back a healthy candidate; it is not allowed to boot an unconfirmed candidate as confirmed.

The reset handoff uses RTC backup registers BKP0..BKP15 only: BKP0 is marker `0x52554831` written last; BKP1 is request 1=ENTER_UPDATE or 2=TRIAL_OK; BKP2..5 are the 16 update-ID bytes; BKP6..13 are the 32 candidate hash bytes (zero for ENTER_UPDATE); BKP14 is CRC-32 over the LE bytes of BKP1..13; BKP15 is zero. Loader reads and immediately clears BKP0 before acting. A mailbox cannot replace a durable journal, authorize a different image, or bypass stopping. ENTER_UPDATE forces the loader to wait for the matching OPEN instead of the ordinary 2000 ms boot window; it commits lock=1 with target=NONE until OPEN supplies the target. A missing/invalid mailbox takes the journal's conservative boot path. Document RTC backup-domain ownership so unrelated code does not overwrite this handoff.

If no valid confirmed app exists, remain in recovery with UART/HTTP update access through ESP and outputs inhibited. Failure of a newly confirmed image later during ordinary operation is an ordinary fault/reset; no claim is made that a 10 s test proves all future behavior. The retained previous slot is not erased until the next accepted update needs that slot. A developer can reinstall a known-good package through the recovery path even when the current app hangs.

### 17.7 ESP buffering, ESP OTA and interruption rules

**STM image transport.** Once READY, ESP allocates one bounded PSRAM buffer of at most 786432 bytes for the complete STM binary. It reads the HTTP body with TCP backpressure, computes SHA-256 incrementally, and verifies metadata before sending BEGIN. This is the only exception to the 1024-byte mission-upload-ahead rule; it is allowed because all operational producers are stopped and the board has the commissioned PSRAM capacity. No second full firmware copy is allocated. Allocation failure reports NO_BUFFER and remains locked. ESP does not persist every data block or use its own OTA partition as STM scratch space.

After body acceptance, ESP autonomously finishes BEGIN/DATA/END and trial tracking even if HC's browser closes. The image and job identity are already fixed; a reconnect only observes progress. After ESP reset the RAM image is gone: incomplete transfer reports INTERRUPTED and requires a complete new upload. Never synthesize missing bytes or continue from an assumed UART offset. HTTP callbacks enqueue bounded work and yield; they do not synchronously wait through STM erases.

**ESP application OTA.** STM remains in its immutable loader with the same update lock, CAN off and outputs inhibited. Use ESP-IDF-supported inactive-app OTA with rollback enabled and tested in the actual runtime. Stream into the inactive partition using bounded buffers; verify full length, SHA-256, ESP32-S3 target, installed profile, contract 3.1.0 and embedded build metadata before selecting it. No bootloader/partition-table/credential/factory reset payload is accepted. `esp_ota_max_bytes` is the actual inactive partition capacity, and size above it rejects before writing.

The newly booted ESP checks storage, watchdog/task startup, update HTTP availability, retained session metadata and communication with the STM service ABI before marking itself valid. It deliberately does not start normal sensors/MQTT/NTRIP. ESP trial must prove these conditions within 10 s of app entry or request rollback/reboot; a hardware/task watchdog covers hangs. Pin and test the ESP bootloader's rollback configuration; default library behavior is not evidence. After confirmation report COMPLETE while staying locked. Lost ESP heartbeats during its planned reboot do not make STM leave maintenance or erase anything.

**Interruption outcomes (authoritative rules):**

| Interruption | Required outcome |
|---|---|
| HC/Wi-Fi lost before full body reception | Discard incomplete body/ESP candidate; ERROR/TRANSFER_TIMEOUT or INTERRUPTED. Lock remains. STM confirmed image untouched. |
| HC/Wi-Fi lost after STM body acceptance | ESP may finish the already authorized fixed image locally; status is reconciled on reconnect. No dependence on HC keepalive. |
| UART corrupt/lost while programming STM | Bounded retries, then ERROR. Inactive partial image remains invalid. Confirmed image and loader survive; no automatic exit. |
| STM reset/power cut during erase/write/verify | Scan journal, discard partial candidate, remain locked in recovery. New session restarts from offset zero. |
| Power cut during journal commit/compaction | Use last valid committed snapshot; no half-record authorizes an image. |
| Reset/power cut during STM trial before confirmation | Reject candidate trial, retain previous confirmed image, report ROLLED_BACK. Stay locked. |
| Reset after candidate confirmation | New confirmed image remains selected; still locked until explicit finish. |
| ESP reset during STM transfer | ESP recovers session metadata before normal work; reacquires loader status, aborts an incomplete candidate and requires new full upload. |
| ESP reset after END was sent | Reconcile by update ID/hash and journal status. COMPLETE/ROLLED_BACK takes precedence over ESP's stale WRITING/TRIAL record; do not reflash automatically. |
| ESP OTA fails trial | Supported ESP rollback returns to the prior ESP app, which reads the persistent lock and exposes update access again. |
| Both MCUs lose power | Either retained lock is sufficient to block ordinary control. ESP and loader reconcile before any normal command admission. |
| User presses physical emergency stop during writing | Hardware inhibit remains active. Finish the current bounded flash operation; updater may continue while power permits. Releasing the stop cannot enable motion. |
| User presses ordinary STOP during writing | Reassert output prohibition, return/update stop status; do not confuse STOP with ABORT or erase confirmed firmware. |

On boot, journal RECEIVING yields ERROR/INTERRUPTED with candidate invalid. TRIAL_PENDING with a verified candidate schedules the single trial; TRIAL_ATTEMPTED without a valid software-reset TRIAL_OK rolls back and reports ERROR/ROLLED_BACK. CONFIRMED with lock=1 reconstructs READY/COMPLETE/ABORTED/ERROR from job_result, never from transfer byte counters; a verified trial confirmation is job_result=COMPLETE. ESP reconstructs its own target-ESP phase from the supported OTA state plus its persisted job, keeping loader lock authoritative. A locked loader does not automatically boot an application on a network or heartbeat timeout. Recovery services remain available indefinitely with bounded idle work. If power is too unstable to complete even journal writes, report the failure when observable; the specification cannot guarantee hardware survival or connectivity without electrical power.

### 17.8 Explicit return to ordinary operation

FINISH is permitted only when neither target is erasing/writing/verifying/trialling, a confirmed valid STM app and validated ESP app exist, and their installed operational versions/profile agree. It does not require GNSS fix, IMU readiness, NTRIP or a released physical emergency stop. Active physical inputs are sampled by the app on restart and still block ARM.

1. ESP records phase EXITING while keeping its durable lock and ordinary command gate closed. It sends EXIT with its installed major/minor/profile. Loader verifies these against the confirmed image, appends a record clearing its lock and resets into that image. It never restores a mission or armed state.
2. ESP performs operational discovery while still refusing external control. Its startup updater probe during this one expected EXITING interval must not reopen the loader merely because the ESP-side lock remains. It starts fresh sensor acquisition and resets sensor epochs, caches, request IDs/leases and update UART queues; it cannot replay the old sample buffer.
3. Confirm fresh compatible STM state is DISARMED, or FAULT solely because active physical inputs are present; store EMPTY and all output targets zero. Then ESP clears its own persistent lock, starts normal MQTT/WS/NTRIP services, and reports IDLE update phase. A sensor that remains unavailable is shown unavailable and handled by the ordinary mode prerequisites.
4. HC discards its old command/session objects, displays the fresh boot/epoch/state, and requires explicit upload/calibration/ARM/START or a new manual claim as applicable.

If a reset/timeout interrupts EXITING, ESP keeps its command gate closed and reconciles. Matching fresh DISARMED/FAULT + EMPTY from the intended confirmed image allows completing that already-authorized FINISH; otherwise re-enter recovery and report EXIT_FAILED. A cleared STM lock alone never permits ESP to replay an old command. ABORT, image verification, COMPLETE, rollback and link recovery do not implicitly perform FINISH.

`MAINT_BEGIN`/`MAINT_END` remain ordinary stopped servicing commands for non-firmware work. They cannot create, clear or bypass a persistent firmware-update lock. All firmware updates use this section's session interface.

### 17.9 Installation prerequisites and deliberately excluded mechanisms

The supplied code does not contain this immutable-loader/A-B design. Initial conversion requires one controlled local ST-LINK installation of loader, factory installation data, initial A image and valid journal, plus both linker configurations. Once installed, routine STM application development updates use HC–ESP–STM remotely. Do not advertise `stm_remote_update:true` until loader/layout/wiring and T37–T52 pass.

ESP GPIO13 → STM NRST must be verified as an open-drain reset path (drive low 100 ms, then release; never actively drive NRST high or inject 5 V). This connection is required to recover a nonresponsive STM application remotely. GPIO12/BOOT0 is **not** a field ROM-loader selector in this design: keep BOOT0 at the verified normal-flash boot level; if wired, ESP must never raise it during this updater. Reset always enters the protected loader at 0x08000000. After reset the loader listens for service OPEN for 2000 ms before ordinary boot when unlocked; ESP sends U_HELLO/OPEN every 100 ms in that window. A locked loader has no escape timeout. Reset requests are sent only by the admitted update coordinator, never by ordinary reconnect code.

If the application does not answer service OPEN, ESP may use this reset path automatically **after** admitting/locking the update session; it must show that recovery entry is being used. Loader's stopping worker still establishes §17.3 evidence before any erase. An unknown UART/pin/flash layout does not trigger automatic ROM, parity, baud or mass-erase fallback. If NRST is not connected, a working app can enter its loader voluntarily, but dead-app remote recovery is unavailable and full conformance cannot be claimed.

Provisioned factory data contains the common profile and an installation manifest recording MCU ID/flash size/revision, board identity, USART1 GPIO/clock mapping, CAN mapping, physical-stop/inhibit pins and polarity, measured stop/coast behavior, and approved VESC timeout settings. The file is length-delimited canonical JSON with a stored CRC, provisioned locally into the factory region; the loader implements a small bounded reader for the fields it uses. Factory header at region base: ASCII `RFI1`, u32 LE JSON length (1..16384), u32 LE CRC-32 over exact JSON bytes, u32 zero, then JSON bytes and erased 0xFF remainder. Top-level JSON keys are `profile` (exact §4 profile) and `installation` (deployment manifest). CRC/profile mismatch or invalid required hardware fields prevents flash admission/normal boot and reports METADATA_ERROR; no pin/default is guessed.

For the alternate stopped proof, `installation` must explicitly contain `motor_inhibit_feedback_present` (boolean), feedback port/pin/active level when true, and `power_removed_coast_ms` (measured integer 1000..60000). These supplement, never replace, the actual board wiring record. Only verified assertion of this **independent** power-inhibit feedback, continuously for that coast interval, can replace missing RPM feedback. With no such circuit use measured wheel/blade stop. The supplied source alone does not prove such a feedback circuit exists.

The normal stop path and VESC timeout must be commissioned for stationary service on the intended terrain; motor power removal or zero current does not imply mechanical holding on a slope. The firmware promises no commanded motion during update, not an unmeasured mechanical parking brake.

Keep the updater small: one loader, two app slots, two metadata sectors, one active session, fixed-size frames, one chunk outstanding, full restart of an interrupted transfer. No delta patches, automatic cross-reboot byte resume, simultaneous ESP/STM flashing, remote loader/option-byte update, external-flash dependency, MQTT firmware payload, generic memory API, app-to-app copying or transparent legacy fallback belongs in v3.1.

## 18. Telemetry and diagnostics

HC should answer four questions without reading debug text: what mode is active, what data are missing, why did movement stop, and which explicit action can resume operation. PAUSED reasons are displayed directly; there is no instruction to clear all faults for a recoverable navigation pause.

Each accepted transition logs: STM boot, monotonic time, event sequence, prior state, new state, reason, request/lease ID if applicable, mission identity/index, and active fault mask. Log storage is bounded (§16). HC persists events and periodic state for later analysis; event loss cannot prevent control.

Expose installed-versus-active safety separately. No fake healthy `bumper=false` is shown for an absent input. `target_erpm` and measured `erpm` are separate. `stopped=false` after STOP may simply mean the blade is coasting; it must not be relabeled as running mission.

Diagnostics are observations, not new control sources. Runtime PERF counters include packet rejection, input age, scheduling budget and queue high-water marks. Rate-limit repeated errors to one human log per second per error category, while retaining counters. Firmware updating has its own coherent phase/error/byte/boot status (§17.4); frozen ordinary telemetry is never relabeled fresh. No continuous CAN/PB8/UART electrical timing tests run during normal operation. Bench electrical tests live in a separate nonconformant firmware target.

No credentials, access tokens or unredacted network authentication headers appear in UART/MQTT logs or exports. The specification intentionally contains none of the credentials present in the reviewed sketch.

## 19. Implementation modules

### 19.1 Shared definitions

Maintain a small language-neutral schema/source directory containing protocol enums, field order, constants, profile canonicalization rules and golden vectors. Generate C/C++/HC constants from it, or use identical checked-in definitions tested against those vectors. Do not create independent hand-maintained lists of accepted mission semantics in all three projects.

Suggested files are implementation structure, not new runtime components:

| Project | Modules |
|---|---|
| Shared | `rover_contract`, `rvm3_layout`, `profile_schema`, `golden_vectors`, `update_abi`, `firmware_header`, `stop_only` |
| STM | `app_state`, `safety_supervisor`, `motion_arbiter`, `mission_store`, `mission_runner`, `navigation`, `geometry`, `uart_protocol`, `vesc_can`, `telemetry`, `board_profile`, `maintenance_adapter`; separate protected `recovery_loader`, `boot_journal`, `flash_ram_worker`; A/B linker scripts |
| ESP | `sensor_gnss`, `sensor_imu`, `uart_bridge`, `request_router`, `network_mqtt`, `manual_ws`, `mission_http`, `ntrip_client`, `update_coordinator`, `stm_update_transport`, `esp_ota`, `status_cache` |
| HC | `mission_compiler`, `rover_client_v3`, `manual_client_v3`, `state_store`, `run_log`, `firmware_package_selector`, `update_client` |

Main/loop functions only initialize and schedule these modules. Avoid rewriting already-working hardware drivers unnecessarily. Every old direct motor-command call site must be migrated to the one STM arbiter, including STOP, fault and ordinary maintenance paths. The loader reuses the stop-only implementation and profile conversions; its exclusive boot context cannot coexist with the application arbiter.

### 19.2 Rules for implementation agents

- Copy this exact document into all relevant repositories and reference it from their project instructions.
- Implement numbered requirements; do not infer behavior from the old code when it conflicts with this document.
- Do not add fallback executors, watchdog bypasses, optimistic status, automatic fault clearing or undisclosed additional start preconditions.
- Do not advertise v3 conformance until relevant acceptance tests have evidence. Work-in-progress builds use `conformant=false`.
- Unknown hardware measurements remain explicitly uncommissioned; they are never replaced with guessed pole counts, gear ratios, GPIOs or stop times.
- When an implementation cannot meet a stated bound, report the exact requirement and evidence; propose a reviewed specification revision instead of changing only one side.
- HC changes are part of this migration even though only two firmware source files were reviewed. Leaving HC on v2 is not a supported deployment.

## 20. Migration and defect traceability

The following defects were found by static inspection of the supplied files. This is a targeted control-path review, not a claim that every possible defect was found or reproduced on hardware.

| ID | Existing location / behavior | Required repair | Acceptance evidence |
|---|---|---|---|
| F01 | STM `ProcessAutoNavigation`: ALIGN sets forward=0 then minimum-wheel clamp reduces turn to 0. | Separate ALIGN/TRACK; differential kinematics allow opposite wheel velocities. | T01, T02 |
| F02 | Stale GNSS/IMU branch returns while infinite repeated motor target remains active. | Data failure clears intent and PAUSES; 100 ms local intent expiry; output arbiter owns refresh. | T05, T06, T18 |
| F03 | ESP `sendPeriodicDrive` uses historical client timestamp to send repeated RC STOP during mission. | Delete it; STM lease scoped to MANUAL. No manual timer exists in AUTO. | T03, T04 |
| F04 | ESP re-sends cached GNSS fields; STM stamps each arrival fresh. | Preserve source epoch/seq/age; duplicates never renew freshness. | T05, T07 |
| F05 | ESP 180-character truncation/drop versus longer STM mission status. | One 512-byte bounded parser; exact framing and CRC; full discard of malformed frame. | T08, T09 |
| F06 | Private response-wait readers consume UART and block normal sensor work. | One RX dispatcher, async transactions, priority queues. | T09, T19, T20 |
| F07 | HTTP resume changes ESP state without STM resume; MQTT pause becomes RC STOP. | Both map to real STM PAUSE/RESUME and one checkpoint model. | T10, T11 |
| F08 | Validated segment speed/blade RPM ignored; turn records omitted; 4096 versus smaller expanded route. | RVM3 fixed segment semantics; execute all records directly; identical limits at every layer. | T12, T13, T14 |
| F09 | MissionStart modifies global feedback/link flags and clears fault bits. | START is a state transition only; fault/feedback policy independent. | T15 |
| F10 | ESP optimistically publishes RUNNING after incomplete start confirmation. | Publish STM state only; ACK loss means UNKNOWN until reconciliation. | T16, T17 |
| F11 | Multiple heading offsets/legacy control paths can disagree. | One STM heading reference, one ESP mounting transform, explicit units/sign tests. | T01, T02, T23 |
| F12 | STM CAN TX includes blocking wait and verbose logging. | Nonblocking CAN mailboxes; no normal per-frame log; bounded scheduling. | T19, T20, T21 |
| F13 | Runtime geofence removed; approach checks sample an interval. | Exact geometry validation and explicit runtime envelope; no automatic approach. | T24, T25 |
| F14 | Local fault paths differ in whether they send stop or only clear software state. | Every mode/fault exit goes through one stop procedure; measured stop distinguished from command acknowledgement. | T18, T26 |
| F15 | Abort/storage updates can diverge between ESP and STM. | STM-owned single upload store; scoped ABORT, no execution semantics. | T27, T28 |
| F16 | STM FWUP stages in bank 2 then RAM-copies over bank 1; protection of a separately recoverable reset entry is not established by the supplied application. | Protected loader; inactive-slot write/direct boot; two-sector journal; trial rollback; never overwrite confirmed app. This is a static risk finding, not a reproduced power-cut failure. | T40, T41, T42, T43 |
| F17 | ESP FWUP has private wait/read/noise filtering and optional ROM/reset paths; normal services may compete with flash traffic. | Single service parser, exclusive update allowlist, fixed UART settings and bounded worker; one documented recovery path. | T37, T38, T44, T45 |

Delete dead code after migration; merely compiling both new and old engines and hoping the old one stays inactive does not satisfy the reform. The source descriptions also differ from actual code in some constants (for example IMU freshness); this document supplies the new single values rather than merging conflicting old values.

## 21. Implementation order

| Stage | Deliverable | Required gate before proceeding |
|---|---|---|
| A | Shared types/constants, profile tooling, frame codec, mock STM/ESP endpoints and mission encoder/validator | Golden vectors and malformed input tests pass. No motors. |
| A1 | Protected STM loader, factory/journal layout, A/B linkers, NRST wiring, service ABI and exclusive updater on ESP/HC | Initial local provision; remote transfer, interruption and rollback tests with motor power inhibited. This enables subsequent development updates from the yard. |
| B | STM state machine, one arbiter, CAN refresh/stop/timeout, physical safety | Wheel direction, local stop and fault tests with cutter disabled. |
| C | ESP task split, sensor epochs/ages, nonblocking bridge and fresh-state reporting | Sensor unplug/reset and network-stall tests pass without motion. |
| D | Manual WS end-to-end | Lease expiry, ESP loss, delayed frames, STOP priority and reclaim tests pass. |
| E | RVM3 upload + blade-free AUTO | One segment, alignment, turn, pause/resume, geometry and maximum mission tests pass. |
| F | HC v3 UI/compiler, full status mapping | No optimistic state or stale-command replay; old APIs unavailable. |
| G | Blade control and operational configuration | Mechanical RPM calibration, cutoff/coast, spin-up and active-fault tests pass; first with cutter blade physically removed. |
| H | Soak, commissioning record and both target OTA/recovery paths | §22 evidence complete; only then set commissioned/conformant appropriately. |

Each stage removes corresponding legacy paths. Do not start by cosmetically splitting the old 10,000-line files while preserving contradictory behavior. Do not require every optional future feature to be complete before delivering blade-free, tested manual/AUTO operation.

## 22. Acceptance tests

Record firmware hashes, installed profile/CRC, VESC firmware/config exports, test method, captured states/frames, pass/fail and observed timing. Pure functions/protocol/state transitions are host-tested; actuator/freshness/deadline assertions require hardware or a faithful injected-I/O harness as indicated. An engineering review is not substituted for these tests.

| Test | Stimulus | Required outcome |
|---|---|---|
| T01 Coordinates/kinematics | Target east while heading north; request clockwise manual turn with v=0; repeat all cardinal headings. | Positive clockwise correction: left forward, right reverse; heading error decreases. No zero-turn clamp. Correct antenna offset sign. |
| T02 Heading reference | Set known heading while stopped; turn +90 degrees; restart IMU, then ESP. | Heading changes +90000 mdeg before reset; resets invalidate reference and pause AUTO; no second hidden offset. |
| T03 Old browser | Use manual, release, start AUTO, then close/reconnect/expire the old WS. | AUTO unaffected; no RC STOP and no old lease mutation. |
| T04 HC/MQTT loss | Disconnect HC/broker during AUTO while replaying valid current GNSS/IMU from sensor harness. | AUTO continues; status becomes unavailable at HC. Reconnect does not restart or stop it. |
| T05 GNSS wire loss | Physically stop F9P UART output while ESP/STM/IMU run. | GNSS sample sequence stops; effective age grows; AUTO pauses at the specified limit; previous wheel targets are cleared. |
| T06 IMU loss | Stop IMU reports but leave ESP heartbeat active. | IMU age reaches limit; AUTO pauses / MANUAL stops; no continued old intent and no false fresh heading. |
| T07 Duplicate samples | Repeat identical GNSS epoch/seq with newly arriving UART frames; inject backlog and GPS-week rollover. | Repeats do not renew age. Rollover/new epoch is handled explicitly, not mistaken for valid fresh old coordinates. |
| T08 Frame length/CRC | 180, 181, 207, 511, 512, 513-byte frames; bad CRC; incomplete LF; overflowing RX ring. | Valid <=512-byte frames parse completely. Invalid/oversized frames discarded whole. Next valid frame recovers; no stale-age refresh. |
| T09 Mixed traffic | Interleave ACK, HB, sensors, state and upload data; add a late old ACK. | Correct dispatch and correlation; no independent reader loses status; old ACK does not override current state. |
| T10 Pause/resume | Pause mid-segment via MQTT; resume via HTTP command, then reverse transports. | Wheels/blade stop, checkpoint preserved, same segment resumes after ALIGN; completed segments not replayed. |
| T11 Displacement | Pause, move rover >200 mm, request RESUME. | REPOSITION_REQUIRED, no automatic travel/approach. STOP + explicit manual positioning remains available. |
| T12 Mission parameters | Two segments with distinct speeds and blade speeds, one transit with blade=0. | Exact per-segment semantics observed; no hardcoded 6000, no unrequested cutter on ALIGN/transit. |
| T13 Capacity | Upload/validate/iterate 4096 segments within byte/geometry limits; then 4097 or oversized file. | Full supported file executes/iterates without smaller route cap; oversized input rejected before executable READY. |
| T14 Format rejection | Unsupported flags, wrong reserved bytes, invalid speed, blade disabled, zero-length record, truncated table. | Exact rejection code/index; never skip or silently clamp file semantics. |
| T15 Fault immunity | Latch MOTOR_FEEDBACK or ESTOP; send START, ARM, duplicates and reconnects. | No hidden fault clear, no watchdog disable, no movement. RESET_FAULT only after cause clears, then separate ARM. |
| T16 Lost START ACK | Drop STM ACK after START commits; retry exact request then allow STATE. | One execution only; cached ACK or UNKNOWN/reconciliation; no second confirmation PAUSE. |
| T17 Stale commands | Retained MQTT command, stale boot/epoch, duplicate altered request, queued START followed by STOP. | Retained/stale/conflicting requests rejected; STOP prevents later queued movement; no replay after reboot. |
| T18 Controller loss | Freeze/kill ESP task, disconnect UART, freeze STM main loop with timer still running. | Manual/peer expiry and then independent IWDG/VESC timeouts behave as specified; timer alone cannot keep watchdog alive. |
| T19 Priority under load | Maximum telemetry, largest mission upload, many HTTP polls, MQTT flood; issue STOP. | <=100 ms to healthy STM/CAN stop enqueue; no hidden frame chain; sensor/heartbeat service maintained. |
| T20 Reconnect stress | Repeated NTRIP DNS/socket failures, Wi-Fi outage, broker retries while valid sensor harness remains active. | Bridge/sensor tasks meet deadlines; one saturated network path cannot starve local control. |
| T21 CAN fault/feedback | Remove one wheel's feedback; inject bus-off/busy; leave other IDs sending. | Correct individual timeout/fault, immediate intent invalidation, bounded recovery; never auto-rearm. |
| T22 Manual expiry | Stop full drive frames but continue ping/pong; duplicate drive seq; send malformed/out-of-range drive. | Targets revoked within end-to-end bound; ping and duplicates do not renew; invalid active-lease input stops that lease. |
| T23 Accuracy/units | Known wheel distance and cutter shaft speed; quaternion/mount/sign fixtures; GNSS altitude datum check. | eRPM/mechanical conversions correct; profile values measured; mounting applied once. |
| T24 Geometry | Concave polygon, narrow exclusion crossed between sample points, touching/overlapping holes, outside start. | Exact whole-segment validation rejects forbidden path; no 0.5 m sampling escape. |
| T25 Runtime fence/quality | Inject real valid quality downgrade, boundary drift and hAcc increase; then recovery. | Appropriate PAUSED reason, no fault-clear requirement or automatic resume; ready flag returns after stability period. |
| T26 Physical stops | Trigger each installed input in MANUAL and AUTO; observe actual wheel/cutter stop times and CAN loss stop. | Same centralized procedure, latched reasons, actual stop distinguished from ACK; measured terrain/deceleration bound recorded. |
| T27 Interrupted upload | Drop HTTP at several offsets; wrong chunk retry; CRC mismatch; STOP during validation. | No partial executable mission; bounded cancellation; state/store coherent; no corrupted old mission retained as READY. |
| T28 Restart matrix | ESP-only reset, STM-only reset, both reset, reset during PAUSED/upload/MAINTENANCE. | §17 persistence rules exactly; new boot invalidates stale commands; no automatic movement. |
| T29 ESP OTA | Wrong image/hash/target, network drop, power cut before commit, successful update then failed first boot through §17 session API. | Prior ESP image recoverable/rollback verified; STM stays in locked loader with CAN off; mission execution never resumes. |
| T30 Soak/headroom | 60 minutes normal worst accepted load plus 15 minutes reconnect/upload stress while stopped. | §16 utilization/memory/latency targets; no unbounded allocation growth, no control deadline miss, no hidden busy wait. |
| T31 Legacy removal | Exercise all old HTTP/MQTT/UART control names and generic command endpoints. | No movement side effects; old endpoints unavailable; one operational control implementation. |
| T32 Clock/sequence wrap | Simulated millis wrap and sequence boundary; reordered/old frames. | Correct age/expiry ordering; no accidental renewal. Active sessions are ended before counter reuse if wrap is not supported. |
| T33 Blade spin-up/coast | Blade never reaches 80%; reaches it; coasts after STOP; blade feedback disappears. | Spin-up wait and pause/fault selection correct; no translation-before-ready; no false physical-stopped claim. |
| T34 Profile mismatch | HC file/ESP profile/STM checksum differ; try upload/ARM/START/STOP. | MCU profile mismatch blocks movement; a mismatching file rejects upload/START but does not itself disable otherwise valid manual operation. STOP works; no silent conversion. |
| T35 Unavailable devices | GNSS absent during manual; disabled blade absent; IMU absent; wheel absent. | Only mode-relevant prerequisites enforced; no GNSS gate on manual, but no ARM without IMU/wheels. |
| T36 State coherence | Sample status through MQTT and HTTP throughout all transitions. | Same STM source state/sequence, real ages, no phantom RUNNING/PAUSED; missing STM becomes unknown. |

| T37 Exclusive entry | Request update from every robot state, including AUTO/PAUSED, and during a mission upload. | One transition revokes output; mission/checkpoint/leases/queued movement deleted; measured stopping completes before writes. Only §17 allowlist remains. Invalid create syntax/auth fails before entry. |
| T38 Channel isolation | Inject normal MQTT/HTTP/WS/UART commands and sensor floods during STM and ESP update; inspect UART/CAN/I2C/task traces. | HTTP 423 for ordinary commands; MQTT/WS/NTRIP/sensor workers stopped; no CAN traffic after quiescence; no stale-command execution. STOP and physical inhibit remain effective. |
| T39 Image rejection | Wrong target, slot link address, vector/MSP, embedded header, size, ABI/profile, padding/hash; oversized body. | No candidate boot; writes confined to allowed inactive slot only. External hash alone cannot approve wrong metadata. |
| T40 Power cuts | Cut power at randomized offsets during erase, every flash-word class, END hash and boot-decision writes; test A and B. | Loader and confirmed app untouched; partial candidate invalid; recovery remains reachable; interrupted transfer restarts from zero. |
| T41 Journal rollover/ECC | Fill metadata sector, interrupt erase/copy/commit/old-sector reclamation; inject torn and unreadable/ECC-faulting records. | Last committed snapshot survives; no guessed candidate, unreadable-record reset loop or loss of the only confirmed record. |
| T42 Trial rollback | Candidate hangs, faults, resets or never reports health; drop UART during trial; interrupt TRIAL_OK reset/confirmation. | At most one trial; prior confirmed slot retained; ROLLED_BACK/ERROR, lock remains. No ordinary app start or motor command during trial. |
| T43 Successful A/B cycle | Update A→B then B→A; verify hashes/header/VTOR, watchdog and CAN trace. | Both slot variants run; inactive-only programming and direct vector boot; COMPLETE only after durable confirmation; no bank-copy/option-byte writes. |
| T44 UART transaction faults | Drop/duplicate/reorder/corrupt DATA/ACK/END; reset peer; send duplicate ID with changed bytes. | Exactly-once writes; committed offsets only; bounded reconciliation; new session after interrupted reboot; no unbounded resend or programming one flash word twice. |
| T45 Flash scheduling | Erase same-bank A and opposite-bank B, inspect map/runtime traces, saturate status polling. | Active flash workers/ISRs/constants in SRAM; IWDG remains effective; HTTP/status respond; flash deadlines respected; no 100% busy-wait. |
| T46 Dead-app recovery | Hang ordinary STM app, request update, operate ESP NRST path. Also test GPIO/loader absent. | Protected loader reachable remotely with verified wiring and stopping evidence; unavailable capability reported honestly if prerequisites absent; no ROM/mass-erase fallback. |
| T47 Broken sensors | Disconnect GNSS, IMU, broker/NTRIP; assert hardware stop; request update with valid stopping evidence. | Update succeeds without navigation-readiness gates or clearing physical stop; output remains inhibited; active stop blocks later ARM. |
| T48 Network/MCU restart matrix | Drop HC before/after body admission; reset ESP, STM, both; lose END response then reconnect. | Exact §17.7 outcomes; matching committed hash/state wins over stale cache; no automatic unlocked startup or reflash. |
| T49 Abort and STOP | STOP and ABORT at each phase, including during erase and after confirmation. | STOP retains update and output prohibition; ABORT waits bounded hardware boundary; lock/confirmed app survive; already committed update reported accurately. |
| T50 Finish and stale replay | FINISH after success/abort/error; interrupt EXITING; replay old mission/manual/command buffers and old HELLO minor=0. | Fresh compatible DISARMED/EMPTY or active-input FAULT; no restored mission/heading/lease; explicit new operation required; old minor cannot arm. |
| T51 Transfer capacity | Full 786432-byte STM images, both slots; insufficient PSRAM; max supported ESP image. | Bounded one-image memory, correct 32/128-byte boundaries, >=1800 B/s healthy STM DATA throughput, phase deadlines and 2 Hz progress. |
| T52 Recovery persistence/protection | Reboot repeatedly in terminal update phases; attempt protected-region/loader/option writes and legacy FWUP/ROM commands; repeat power-cut recovery. | Lock persists until FINISH; only documented image APIs act; protected regions unchanged; remote capability advertised only after installed evidence. |

Hardware pass criteria must include requested stop enqueue time **and** physical stopping/coasting behavior. Initial tests use wheels raised or a controlled blade-free test area; a software pass does not establish an unmeasured stopping distance.

## 23. Reference algorithms and vectors

### 23.1 CRC, framing and minimal mission encoder

This reference is a format oracle for host tests, not MCU firmware. It does not perform geometry or commissioning validation. Firmware codecs must reproduce the bytes exactly.

```python
import struct
import uuid
import zlib

def crc32(data: bytes) -> int:
    return zlib.crc32(data) & 0xFFFFFFFF

def uart_frame(src: str, dst: str, seq: int, kind: str, body: str) -> bytes:
    prefix = f"R3|{src}|{dst}|{seq}|{kind}|{body}".encode("ascii")
    frame = prefix + f"|{crc32(prefix):08X}\n".encode("ascii")
    assert len(frame) <= 512
    return frame

def minimal_mission(profile_crc: int) -> bytes:
    # 10 x 10 m allowed square; 1 m blade-free northward segment.
    vertices = [(-5000, -5000), (5000, -5000),
                (5000, 5000), (-5000, 5000)]  # CCW
    record = struct.pack("<iiHHHH", 0, 1000, 250, 0, 0, 0)
    payload = b"".join(struct.pack("<ii", *p) for p in vertices) + record
    header = bytearray(96)
    struct.pack_into("<4sHHII", header, 0, b"RVM3", 3, 0, 96+len(payload), 0)
    header[16:32] = uuid.UUID("00112233-4455-4677-8899-aabbccddeeff").bytes
    struct.pack_into("<IiiiiiHHII", header, 32,
                     1, 470000000, 180000000, 100000, 0, 0,
                     4, 0, 1, profile_crc)
    result = header + payload
    struct.pack_into("<I", result, 12, crc32(result))
    return bytes(result)

assert crc32(b"123456789") == 0xCBF43926
assert len(minimal_mission(0x11223344)) == 144
```

Checked golden outputs for this exact encoder:

```text
uart_frame("0123456789ABCDEF", "FEDCBA9876543210", 1, "HB", "0"):
R3|0123456789ABCDEF|FEDCBA9876543210|1|HB|0|74624E82<LF>

minimal_mission(0x11223344):
length: 144 bytes
file_crc32 numeric: CAA8AA80
bytes 12..15: 80 AA A8 CA
SHA-256: 73dfbb441429622cae9db7a1bf5abb6925558ed9f4e10d46e3303b98a1e208d7
```

The example origin is a synthetic test datum, not the owner's garden. Its profile CRC is a test constant, not authorization to run. A target profile with max speed <250 rejects it as specified.

### 23.2 WGS84 to ENU

Use double precision for ECEF/origin subtraction. Constants: semi-major axis a=6378137 m, flattening f=1/298.257223563, e²=f(2-f). Convert latitude phi and longitude lambda to radians. Height h is ellipsoid meters.

```text
N = a / sqrt(1 - e² * sin(phi)²)
X = (N + h) * cos(phi) * cos(lambda)
Y = (N + h) * cos(phi) * sin(lambda)
Z = (N*(1-e²) + h) * sin(phi)
```

Subtract origin ECEF to obtain dX/dY/dZ. With origin phi0/lambda0:

```text
east  = -sin(lambda0)*dX + cos(lambda0)*dY
north = -sin(phi0)*cos(lambda0)*dX - sin(phi0)*sin(lambda0)*dY + cos(phi0)*dZ
up    =  cos(phi0)*cos(lambda0)*dX + cos(phi0)*sin(lambda0)*dY + sin(phi0)*dZ
```

Round meters to millimeters once. HC and STM must agree within 2 mm on host-generated local fixtures before use. Test negative longitude, nonzero origin height and ±1 km extents. Do not use MSL altitude in one implementation and ellipsoid altitude in the other.

### 23.3 Body rotation and lever arm

Let psi be clockwise heading, theta nose-up pitch, phi right-down roll in radians. In ENU coordinates:

```text
forward = (sin(psi)*cos(theta), cos(psi)*cos(theta), sin(theta))
left0   = (-cos(psi), sin(psi), 0)
up0     = cross(forward, left0)
left    = cos(phi)*left0 + sin(phi)*up0
up      = -sin(phi)*left0 + cos(phi)*up0
antenna_offset_ENU = dx*forward + dy*left + dz*up
control_point_ENU  = antenna_position_ENU - antenna_offset_ENU
```

For a 200 mm forward antenna offset: facing north subtract 200 mm north; facing east subtract 200 mm east. Sensor-to-body mounting quaternion rotates sensor coordinates into this right-handed body frame. If a vendor quaternion maps sensor to reference, compute reference-from-body by multiplying reference-from-sensor by the inverse of body-from-sensor. Validate using fixtures; never resolve convention uncertainty by changing a sign until one field looks plausible.

### 23.4 Signed angle and scheduler oracle

```python
def heading_error_mdeg(target, current):
    return (target - current + 180000) % 360000 - 180000

def expired_u32(now, then, ttl_ms):
    return ((now - then) & 0xFFFFFFFF) > ttl_ms

assert heading_error_mdeg(90000, 0) == 90000
assert heading_error_mdeg(1000, 359000) == 2000
assert heading_error_mdeg(180000, 0) == -180000
assert expired_u32(30, 0xFFFFFFF0, 40)
```

Local implementation must use the same boundary rule: age <=limit is usable; age >limit expires. A supervisor cycle's <=10 ms detection delay is included in end-to-end budgets. Do not base duplicate detection on values alone: a stationary sensor can legitimately produce unchanged coordinates with a new sample identity.

### 23.5 Firmware header and update-frame vectors

This format-only oracle uses synthetic data and does not produce a bootable firmware. The SHA below is a checksum of the 256-byte header fixture, **not** the whole-image hash used in an update. The service frame tests encoding only; a live DATA also needs an admitted transfer and matching offset.

```python
import hashlib
import struct
import zlib

header = bytearray(256)
header[:4] = b"RFU1"
struct.pack_into("<HH", header, 4, 256, 1)
header[8:24] = b"STM32H743VI".ljust(16, b"\0")
struct.pack_into("<IIIIHHHHI", header, 24,
                 1, 2, 0x08140000, 131072, 3, 1, 1, 0, 0x12345678)
header[52:100] = b"rover-stm-3.1.0-vector".ljust(48, b"\0")
assert len(header) == 256
assert hashlib.sha256(header).hexdigest() == (
    "78ae7deaf1f7349b547f35b9fb7e8413421634afb57ffe35740fd34e4c188b4d")

prefix = ("R3|0123456789ABCDEF|FEDCBA9876543210|1|U_REQ|"
          "1,00112233445566778899AABBCCDDEEFF,DATA,0,128," + "00" * 128)
frame = (prefix + f"|{zlib.crc32(prefix.encode('ascii')):08X}\n").encode("ascii")
assert len(frame) == 357
assert frame.endswith(b"|4DE710BF\n")

# Journal commit word: payload must be exactly 480 bytes.
def journal_commit_word(payload, sequence):
    assert len(payload) == 480
    assert struct.unpack_from("<Q", payload, 8)[0] == sequence
    return struct.pack("<4sIQ16s", b"RCM1", zlib.crc32(payload), sequence, bytes(16))

payload = bytearray(480)
payload[:4] = b"RUJ1"
struct.pack_into("<HHQ", payload, 4, 1, 512, 1)
record = bytes(payload) + journal_commit_word(payload, 1)
assert len(record) == 512
assert struct.unpack_from("<I", record, 484)[0] == zlib.crc32(record[:480])
```

Implementations additionally test full-length DATA/status frames, wrong field counts, torn journal words, and the required hardware interruption cases in T37–T52. Running these format oracles is not evidence that an on-device loader or power-loss recovery has passed.

## 24. Evidence and reference documents

### 24.1 Reviewed project material

- `main.c`, firmware label `2026-09-25.6-mission-aim-first`, SHA-256 `bbbfd813f67eeefd72c5d1b654ea92d472b170198897b7e7065d64131060c67b`.
- `sketch_sep14a.ino`, SHA-256 `88f430056ca26f6a928c9c2bb84e8c4465e482e329c0472f48c4da7e3731b1ff`.
- `STM_CURRENT_BEHAVIOR.md` and `ESP_CURRENT_BEHAVIOR.md`, supplied September 25 behavior summaries; code takes precedence for the defect review.
- `ROVER_HC_CONTRACT.md`, v2.0.0 dated September 23, read as the previous HC contract. It is superseded, not edited in place by this deliverable.

HC source, complete STM project/MSP/linker files, bootloader, exact installed F9P firmware, VESC configuration dumps and physical commissioning measurements were not supplied. Accordingly this is a complete target behavior/interface specification with explicit installation inputs; it does not claim those unknown hardware values have been verified.

### 24.2 Primary technical references

References were checked on 2026-09-30. Repository `master`/documentation `stable` links can move; the implementation must pin its actual vendor source/toolchain versions in its build manifest.

1. [VESC CAN communication documentation](https://github.com/vedderb/bldc/blob/master/documentation/comm_can.md) — extended-ID layout, basic motor commands and local timeout behavior. The implementation must verify these against the installed controller firmware and the captured frame tests in §22.
2. [VESC firmware repository](https://github.com/vedderb/bldc) and [protocol types](https://github.com/vedderb/bldc/blob/master/datatypes.h) — primary source for version-specific motor protocol definitions. The reviewed local STM source also provided the STATUS parsing/IDs used in this baseline.
3. [u-blox F9 HPG 1.32 interface description, UBX-22008968](https://content.u-blox.com/sites/default/files/documents/u-blox-F9-HPG-1.32_InterfaceDescription_UBX-22008968.pdf) — canonical UBX navigation data/flags. This document was retrievable; it is not a claim that the owner's F9P runs HPG 1.32. Verify the corresponding installed-version manual before coding its parser/configuration.
4. [ZED-F9P integration manual](https://content.u-blox.com/sites/default/files/ZED-F9P_IntegrationManual_UBX-18010802.pdf) — receiver integration and RTK solution behavior.
5. [CEVA BNO08X datasheet](https://www.ceva-ip.com/wp-content/uploads/BNO080_085-Datasheet.pdf) — rotation-vector reporting and sensor reference/accuracy context; deployment mounting/sign tests remain mandatory.
6. [ST AN4839: Level-1 cache on STM32F7/H7](https://www.st.com/resource/en/application_note/an4839-level-1-cache-on-stm32f7-series-and-stm32h7-series-stmicroelectronics.pdf) — CPU/DMA data coherency and cacheable buffer handling.
7. [Espressif ESP32-S3 OTA documentation](https://docs.espressif.com/projects/esp-idf/en/stable/esp32s3/api-reference/system/ota.html) — inactive-image OTA, boot validation and rollback mechanisms. Enable/test these with the actual pinned runtime.
8. [ST STM32H742/743 datasheet DS12110, Rev 11](https://www.st.com/resource/en/datasheet/stm32h743vi.pdf) — §3.3.1 flash geometry, §3.3.2 memory regions and Tables 43/140 programming/erase timings for the applicable silicon revision. The 2 MiB H743VI layout in §17 is a project allocation using these device constraints, not a vendor-supplied rover bootloader.
9. [ST RM0433 reference manual](https://www.st.com/resource/en/reference_manual/dm00314099.pdf) and [ST H7 Flash training](https://www.st.com/content/ccc/resource/training/technical/product_training/group0/1f/4f/b7/85/91/e0/4d/2f/STM32H7-Memory-Flash_FLASH/files/STM32H7-Memory-Flash_FLASH.pdf/_jcr_content/translations/en.STM32H7-Memory-Flash_FLASH.pdf) — flash programming, bank/sector rules, protection and device-level boot/register behavior. The datasheet was retrieved directly; the oversized RM0433 document was indexed but not fully retrieved in this review. Implementation must pin/read the complete manual and actual-part errata for its driver/register setup.

Timeouts, margins, task budgets, state transitions, file format and API choices in this specification are project design decisions. Vendor documents do not certify this rover's stopping distance, heading quality, CPU headroom or overall safety. Those are established by the installation record and acceptance evidence.

**End of normative specification v3.1.0.**
